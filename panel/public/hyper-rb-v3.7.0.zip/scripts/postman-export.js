// ============================================================
// Hyper RB · Scripts · #12 postman-export
// Exporta requests sanitizadas para Postman Collection v2.1.0.
// Agrupa folders por host. Bodies binários omitidos.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  const BINARY_CT = /(image\/|audio\/|video\/|application\/(octet-stream|pdf|zip|x-protobuf|wasm))/i;

  function isBinaryContentType(headers) {
    if (!headers) return false;
    const ct = headers["content-type"] || headers["Content-Type"] || "";
    return BINARY_CT.test(String(ct));
  }

  function headersToPostman(h) {
    const out = [];
    if (!h) return out;
    for (const [k, v] of Object.entries(h)) {
      out.push({ key: String(k), value: String(v ?? ""), type: "text" });
    }
    return out;
  }

  function urlToPostman(rawUrl) {
    try {
      const u = new URL(rawUrl);
      const query = [];
      u.searchParams.forEach((value, key) => query.push({ key, value }));
      return {
        raw: rawUrl,
        protocol: u.protocol.replace(":", ""),
        host: u.hostname.split("."),
        path: u.pathname.split("/").filter(Boolean),
        ...(query.length ? { query } : {}),
      };
    } catch {
      return { raw: String(rawUrl || "") };
    }
  }

  function buildBody(req) {
    if (req.reqBody == null || req.reqBody === "") return undefined;
    if (isBinaryContentType(req.reqHeaders)) return undefined;
    return { mode: "raw", raw: String(req.reqBody), options: { raw: { language: "json" } } };
  }

  function shortName(req) {
    const path = req.pathname || "/";
    const trimmed = path.length > 60 ? path.slice(0, 57) + "…" : path;
    return `${req.method} ${trimmed}`;
  }

  function buildCollection(requests) {
    const ts = new Date().toISOString();
    const folders = new Map();
    let total = 0;

    for (const r of requests) {
      if (!r || !r.url) continue;
      const host = r.host || "unknown-host";
      if (!folders.has(host)) folders.set(host, []);
      folders.get(host).push({
        name: shortName(r),
        request: {
          method: r.method,
          header: headersToPostman(r.reqHeaders),
          url: urlToPostman(r.url),
          ...(buildBody(r) ? { body: buildBody(r) } : {}),
        },
        response: [],
      });
      total++;
    }

    const items = [];
    for (const [host, reqs] of folders) {
      items.push({ name: host, item: reqs });
    }

    return {
      info: {
        _postman_id: S.cryptoUuid(),
        name: `Hyper RB Export ${ts}`,
        description: "Exportação gerada pela Hyper RB · script postman-export",
        schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
      },
      item: items,
      _meta: { generatedAt: ts, totalRequests: total, totalFolders: items.length },
    };
  }

  const SCRIPT = {
    id: 12,
    slug: "postman-export",
    name: "Postman Collection",
    description: "Exporta requests capturadas como Postman Collection v2.1.0 (folders por host).",
    icon: "📦",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes." };
      }

      const collection = buildCollection(ctx.requests);
      const json = JSON.stringify(collection, null, 2);
      const filename = `hyper-rb-postman-${Date.now()}.json`;

      return {
        ok: true,
        summary: `${collection._meta.totalRequests} requests · ${collection._meta.totalFolders} hosts`,
        artifact: { filename, mime: "application/json", content: json },
        render(mountEl) {
          const folders = collection.item;
          const rows = folders.map((f) => `
            <tr>
              <td>${S.escapeHtml(f.name)}</td>
              <td style="text-align:right">${f.item.length}</td>
            </tr>
          `).join("");

          mountEl.innerHTML = `
            <div class="hyper-rb-section">
              <div class="hyper-rb-section-head">
                <div>
                  <div class="hyper-rb-section-title">Postman Collection v2.1.0</div>
                  <div class="hyper-rb-section-sub">
                    ${S.escapeHtml(collection._meta.totalRequests)} requests agrupadas em
                    ${S.escapeHtml(collection._meta.totalFolders)} folder(s).
                    Bodies binários omitidos. Headers sanitizados.
                  </div>
                </div>
                <button class="hyper-rb-btn hyper-rb-btn-primary dl-postman">⬇ Baixar .json</button>
              </div>
              <table class="hyper-rb-table">
                <thead><tr><th>Host (folder)</th><th style="text-align:right">Requests</th></tr></thead>
                <tbody>${rows || `<tr><td colspan="2">Nenhuma request elegível.</td></tr>`}</tbody>
              </table>
            </div>
          `;

          mountEl.querySelector(".dl-postman")?.addEventListener("click", () => {
            S.downloadBlob(filename, "application/json", json);
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();