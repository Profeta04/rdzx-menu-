// ============================================================
// Hyper RB · Scripts · #14 response-schema
// Infere JSON Schema (Draft 2020-12) a partir dos response bodies,
// agrupados por method+host+pathname (mesmo agrupador de #1).
// Sem IA, sem rede.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  const MAX_ENUM = 5;
  const MAX_SAMPLES_PER_GROUP = 20;

  function tryParseJson(str) {
    if (typeof str !== "string" || !str) return undefined;
    const s = str.trim();
    if (!s || (s[0] !== "{" && s[0] !== "[")) return undefined;
    try { return JSON.parse(s); } catch { return undefined; }
  }

  function typeOf(v) {
    if (v === null) return "null";
    if (Array.isArray(v)) return "array";
    if (typeof v === "number") return Number.isInteger(v) ? "integer" : "number";
    return typeof v; // string, boolean, object
  }

  // Merge a sample value into an accumulator node.
  // Node shape: { types:Set, values:Set (for scalars), required:Set, seen:Set, props:{}, items:node, count:number }
  function mergeNode(node, value) {
    if (!node) node = { types: new Set(), values: new Set(), required: null, seen: new Set(), props: {}, items: null, count: 0 };
    node.count++;
    const t = typeOf(value);
    node.types.add(t);

    if (t === "object" && value) {
      const keys = Object.keys(value);
      const keySet = new Set(keys);
      if (node.required === null) {
        node.required = new Set(keys);
      } else {
        for (const k of [...node.required]) if (!keySet.has(k)) node.required.delete(k);
      }
      for (const k of keys) {
        node.seen.add(k);
        node.props[k] = mergeNode(node.props[k], value[k]);
      }
    } else if (t === "array") {
      for (const item of value) node.items = mergeNode(node.items, item);
    } else if (t === "string" || t === "integer" || t === "number" || t === "boolean") {
      if (node.values.size <= MAX_ENUM + 1) node.values.add(value);
    }
    return node;
  }

  function nodeToSchema(node) {
    if (!node) return {};
    const types = [...node.types];
    const schema = {};

    if (types.length === 1) schema.type = types[0];
    else if (types.length > 1) schema.type = types;

    if (node.types.has("object")) {
      schema.properties = {};
      for (const k of Object.keys(node.props)) schema.properties[k] = nodeToSchema(node.props[k]);
      if (node.required && node.required.size) schema.required = [...node.required].sort();
      schema.additionalProperties = false;
    }
    if (node.types.has("array") && node.items) {
      schema.items = nodeToSchema(node.items);
    }
    if (types.every((t) => t === "string" || t === "integer" || t === "number" || t === "boolean")) {
      if (node.values.size > 0 && node.values.size <= MAX_ENUM) {
        schema.enum = [...node.values];
      }
    }
    return schema;
  }

  function groupKey(r) {
    return `${r.method} ${r.host}${r.pathname}`;
  }

  function inferAll(requests) {
    const groups = new Map();
    for (const r of requests) {
      if (!r || !r.resBody) continue;
      const parsed = tryParseJson(r.resBody);
      if (parsed === undefined) continue;
      const key = groupKey(r);
      let g = groups.get(key);
      if (!g) { g = { key, samples: 0, node: null, sample: parsed }; groups.set(key, g); }
      if (g.samples >= MAX_SAMPLES_PER_GROUP) continue;
      g.node = mergeNode(g.node, parsed);
      g.samples++;
    }
    const out = [];
    for (const g of groups.values()) {
      out.push({
        key: g.key,
        samples: g.samples,
        schema: {
          $schema: "https://json-schema.org/draft/2020-12/schema",
          title: g.key,
          ...nodeToSchema(g.node),
        },
      });
    }
    return out;
  }

  const SCRIPT = {
    id: 14,
    slug: "response-schema",
    name: "Response Schema",
    description: "Infere JSON Schema (Draft 2020-12) a partir dos response bodies, agrupado por endpoint.",
    icon: "🧬",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      const groups = inferAll(ctx.requests);
      if (!groups.length) {
        return { ok: false, error: "Nenhuma response JSON válida encontrada." };
      }

      const bundle = {
        generatedAt: new Date().toISOString(),
        totalGroups: groups.length,
        schemas: groups.map((g) => ({ endpoint: g.key, samples: g.samples, schema: g.schema })),
      };
      const json = JSON.stringify(bundle, null, 2);
      const filename = `hyper-rb-schemas-${Date.now()}.json`;

      return {
        ok: true,
        summary: `${groups.length} schema(s) inferido(s)`,
        artifact: { filename, mime: "application/json", content: json },
        render(mountEl) {
          const rows = groups.map((g, i) => `
            <tr>
              <td>${S.escapeHtml(g.key)}</td>
              <td style="text-align:right">${g.samples}</td>
              <td><button class="hyper-rb-btn show-schema" data-idx="${i}">Ver schema</button></td>
            </tr>
          `).join("");

          mountEl.innerHTML = `
            <div class="hyper-rb-section">
              <div class="hyper-rb-section-head">
                <div>
                  <div class="hyper-rb-section-title">Response Schema</div>
                  <div class="hyper-rb-section-sub">
                    ${S.escapeHtml(groups.length)} endpoint(s) com response JSON.
                    Enum inferido quando ≤ ${MAX_ENUM} valores distintos.
                  </div>
                </div>
                <button class="hyper-rb-btn hyper-rb-btn-primary dl-schemas">⬇ Baixar schemas.json</button>
              </div>
              <table class="hyper-rb-table">
                <thead><tr><th>Endpoint</th><th style="text-align:right">Samples</th><th></th></tr></thead>
                <tbody>${rows}</tbody>
              </table>
              <pre class="hyper-rb-pre schema-preview" style="max-height:360px;overflow:auto;display:none"><code></code></pre>
            </div>
          `;

          const pre = mountEl.querySelector(".schema-preview");
          const code = pre?.querySelector("code");
          mountEl.querySelectorAll(".show-schema").forEach((btn) => {
            btn.addEventListener("click", () => {
              const idx = Number(btn.getAttribute("data-idx"));
              const g = groups[idx];
              if (!g || !pre || !code) return;
              code.textContent = JSON.stringify(g.schema, null, 2);
              pre.style.display = "block";
              pre.scrollIntoView({ behavior: "smooth", block: "nearest" });
            });
          });
          mountEl.querySelector(".dl-schemas")?.addEventListener("click", () => {
            S.downloadBlob(filename, "application/json", json);
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();