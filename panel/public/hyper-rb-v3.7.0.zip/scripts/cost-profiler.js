// ============================================================
// Hyper RB · Script #5 · cost-profiler
// Perfil de Custo/Latência — agrupa requests por endpoint canônico,
// calcula bytes, latência (avg/p50/p95/p99) e tokens estimados.
// Renderiza 3 charts SVG inline + tabela completa + export CSV.
// Sem IA, sem rede.
// ============================================================
(function registerCostProfiler() {
  "use strict";
  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · cost-profiler] HYPER_RB_SHARED ausente");
    return;
  }

  // ---------- helpers ----------
  const UUID_RE = /^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
  const HEXID_RE = /^[0-9a-f]{12,}$/i;
  const NUMID_RE = /^\d+$/;

  function normSeg(seg) {
    if (!seg) return seg;
    if (UUID_RE.test(seg)) return "{uuid}";
    if (HEXID_RE.test(seg)) return "{hexid}";
    if (NUMID_RE.test(seg)) return "{id}";
    return seg;
  }

  function pathTemplate(pathname) {
    if (!pathname || pathname === "/") return "/";
    return "/" + pathname.split("/").filter(Boolean).map(normSeg).join("/");
  }

  function percentile(sortedArr, p) {
    if (!sortedArr.length) return 0;
    const idx = Math.min(sortedArr.length - 1, Math.floor((p / 100) * sortedArr.length));
    return sortedArr[idx];
  }

  function bodyLen(s) {
    if (!s) return 0;
    return typeof s === "string" ? s.length : 0;
  }

  // CSV escape: wrap in quotes, double inner quotes
  function csvCell(v) {
    const s = String(v ?? "");
    if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  // ---------- core ----------
  function buildProfile(requests) {
    const groups = new Map();
    for (const r of requests) {
      if (!r || !r.host) continue;
      const key = `${r.host}|${(r.method || "GET").toUpperCase()}|${pathTemplate(r.pathname || "/")}`;
      let g = groups.get(key);
      if (!g) {
        g = {
          key,
          host: r.host,
          method: (r.method || "GET").toUpperCase(),
          pathTemplate: pathTemplate(r.pathname || "/"),
          count: 0,
          totalReqBytes: 0,
          totalResBytes: 0,
          totalBytes: 0,
          totalChars: 0,
          latencies: [],
          statuses: new Set(),
        };
        groups.set(key, g);
      }
      const reqB = bodyLen(r.reqBody);
      const resB = bodyLen(r.resBody);
      g.count++;
      g.totalReqBytes += reqB;
      g.totalResBytes += resB;
      g.totalBytes += reqB + resB;
      g.totalChars += reqB + resB;
      if (typeof r.durationMs === "number" && isFinite(r.durationMs)) {
        g.latencies.push(r.durationMs);
      }
      if (typeof r.status === "number") g.statuses.add(r.status);
    }

    const rows = [];
    for (const g of groups.values()) {
      const lats = g.latencies.slice().sort((a, b) => a - b);
      const sum = lats.reduce((a, b) => a + b, 0);
      rows.push({
        host: g.host,
        method: g.method,
        pathTemplate: g.pathTemplate,
        count: g.count,
        totalBytes: g.totalBytes,
        avgBytes: Math.round(g.totalBytes / g.count),
        totalMs: Math.round(sum),
        avgMs: lats.length ? Math.round(sum / lats.length) : 0,
        p50Ms: Math.round(percentile(lats, 50)),
        p95Ms: Math.round(percentile(lats, 95)),
        p99Ms: Math.round(percentile(lats, 99)),
        estTokens: Math.ceil(g.totalChars / 4),
        statuses: Array.from(g.statuses).sort((a, b) => a - b).join(","),
      });
    }
    return rows;
  }

  // ---------- rendering ----------
  function svgBarChart(title, items, valueKey, formatter, color) {
    // items already sorted desc, top 10
    const W = 320, H = 220, padL = 140, padR = 12, padT = 28, padB = 12;
    const max = items.reduce((m, it) => Math.max(m, it[valueKey]), 0) || 1;
    const innerW = W - padL - padR;
    const rowH = items.length ? (H - padT - padB) / items.length : 0;
    const barH = Math.max(6, rowH - 4);

    let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet" style="display:block">`;
    svg += `<text x="8" y="18" fill="rgba(255,255,255,0.75)" font-size="11" font-weight="800" style="text-transform:uppercase;letter-spacing:0.08em">${S.escapeHtml(title)}</text>`;

    items.forEach((it, i) => {
      const y = padT + i * rowH;
      const w = Math.max(2, (it[valueKey] / max) * innerW);
      const label = `${it.method} ${it.pathTemplate}`;
      const truncLabel = label.length > 22 ? label.slice(0, 21) + "…" : label;
      svg += `<text x="${padL - 6}" y="${y + barH / 2 + 3}" fill="rgba(255,255,255,0.55)" font-size="9" text-anchor="end" font-family="ui-monospace,SFMono-Regular,monospace">${S.escapeHtml(truncLabel)}</text>`;
      svg += `<rect x="${padL}" y="${y + 2}" width="${w}" height="${barH}" fill="${color}" rx="2" opacity="0.85"><title>${S.escapeHtml(label)} — ${S.escapeHtml(formatter(it[valueKey]))}</title></rect>`;
      svg += `<text x="${padL + w + 4}" y="${y + barH / 2 + 3}" fill="rgba(255,255,255,0.7)" font-size="9" font-family="ui-monospace,SFMono-Regular,monospace">${S.escapeHtml(formatter(it[valueKey]))}</text>`;
    });
    svg += `</svg>`;
    return svg;
  }

  function buildHTML(rows) {
    if (!rows.length) {
      return `<div class="hyper-rb-error" style="padding:16px;color:rgba(255,255,255,0.7)">Nenhum endpoint agrupado encontrado.</div>`;
    }
    const topBytes = rows.slice().sort((a, b) => b.totalBytes - a.totalBytes).slice(0, 10);
    const topMs = rows.slice().sort((a, b) => b.totalMs - a.totalMs).slice(0, 10);
    const topTokens = rows.slice().sort((a, b) => b.estTokens - a.estTokens).slice(0, 10);

    const tableRows = rows
      .slice()
      .sort((a, b) => b.totalBytes - a.totalBytes)
      .map((r) => `
        <tr>
          <td style="padding:6px 8px;font-family:ui-monospace,monospace;font-size:10px;color:rgba(255,255,255,0.5)">${S.escapeHtml(r.host)}</td>
          <td style="padding:6px 8px;font-weight:800;font-size:10px;color:#bf00ff">${S.escapeHtml(r.method)}</td>
          <td style="padding:6px 8px;font-family:ui-monospace,monospace;font-size:10px;color:rgba(255,255,255,0.85)">${S.escapeHtml(r.pathTemplate)}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px">${r.count}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;font-family:ui-monospace,monospace">${S.escapeHtml(S.formatBytes(r.totalBytes))}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;font-family:ui-monospace,monospace">${S.escapeHtml(S.formatMs(r.avgMs))}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;font-family:ui-monospace,monospace">${S.escapeHtml(S.formatMs(r.p95Ms))}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;font-family:ui-monospace,monospace">${S.escapeHtml(S.formatMs(r.p99Ms))}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;font-family:ui-monospace,monospace">${r.estTokens.toLocaleString()}</td>
          <td style="padding:6px 8px;text-align:right;font-size:10px;color:rgba(255,255,255,0.5)">${S.escapeHtml(r.statuses)}</td>
        </tr>
      `).join("");

    return `
      <div style="display:flex;flex-direction:column;gap:16px;padding:12px">
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <button class="dl-csv" style="padding:8px 14px;border-radius:10px;background:rgba(191,0,255,0.15);border:1px solid rgba(191,0,255,0.35);color:#fff;font-weight:800;font-size:10px;letter-spacing:0.08em;text-transform:uppercase;cursor:pointer">Baixar CSV</button>
          <span style="font-size:10px;color:rgba(255,255,255,0.45);font-weight:700;text-transform:uppercase;letter-spacing:0.08em">${rows.length} endpoints agrupados</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px">
          <div style="background:rgba(18,18,20,0.7);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.06);border-radius:12px;padding:8px">${svgBarChart("Top 10 · Bytes", topBytes, "totalBytes", (v) => S.formatBytes(v), "#bf00ff")}</div>
          <div style="background:rgba(18,18,20,0.7);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.06);border-radius:12px;padding:8px">${svgBarChart("Top 10 · Tempo Total", topMs, "totalMs", (v) => S.formatMs(v), "#7a00cc")}</div>
          <div style="background:rgba(18,18,20,0.7);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.06);border-radius:12px;padding:8px">${svgBarChart("Top 10 · Tokens (est)", topTokens, "estTokens", (v) => v.toLocaleString(), "#4a0080")}</div>
        </div>
        <div style="background:rgba(18,18,20,0.7);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.06);border-radius:12px;overflow:auto;max-height:420px">
          <table style="width:100%;border-collapse:collapse;font-size:10px">
            <thead style="position:sticky;top:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px)">
              <tr style="text-align:left">
                <th style="padding:8px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Host</th>
                <th style="padding:8px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Method</th>
                <th style="padding:8px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Path</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Count</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Bytes</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Avg</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">P95</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">P99</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Tokens</th>
                <th style="padding:8px;text-align:right;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:0.08em;color:rgba(255,255,255,0.5)">Status</th>
              </tr>
            </thead>
            <tbody>${tableRows}</tbody>
          </table>
        </div>
      </div>
    `;
  }

  function buildCSV(rows) {
    const header = ["host", "method", "pathTemplate", "count", "totalBytes", "avgBytes", "totalMs", "avgMs", "p50Ms", "p95Ms", "p99Ms", "estTokens", "statuses"];
    const lines = [header.join(",")];
    for (const r of rows) {
      lines.push(header.map((k) => csvCell(r[k])).join(","));
    }
    return lines.join("\r\n");
  }

  // ---------- script contract ----------
  const SCRIPT = {
    id: 5,
    slug: "cost-profiler",
    name: "Perfil Custo/Latência",
    description: "Bytes, latência (avg/p95/p99) e tokens estimados por endpoint.",
    icon: "💸",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      if (!ctx || !ctx.requests || !ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes." };
      }
      const rows = buildProfile(ctx.requests);
      if (!rows.length) {
        return { ok: false, error: "Nenhum endpoint válido (faltam hosts)." };
      }
      const totalBytes = rows.reduce((a, b) => a + b.totalBytes, 0);
      const totalMs = rows.reduce((a, b) => a + b.totalMs, 0);
      const totalTokens = rows.reduce((a, b) => a + b.estTokens, 0);
      const csv = buildCSV(rows);

      return {
        ok: true,
        summary: `${rows.length} endpoints · ${S.formatBytes(totalBytes)} · ${S.formatMs(totalMs)} · ~${totalTokens.toLocaleString()} tokens`,
        render(mountEl) {
          mountEl.innerHTML = buildHTML(rows);
          const csvBtn = mountEl.querySelector(".dl-csv");
          if (csvBtn) {
            csvBtn.addEventListener("click", () => {
              S.downloadBlob("hyper-rb-cost-profile.csv", "text/csv;charset=utf-8", csv);
            });
          }
        },
        artifact: { filename: "hyper-rb-cost-profile.csv", mime: "text/csv", content: csv },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();