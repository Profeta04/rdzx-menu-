(() => {
  const state = {
    data: null,
    selectedRequestId: null,
    detailTab: "overview",
    page: 1,
    pageSize: 50,
    filters: {
      method: "ALL",
      type: "ALL",
      search: "",
    },
    composer: {
      method: "GET",
      url: "https://api.lovable.dev/v1/projects",
      body: "",
    },
  };

  let heartbeatTimer = null;
  const app = document.getElementById("app");

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function sendMessage(type, payload) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type, payload }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve(response || { ok: false, error: "Sem resposta" });
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  function formatBytes(bytes) {
    const value = Number(bytes || 0);
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(2)} MB`;
  }

  function formatMs(ms) {
    return `${Math.max(0, Number(ms || 0))} ms`;
  }

  function formatDate(value) {
    if (!value) return "—";
    try {
      return new Date(value).toLocaleString("pt-BR");
    } catch {
      return String(value);
    }
  }

  function methodClass(method) {
    return `method-${String(method || "GET").toUpperCase()}`;
  }

  function statusClass(status) {
    return Number(status) >= 400 || Number(status) === 0 ? "status-error" : "status-ok";
  }

  function getDiagBadgeClass(status) {
    if (status === "ready") return "badge-ready";
    if (status === "error") return "badge-error";
    return "badge-waiting";
  }

  function parseJsonSafe(value) {
    if (!value) return null;
    if (typeof value === "object") return value;
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }

  function formatCodeBlock(value) {
    if (value === undefined || value === null || value === "") return "// vazio";
    if (typeof value === "string") return value;
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  function buildJsonTree(value) {
    if (value === null) return '<span class="json-value-null">null</span>';
    if (typeof value === "string") return `<span class="json-value-string">"${escapeHtml(value)}"</span>`;
    if (typeof value === "number") return `<span class="json-value-number">${value}</span>`;
    if (typeof value === "boolean") return `<span class="json-value-boolean">${value}</span>`;
    if (Array.isArray(value)) {
      return `<div class="json-tree">${value.map((item, index) => `<div class="json-node"><span class="json-key">[${index}]</span>: ${buildJsonTree(item)}</div>`).join("")}</div>`;
    }
    return `<div class="json-tree">${Object.entries(value).map(([key, item]) => `<div class="json-node"><span class="json-key">${escapeHtml(key)}</span>: ${buildJsonTree(item)}</div>`).join("")}</div>`;
  }

  function filteredRequests() {
    const entries = state.data?.network || [];
    return entries.filter((entry) => {
      const searchTarget = [
        entry.url,
        entry.method,
        entry.requestBody,
        entry.responseBody,
        JSON.stringify(entry.requestHeaders || {}),
        JSON.stringify(entry.responseHeaders || {}),
      ].join(" ").toLowerCase();
      const matchesSearch = !state.filters.search || searchTarget.includes(state.filters.search.toLowerCase());
      const matchesMethod = state.filters.method === "ALL" || String(entry.method).toUpperCase() === state.filters.method;
      const matchesType = state.filters.type === "ALL" || String(entry.kind).toLowerCase() === state.filters.type.toLowerCase();
      return matchesSearch && matchesMethod && matchesType;
    });
  }

  function pagedRequests() {
    const items = filteredRequests();
    const start = (state.page - 1) * state.pageSize;
    return items.slice(start, start + state.pageSize);
  }

  function selectedRequest() {
    const items = state.data?.network || [];
    return items.find((entry) => entry.id === state.selectedRequestId) || pagedRequests()[0] || null;
  }

  function loadEntryIntoComposer(entry) {
    if (!entry) return;
    state.composer.method = String(entry.method || "GET").toUpperCase();
    state.composer.url = entry.url || "";
    let body = entry.requestBody;
    if (body && typeof body !== "string") {
      try { body = JSON.stringify(body, null, 2); } catch { body = String(body); }
    }
    state.composer.body = body || "";
  }

  function copyText(text) {
    navigator.clipboard.writeText(text).catch(() => {});
  }

  function renderOverview(entry) {
    return `
      <div class="section-card">
        <div class="section-label">Resumo</div>
        <div class="key-value-grid">
          <div class="kv-row"><div class="kv-key">URL</div><div class="mono">${escapeHtml(entry.url)}</div></div>
          <div class="kv-row"><div class="kv-key">Origem</div><div>${escapeHtml(entry.source || "page")}</div></div>
          <div class="kv-row"><div class="kv-key">Tipo</div><div>${escapeHtml(entry.kind || "fetch")}</div></div>
          <div class="kv-row"><div class="kv-key">Status</div><div class="${statusClass(entry.status)}">${escapeHtml(entry.status || 0)} ${escapeHtml(entry.statusText || "")}</div></div>
          <div class="kv-row"><div class="kv-key">Tempo</div><div>${formatMs(entry.timingMs)}</div></div>
          <div class="kv-row"><div class="kv-key">Tamanho</div><div>${formatBytes(entry.responseSize)}</div></div>
          <div class="kv-row"><div class="kv-key">Capturada em</div><div>${formatDate(entry.startedAt)}</div></div>
        </div>
      </div>
      <div class="section-card">
        <div class="section-label">Auth reutilizada</div>
        <div class="key-value-grid">
          <div class="kv-row"><div class="kv-key">Bearer</div><div>${entry.auth?.hasBearerToken ? escapeHtml(entry.auth.tokenPreview || "capturado") : "Não capturado"}</div></div>
          <div class="kv-row"><div class="kv-key">Cookies</div><div>${escapeHtml(entry.auth?.cookiesPreview || "Não capturados")}</div></div>
          <div class="kv-row"><div class="kv-key">Project ID</div><div class="mono">${escapeHtml(entry.auth?.projectId || "—")}</div></div>
          <div class="kv-row"><div class="kv-key">Workspace ID</div><div class="mono">${escapeHtml(entry.auth?.workspaceId || "—")}</div></div>
        </div>
      </div>
    `;
  }

  function renderRequestTab(entry) {
    return `
      <div class="section-card">
        <div class="section-label">Headers</div>
        <pre>${escapeHtml(formatCodeBlock(entry.requestHeaders || {}))}</pre>
      </div>
      <div class="section-card">
        <div class="section-label">Body</div>
        <pre>${escapeHtml(formatCodeBlock(entry.requestBody))}</pre>
      </div>
    `;
  }

  function renderResponseTab(entry) {
    const parsed = entry.responseJson || parseJsonSafe(entry.responseBody);
    return `
      <div class="section-card">
        <div class="section-label">Headers</div>
        <pre>${escapeHtml(formatCodeBlock(entry.responseHeaders || {}))}</pre>
      </div>
      <div class="section-card">
        <div class="section-label">Preview JSON</div>
        ${parsed ? buildJsonTree(parsed) : `<pre>${escapeHtml(formatCodeBlock(entry.responseBody))}</pre>`}
      </div>
      <div class="section-card">
        <div class="section-label">Response bruta</div>
        <pre>${escapeHtml(formatCodeBlock(entry.responseBody))}</pre>
      </div>
    `;
  }

  function renderTimingTab(entry) {
    return `
      <div class="section-card">
        <div class="section-label">Timing</div>
        <div class="key-value-grid">
          <div class="kv-row"><div class="kv-key">Tempo total</div><div>${formatMs(entry.timingMs)}</div></div>
          <div class="kv-row"><div class="kv-key">Início</div><div>${formatDate(entry.startedAt)}</div></div>
          <div class="kv-row"><div class="kv-key">Status</div><div>${escapeHtml(entry.status || 0)}</div></div>
          <div class="kv-row"><div class="kv-key">Tamanho</div><div>${formatBytes(entry.responseSize)}</div></div>
          <div class="kv-row"><div class="kv-key">Erro</div><div>${escapeHtml(entry.error || "—")}</div></div>
        </div>
      </div>
    `;
  }

  function renderDetailContent(entry) {
    if (!entry) {
      return `
        <div class="empty-state">
          <div class="empty-title">Nenhuma request selecionada</div>
          <div class="empty-body">Capture tráfego da Lovable em tempo real ou execute uma request manual para abrir o inspetor.</div>
        </div>
      `;
    }
    if (state.detailTab === "request") return renderRequestTab(entry);
    if (state.detailTab === "response") return renderResponseTab(entry);
    if (state.detailTab === "timing") return renderTimingTab(entry);
    return renderOverview(entry);
  }

  function buildFetchSnippet(entry) {
    return `fetch(${JSON.stringify(entry.url)}, ${JSON.stringify({
      method: entry.method,
      headers: entry.requestHeaders || {},
      body: entry.requestBody || undefined,
    }, null, 2)})`;
  }

  function buildCurlSnippet(entry) {
    const headers = Object.entries(entry.requestHeaders || {}).map(([key, value]) => `-H ${JSON.stringify(`${key}: ${value}`)}`).join(" ");
    const body = entry.requestBody ? ` --data ${JSON.stringify(entry.requestBody)}` : "";
    return `curl -X ${entry.method} ${headers}${body} ${JSON.stringify(entry.url)}`;
  }

  function bindEvents() {
    document.querySelectorAll("[data-method-filter]").forEach((button) => {
      button.addEventListener("click", () => {
        state.filters.method = button.getAttribute("data-method-filter") || "ALL";
        state.page = 1;
        render();
      });
    });

    const typeSelect = document.getElementById("filter-type");
    const searchInput = document.getElementById("filter-search");
    const requestUrl = document.getElementById("request-url");
    const requestMethod = document.getElementById("request-method");
    const requestBody = document.getElementById("request-body");
    const clearButton = document.getElementById("clear-network");
    const debugToggle = document.getElementById("debug-toggle");
    const licenseForm = document.getElementById("license-form");
    const replayButton = document.getElementById("execute-request");
    const prevPage = document.getElementById("page-prev");
    const nextPage = document.getElementById("page-next");
    const refreshState = document.getElementById("refresh-state");

    if (typeSelect) {
      typeSelect.addEventListener("change", () => {
        state.filters.type = typeSelect.value;
        state.page = 1;
        render();
      });
    }
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        state.filters.search = searchInput.value;
        state.page = 1;
        render();
      });
    }
    if (clearButton) {
      clearButton.addEventListener("click", async () => {
        await sendMessage("BURP_CLEAR_NETWORK");
        await refresh();
      });
    }
    if (refreshState) {
      refreshState.addEventListener("click", refresh);
    }
    if (debugToggle) {
      debugToggle.addEventListener("click", async () => {
        const response = await sendMessage("BURP_SET_DEBUG", { enabled: !state.data?.debug });
        state.data = response.state;
        render();
      });
    }
    if (requestUrl) {
      requestUrl.addEventListener("input", () => { state.composer.url = requestUrl.value; });
    }
    if (requestMethod) {
      requestMethod.addEventListener("change", () => { state.composer.method = requestMethod.value; });
    }
    if (requestBody) {
      requestBody.addEventListener("input", () => { state.composer.body = requestBody.value; });
    }

    if (replayButton) {
      replayButton.addEventListener("click", async () => {
        const responseBox = document.getElementById("composer-status");
        replayButton.disabled = true;
        responseBox.textContent = "Enviando request via edge function Burp...";
        let bodyPayload = null;
        if (requestBody.value.trim()) {
          try {
            bodyPayload = JSON.parse(requestBody.value);
          } catch {
            bodyPayload = requestBody.value;
          }
        }
        const response = await sendMessage("BURP_EXECUTE_REQUEST", {
          url: requestUrl.value.trim(),
          method: requestMethod.value,
          headers: {},
          body: bodyPayload,
        });
        replayButton.disabled = false;
        if (!response.ok) {
          responseBox.textContent = response.error || "Falha ao executar request.";
          return;
        }
        responseBox.textContent = "Request enviada com sucesso.";
        state.data = response.state;
        state.selectedRequestId = response.result.id;
        render();
      });
    }
    if (prevPage) {
      prevPage.addEventListener("click", () => {
        state.page = Math.max(1, state.page - 1);
        render();
      });
    }
    if (nextPage) {
      nextPage.addEventListener("click", () => {
        const totalPages = Math.max(1, Math.ceil(filteredRequests().length / state.pageSize));
        state.page = Math.min(totalPages, state.page + 1);
        render();
      });
    }

    document.querySelectorAll("[data-request-id]").forEach((item) => {
      item.addEventListener("click", () => {
        state.selectedRequestId = item.getAttribute("data-request-id");
        loadEntryIntoComposer(selectedRequest());
        render();
      });
    });

    document.querySelectorAll("[data-detail-tab]").forEach((tab) => {
      tab.addEventListener("click", () => {
        state.detailTab = tab.getAttribute("data-detail-tab") || "overview";
        render();
      });
    });

    document.querySelectorAll("[data-copy]").forEach((button) => {
      button.addEventListener("click", () => {
        const entry = selectedRequest();
        if (!entry) return;
        const action = button.getAttribute("data-copy");
        if (action === "request") {
          loadEntryIntoComposer(entry);
          copyText(JSON.stringify({ method: entry.method, url: entry.url, body: entry.requestBody }, null, 2));
          const status = document.getElementById("composer-status");
          if (status) status.textContent = "Request carregada no composer. Pronta para reenvio.";
          render();
          return;
        }
        if (action === "payload") copyText(formatCodeBlock(entry.requestBody));
        if (action === "headers") copyText(formatCodeBlock(entry.requestHeaders));
        if (action === "response") copyText(formatCodeBlock(entry.responseBody));
        if (action === "fetch") copyText(buildFetchSnippet(entry));
        if (action === "curl") copyText(buildCurlSnippet(entry));
        if (action === "json") copyText(formatCodeBlock(entry.responseJson || parseJsonSafe(entry.responseBody) || entry.requestBody));
      });
    });

    const handle = document.getElementById("resize-handle");
    const grid = document.getElementById("network-grid");
    if (handle && grid && window.innerWidth > 960) {
      let dragging = false;
      handle.addEventListener("mousedown", () => { dragging = true; });
      window.addEventListener("mouseup", () => { dragging = false; });
      window.addEventListener("mousemove", (event) => {
        if (!dragging) return;
        const rect = grid.getBoundingClientRect();
        const width = ((event.clientX - rect.left) / rect.width) * 100;
        const clamped = Math.max(28, Math.min(60, width));
        document.documentElement.style.setProperty("--list-width", `${clamped}%`);
      });
    }
  }

  function render() {
    const data = state.data;
    const entries = pagedRequests();
    const total = filteredRequests().length;
    const totalPages = Math.max(1, Math.ceil(total / state.pageSize));
    const entry = selectedRequest();
    if (!state.selectedRequestId && entry) state.selectedRequestId = entry.id;

    app.innerHTML = `
      <div class="app-shell">
        <div class="topbar">
          <div class="brand-wrap">
            <div class="brand-mark">B</div>
            <div>
              <div class="brand-title">Burp Lovable</div>
              <div class="brand-subtitle">Network live · replay engine · startup diagnostics</div>
            </div>
          </div>
          <div class="toolbar-actions">
            <button class="ghost-btn" id="refresh-state">Atualizar</button>
            <button class="ghost-btn" id="debug-toggle">${data?.debug ? "Debug on" : "Debug off"}</button>
          </div>
        </div>

        <div class="status-strip">
          <div class="status-card">
            <div class="status-label">Autenticação</div>
            <div class="status-value">${data?.auth?.hasBearerToken ? "Token capturado" : "Sem token"}</div>
            <div class="status-meta mono">${escapeHtml(data?.auth?.bearerTokenPreview || "—")}</div>
          </div>
          <div class="status-card">
            <div class="status-label">Requests</div>
            <div class="status-value">${data?.stats?.entryCount || 0}</div>
            <div class="status-meta">Captura em tempo real</div>
          </div>
          <div class="status-card">
            <div class="status-label">Projeto</div>
            <div class="status-value mono">${escapeHtml(data?.auth?.projectId || "—")}</div>
            <div class="status-meta mono">${escapeHtml(data?.auth?.workspaceId || "—")}</div>
          </div>
        </div>

        <div class="diagnostics-grid">
          ${Object.entries(data?.diagnostics || {}).map(([key, diag]) => `
            <div class="diag-card">
              <div class="diag-top">
                <div class="diag-title">${escapeHtml(key)}</div>
                <span class="badge ${getDiagBadgeClass(diag.status)}">${escapeHtml(diag.status)}</span>
              </div>
              <div class="diag-detail">${escapeHtml(diag.detail || "—")}</div>
            </div>
          `).join("")}
        </div>


        ${data?.debug ? `
          <div class="debug-panel">
            <h2>Startup diagnostics</h2>
            <p>Logs internos sanitizados da inicialização e dos módulos do service worker/content/page hook.</p>
            <div class="debug-log-list">
              ${(data?.startupLogs || []).slice(0, 12).map((log) => `
                <div class="debug-log-item">
                  <div class="debug-log-head">
                    <span class="badge ${log.level === "error" ? "badge-error" : log.level === "warn" ? "badge-waiting" : "badge-live"}">${escapeHtml(log.level)}</span>
                    <span class="mono">${escapeHtml(formatDate(log.timestamp))}</span>
                  </div>
                  <div class="debug-log-message">${escapeHtml(log.module)} · ${escapeHtml(log.message)}</div>
                  ${log.meta ? `<div class="debug-log-meta mono">${escapeHtml(JSON.stringify(log.meta))}</div>` : ""}
                </div>
              `).join("") || `<div class="debug-log-item">Sem logs ainda.</div>`}
            </div>
          </div>
        ` : ""}

        <div class="workspace">
          <div class="network-toolbar">
            <input id="filter-search" class="search-input" placeholder="Buscar por URL, método, body ou header" value="${escapeHtml(state.filters.search)}">
            <button class="chip-btn" data-method-filter="ALL">ALL</button>
            <button class="chip-btn" data-method-filter="GET">GET</button>
            <button class="chip-btn" data-method-filter="POST">POST</button>
            <button class="chip-btn" data-method-filter="PUT">PUT</button>
            <button class="chip-btn" data-method-filter="DELETE">DELETE</button>
            <select id="filter-type" class="panel-select">
              <option value="ALL" ${state.filters.type === "ALL" ? "selected" : ""}>Todos</option>
              <option value="fetch" ${state.filters.type === "fetch" ? "selected" : ""}>Fetch/XHR</option>
              <option value="graphql" ${state.filters.type === "graphql" ? "selected" : ""}>GraphQL</option>
              <option value="xhr" ${state.filters.type === "xhr" ? "selected" : ""}>XHR</option>
            </select>
            <button class="ghost-btn" id="clear-network">Limpar</button>
          </div>

          <div class="composer">
            <select id="request-method" class="panel-select">
              ${["GET", "POST", "PUT", "PATCH", "DELETE"].map((method) => `<option value="${method}" ${state.composer.method === method ? "selected" : ""}>${method}</option>`).join("")}
            </select>
            <input id="request-url" class="text-input mono" placeholder="https://api.lovable.dev/v1/projects" value="${escapeHtml(state.composer.url)}">
            <div class="composer-stack">
              <textarea id="request-body" class="panel-textarea mono" placeholder='{"payload": true}'>${escapeHtml(state.composer.body)}</textarea>
            </div>
            <div class="composer-stack">
              <button class="primary-btn" id="execute-request">Enviar</button>
              <div id="composer-status" class="hint-text">Headers, bearer token e cookies são gerenciados automaticamente pela extensão.</div>
            </div>
          </div>

          <div class="network-grid" id="network-grid">
            <div class="request-list">
              ${entries.length ? entries.map((item) => `
                <div class="request-item ${item.id === state.selectedRequestId ? "active" : ""}" data-request-id="${escapeHtml(item.id)}">
                  <div class="request-top">
                    <span class="method-pill ${methodClass(item.method)}">${escapeHtml(item.method)}</span>
                    <span class="status-code ${statusClass(item.status)}">${escapeHtml(item.status || 0)}</span>
                  </div>
                  <div class="request-url mono">${escapeHtml(item.url)}</div>
                  <div class="request-bottom">
                    <div class="request-meta">
                      <span>${escapeHtml(item.kind || "fetch")}</span>
                      <span>${formatMs(item.timingMs)}</span>
                      <span>${formatBytes(item.responseSize)}</span>
                    </div>
                    <span class="badge badge-live">live</span>
                  </div>
                </div>
              `).join("") : `
                <div class="empty-state">
                  <div class="empty-title">Nenhuma request capturada</div>
                  <div class="empty-body">Abra a Lovable, navegue ou envie mensagens: o hook intercepta fetch/XHR reais em tempo real.</div>
                </div>
              `}
              <div class="request-list-footer">
                <span>${total} item(ns)</span>
                <div class="toolbar-actions">
                  <button class="ghost-btn" id="page-prev" ${state.page <= 1 ? "disabled" : ""}>Anterior</button>
                  <span>Página ${state.page} / ${totalPages}</span>
                  <button class="ghost-btn" id="page-next" ${state.page >= totalPages ? "disabled" : ""}>Próxima</button>
                </div>
              </div>
            </div>
            <div class="resize-handle" id="resize-handle"></div>
            <div class="detail-pane">
              <div class="detail-header">
                <div>
                  <div class="detail-title mono">${entry ? escapeHtml(entry.url) : "Inspector"}</div>
                  <div class="detail-subtitle">${entry ? `${escapeHtml(entry.method)} · ${escapeHtml(entry.status || 0)} · ${formatMs(entry.timingMs)}` : "Selecione uma request para inspecionar headers, payload, response, cookies e timing."}</div>
                </div>
                <div class="detail-actions">
                  <button class="ghost-btn" data-copy="request">Copy request</button>
                  <button class="ghost-btn" data-copy="payload">Payload</button>
                  <button class="ghost-btn" data-copy="headers">Headers</button>
                  <button class="ghost-btn" data-copy="response">Response</button>
                  <button class="ghost-btn" data-copy="fetch">as fetch()</button>
                  <button class="ghost-btn" data-copy="curl">as curl</button>
                  <button class="ghost-btn" data-copy="json">JSON</button>
                </div>
              </div>
              <div class="tabbar">
                ${["overview", "request", "response", "timing"].map((tab) => `<button class="tab-btn ${state.detailTab === tab ? "active" : ""}" data-detail-tab="${tab}">${tab}</button>`).join("")}
              </div>
              <div class="detail-content">
                ${renderDetailContent(entry)}
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    bindEvents();
  }

  async function refresh() {
    const response = await sendMessage("BURP_GET_STATE");
    if (!response?.ok) throw new Error(response?.error || "Falha ao obter estado");
    state.data = response.state;
    if (state.data) state.data.license = { valid: true, userName: "Acesso Total" };
    if (!state.selectedRequestId && state.data?.network?.[0]) state.selectedRequestId = state.data.network[0].id;
    render();
  }

  function startHeartbeat() {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = setInterval(async () => {
      try {
        await sendMessage("BURP_HEARTBEAT");
      } catch {}
    }, 60000);
  }

  function renderFallback(error) {
    app.innerHTML = `
      <div class="app-shell">
        <div class="fallback-card">
          <div class="fallback-title">Falha ao renderizar o sidepanel</div>
          <div class="fallback-body">${escapeHtml(error?.message || String(error))}</div>
          <button class="primary-btn" id="reload-panel">Recarregar</button>
        </div>
      </div>
    `;
    document.getElementById("reload-panel").addEventListener("click", () => window.location.reload());
  }

  window.addEventListener("error", (event) => renderFallback(event.error || new Error(event.message)));
  window.addEventListener("unhandledrejection", (event) => renderFallback(event.reason || new Error("Unhandled rejection")));
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "BURP_NETWORK_UPDATED" || message?.type === "BURP_AUTH_UPDATED" || message?.type === "BURP_LOG_UPDATED" || message?.type === "BURP_STATE_READY") {
      state.data = message.payload;
      if (!state.selectedRequestId && state.data.network?.[0]) state.selectedRequestId = state.data.network[0].id;
      render();
    }
  });

  refresh().then(startHeartbeat).catch(renderFallback);
})();
