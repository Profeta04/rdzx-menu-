(function registerErrorMiner() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · error-miner] HYPER_RB_SHARED ausente");
    return;
  }

  const EXCERPT_LEN = 300;

  function normalizePath(pathname) {
    if (!pathname || pathname === "/") return "/";
    return "/" + pathname
      .split("/")
      .filter(Boolean)
      .map((seg) => {
        if (/^\d+$/.test(seg)) return "{id}";
        if (/^[0-9a-f-]{8,}$/i.test(seg)) return "{id}";
        return seg;
      })
      .join("/");
  }

  function statusClass(status) {
    if (status >= 500) return "err-5xx";
    if (status >= 400) return "err-4xx";
    return "err-other";
  }

  function buildGroups(requests) {
    const groups = new Map();
    for (const req of requests) {
      const status = Number(req?.status || 0);
      if (!status || status < 400) continue;
      const method = String(req.method || "GET").toUpperCase();
      const host = req.host || "(sem host)";
      const path = normalizePath(req.pathname || "/");
      const key = `${status}|${host}|${method} ${path}`;

      let g = groups.get(key);
      if (!g) {
        g = {
          key, status, host, method, path,
          count: 0,
          firstSeen: req.ts || Date.now(),
          lastSeen: req.ts || Date.now(),
          sampleReq: req,
          bodyExcerpt: String(req.resBody || "").slice(0, EXCERPT_LEN),
        };
        groups.set(key, g);
      }
      g.count++;
      const ts = req.ts || Date.now();
      if (ts < g.firstSeen) g.firstSeen = ts;
      if (ts > g.lastSeen) { g.lastSeen = ts; g.sampleReq = req; }
      if (!g.bodyExcerpt && req.resBody) {
        g.bodyExcerpt = String(req.resBody).slice(0, EXCERPT_LEN);
      }
    }
    return Array.from(groups.values()).sort((a, b) => b.count - a.count);
  }

  function formatTime(ts) {
    try { return new Date(ts).toLocaleTimeString("pt-BR"); } catch { return "—"; }
  }

  function renderMarkdownLite(text) {
    const safe = S.escapeHtml(String(text || ""));
    return safe
      .replace(/```([\s\S]*?)```/g, "<pre>$1</pre>")
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/\n/g, "<br>");
  }

  const SCRIPT = {
    id: 10,
    slug: "error-miner",
    name: "Minerador de Erros",
    description: "Agrupa respostas 4xx/5xx por endpoint e oferece diagnóstico via IA.",
    icon: "⛏️",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      const groups = buildGroups(ctx.requests || []);
      if (!groups.length) {
        return { ok: false, error: "Nenhuma resposta com status ≥ 400 capturada." };
      }

      return {
        ok: true,
        summary: `${groups.length} grupos de erro (${groups.reduce((s, g) => s + g.count, 0)} respostas)`,
        render(mountEl) {
          mountEl.innerHTML = `
            <div class="hyper-rb-error-miner" style="display:flex;flex-direction:column;gap:12px;padding:8px;">
              <div style="display:flex;gap:8px;align-items:center;font-size:13px;opacity:.8;">
                <span>⛏️ ${groups.length} grupos · ${groups.reduce((s, g) => s + g.count, 0)} erros totais</span>
              </div>
              <div class="em-list" style="display:flex;flex-direction:column;gap:8px;"></div>
            </div>
            <style>
              .hyper-rb-error-miner .em-item{background:rgba(18,18,20,.7);backdrop-filter:blur(24px);border:1px solid rgba(191,0,255,.2);border-radius:10px;padding:10px 12px;}
              .hyper-rb-error-miner .em-head{display:flex;gap:8px;align-items:center;cursor:pointer;}
              .hyper-rb-error-miner .em-badge{font-family:monospace;font-weight:700;padding:2px 8px;border-radius:6px;font-size:11px;}
              .hyper-rb-error-miner .err-5xx{background:rgba(255,60,60,.2);color:#ff6b6b;}
              .hyper-rb-error-miner .err-4xx{background:rgba(255,170,0,.18);color:#ffb84d;}
              .hyper-rb-error-miner .err-other{background:rgba(191,0,255,.15);color:#bf00ff;}
              .hyper-rb-error-miner .em-meta{margin-left:auto;font-size:11px;opacity:.65;}
              .hyper-rb-error-miner .em-method{font-family:monospace;font-size:11px;opacity:.8;}
              .hyper-rb-error-miner .em-path{font-family:monospace;font-size:12px;color:#e8e8ec;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
              .hyper-rb-error-miner .em-body{display:none;margin-top:10px;border-top:1px solid rgba(255,255,255,.08);padding-top:10px;font-size:12px;}
              .hyper-rb-error-miner .em-item.open .em-body{display:block;}
              .hyper-rb-error-miner pre{background:rgba(0,0,0,.35);padding:8px;border-radius:6px;overflow:auto;max-height:200px;white-space:pre-wrap;word-break:break-word;font-size:11px;}
              .hyper-rb-error-miner .em-ai-btn{margin-top:8px;background:linear-gradient(135deg,#bf00ff,#7a00cc);color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:12px;}
              .hyper-rb-error-miner .em-ai-btn:disabled{opacity:.5;cursor:not-allowed;}
              .hyper-rb-error-miner .em-ai-out{margin-top:8px;padding:8px;background:rgba(191,0,255,.08);border-left:2px solid #bf00ff;border-radius:4px;font-size:12px;line-height:1.5;}
            </style>
          `;

          const list = mountEl.querySelector(".em-list");
          groups.forEach((g, idx) => {
            const item = document.createElement("div");
            item.className = "em-item";
            item.innerHTML = `
              <div class="em-head" data-idx="${idx}">
                <span class="em-badge ${statusClass(g.status)}">${g.status}</span>
                <span class="em-method">${S.escapeHtml(g.method)}</span>
                <span class="em-path" title="${S.escapeHtml(g.host + g.path)}">${S.escapeHtml(g.host)}${S.escapeHtml(g.path)}</span>
                <span class="em-meta">×${g.count} · ${formatTime(g.lastSeen)}</span>
              </div>
              <div class="em-body">
                <div style="opacity:.7;margin-bottom:6px;">Primeira: ${formatTime(g.firstSeen)} · Última: ${formatTime(g.lastSeen)}</div>
                ${g.bodyExcerpt ? `<pre>${S.escapeHtml(g.bodyExcerpt)}</pre>` : '<div style="opacity:.5;font-style:italic;">(sem corpo de resposta)</div>'}
                <button class="em-ai-btn" data-idx="${idx}">🤖 Diagnosticar com IA</button>
                <div class="em-ai-out" style="display:none;"></div>
              </div>
            `;
            list.appendChild(item);
          });

          list.addEventListener("click", async (e) => {
            const target = e.target;
            if (!(target instanceof HTMLElement)) return;

            const head = target.closest(".em-head");
            if (head && !target.classList.contains("em-ai-btn")) {
              head.parentElement.classList.toggle("open");
              return;
            }

            if (target.classList.contains("em-ai-btn")) {
              const idx = Number(target.getAttribute("data-idx"));
              const g = groups[idx];
              if (!g) return;
              const out = target.nextElementSibling;
              if (!out) return;

              target.disabled = true;
              target.textContent = "Analisando…";
              out.style.display = "block";
              out.innerHTML = '<span style="opacity:.7;">Consultando IA…</span>';

              try {
                const res = await Promise.race([
                  ctx.callAI("diagnose_failed_replay", {
                    request: {
                      method: g.sampleReq.method,
                      url: g.sampleReq.url,
                      reqHeaders: g.sampleReq.reqHeaders,
                      reqBody: g.sampleReq.reqBody,
                    },
                    response: {
                      status: g.status,
                      resHeaders: g.sampleReq.resHeaders,
                      resBody: g.sampleReq.resBody,
                    },
                  }),
                  new Promise((r) => setTimeout(() => r({ ok: false, error: "timeout" }), 20000)),
                ]);

                if (res && res.ok && res.data) {
                  const md = typeof res.data === "string" ? res.data : (res.data.markdown || res.data.text || JSON.stringify(res.data));
                  out.innerHTML = renderMarkdownLite(md);
                } else {
                  const code = res?.error_code || "";
                  const msg = res?.error || "Falha desconhecida";
                  out.innerHTML = `<span style="color:#ff6b6b;">Erro: ${S.escapeHtml(code ? code + " — " : "")}${S.escapeHtml(msg)}</span>`;
                }
              } catch (err) {
                out.innerHTML = `<span style="color:#ff6b6b;">Erro: ${S.escapeHtml(err?.message || String(err))}</span>`;
              } finally {
                target.disabled = false;
                target.textContent = "🤖 Diagnosticar com IA";
              }
            }
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();
