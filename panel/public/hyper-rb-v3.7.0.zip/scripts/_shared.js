// ============================================================
// Hyper RB · Scripts · _shared.js
// Sanitização + utilitários comuns aos 12 scripts.
// Carregado ANTES de qualquer script individual.
// ============================================================
(function () {
  "use strict";

  const REDACTED = "<redacted>";
  const REDACT_HEADERS = new Set([
    "authorization", "cookie", "set-cookie",
    "x-api-key", "x-supabase-auth", "apikey",
    "x-license-key",
  ]);
  // JWT (header.payload.sig)
  const JWT_RE = /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{6,}/g;
  // Lovable tokens (best-effort — long base64ish strings after "lv_" or "lovable_")
  const LOVABLE_TOKEN_RE = /\b(lv_|lovable_)[A-Za-z0-9_-]{16,}/g;
  const MAX_BODY = 16 * 1024;

  function maskString(s) {
    if (typeof s !== "string") return s;
    return s.replace(JWT_RE, "<jwt>").replace(LOVABLE_TOKEN_RE, "<lovable-token>");
  }

  function sanitizeHeaders(h) {
    const out = {};
    if (!h || typeof h !== "object") return out;
    for (const [k, v] of Object.entries(h)) {
      if (REDACT_HEADERS.has(String(k).toLowerCase())) {
        out[k] = REDACTED;
      } else {
        out[k] = typeof v === "string" ? maskString(v) : v;
      }
    }
    return out;
  }

  function truncBody(body) {
    if (body == null) return body;
    const str = typeof body === "string" ? body : (() => {
      try { return JSON.stringify(body); } catch { return String(body); }
    })();
    const masked = maskString(str);
    if (masked.length <= MAX_BODY) return masked;
    return masked.slice(0, MAX_BODY) + `…(+${masked.length - MAX_BODY} bytes)`;
  }

  function parseUrl(u) {
    try {
      const url = new URL(u);
      return { host: url.host, pathname: url.pathname };
    } catch {
      return { host: "", pathname: u || "" };
    }
  }

  /**
   * Convert raw burp_background request entry into the canonical
   * SanitizedRequest shape consumed by every script.
   */
  function sanitize(entry) {
    if (!entry || typeof entry !== "object") return null;
    const { host, pathname } = parseUrl(entry.url || "");
    return {
      id: String(entry.id || entry.requestId || cryptoUuid()),
      ts: Number(entry.ts || entry.startTime || Date.now()),
      method: String(entry.method || "GET").toUpperCase(),
      url: maskString(String(entry.url || "")),
      host, pathname,
      status: typeof entry.status === "number" ? entry.status : undefined,
      durationMs: typeof entry.timingMs === "number" ? entry.timingMs : undefined,
      reqHeaders: sanitizeHeaders(entry.requestHeaders || entry.reqHeaders || {}),
      resHeaders: sanitizeHeaders(entry.responseHeaders || entry.resHeaders || {}),
      reqBody: truncBody(entry.requestBody ?? entry.reqBody),
      resBody: truncBody(entry.responseBody ?? entry.resBody),
      isSSE: String(
        (entry.responseHeaders && (entry.responseHeaders["content-type"] || entry.responseHeaders["Content-Type"])) || ""
      ).toLowerCase().includes("text/event-stream"),
      initiator: entry.initiator || entry.kind || undefined,
    };
  }

  function sanitizeAll(entries) {
    if (!Array.isArray(entries)) return [];
    const out = [];
    for (const e of entries) {
      const s = sanitize(e);
      if (s) out.push(s);
    }
    return out;
  }

  function cryptoUuid() {
    try { return crypto.randomUUID(); }
    catch { return "id-" + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  }

  function formatBytes(n) {
    if (typeof n !== "number" || !isFinite(n)) return "—";
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
    return (n / (1024 * 1024)).toFixed(2) + " MB";
  }

  function formatMs(n) {
    if (typeof n !== "number" || !isFinite(n)) return "—";
    if (n < 1000) return Math.round(n) + " ms";
    return (n / 1000).toFixed(2) + " s";
  }

  function downloadBlob(filename, mime, content) {
    try {
      const blob = content instanceof Blob ? content : new Blob([content], { type: mime || "application/octet-stream" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click();
      requestAnimationFrame(() => { URL.revokeObjectURL(url); a.remove(); });
    } catch (e) {
      console.error("[Hyper RB scripts] downloadBlob falhou:", e);
    }
  }

  /**
   * Mount a side drawer (singleton) and return the inner mount element.
   * The script's render(mountEl) function paints into it.
   */
  function mountDrawer(title) {
    let drawer = document.getElementById("hyper-rb-script-drawer");
    if (!drawer) {
      drawer = document.createElement("div");
      drawer.id = "hyper-rb-script-drawer";
      drawer.className = "hyper-rb-drawer";
      drawer.innerHTML = `
        <div class="hyper-rb-drawer-head">
          <div class="hyper-rb-drawer-title"></div>
          <button class="hyper-rb-drawer-close" aria-label="Fechar">×</button>
        </div>
        <div class="hyper-rb-drawer-body"></div>
      `;
      document.body.appendChild(drawer);
      drawer.querySelector(".hyper-rb-drawer-close").addEventListener("click", () => {
        drawer.classList.remove("open");
      });
    }
    drawer.querySelector(".hyper-rb-drawer-title").textContent = title || "Script";
    const body = drawer.querySelector(".hyper-rb-drawer-body");
    body.innerHTML = "";
    drawer.classList.add("open");
    return body;
  }

  function escapeHtml(v) {
    return String(v ?? "")
      .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;").replaceAll("'", "&#039;");
  }

  // Namespaced chrome.storage.local helper (per-slug)
  function makeStorage(slug) {
    const ns = `ql_script_${slug}_`;
    return {
      async get(key) {
        return new Promise((resolve) => {
          try {
            chrome.storage.local.get([ns + key], (res) => resolve(res?.[ns + key]));
          } catch { resolve(undefined); }
        });
      },
      async set(key, value) {
        return new Promise((resolve) => {
          try {
            chrome.storage.local.set({ [ns + key]: value }, () => resolve());
          } catch { resolve(); }
        });
      },
    };
  }

  window.HYPER_RB_SHARED = {
    sanitize, sanitizeAll, sanitizeHeaders, truncBody,
    formatBytes, formatMs, downloadBlob, mountDrawer,
    escapeHtml, makeStorage, cryptoUuid,
  };
})();
