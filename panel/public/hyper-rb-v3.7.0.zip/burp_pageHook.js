(() => {
      if (window.__BURP_LOVABLE_PAGE__) return;
      window.__BURP_LOVABLE_PAGE__ = true;

      const MAX_BODY_CHARS = 25000;
      const XHR_META = new WeakMap();

      function clamp(value) {
        if (value === undefined || value === null) return null;
        const text = typeof value === "string" ? value : JSON.stringify(value);
        return text.length > MAX_BODY_CHARS ? `${text.slice(0, MAX_BODY_CHARS)}
/* truncated */` : text;
      }

      function serializeHeaders(headers) {
        if (!headers) return {};
        try {
          if (headers instanceof Headers) return Object.fromEntries(headers.entries());
          if (Array.isArray(headers)) return Object.fromEntries(headers);
          return { ...headers };
        } catch {
          return {};
        }
      }

      function detectProjectId(url) {
        const match = String(url || location.href).match(/\/projects\/([0-9a-fA-F-]{36})/i);
        return match ? match[1] : null;
      }

      function getWorkspaceId() {
        try {
          const fromStorage = localStorage.getItem("lovable_workspace_id");
          if (fromStorage) return fromStorage;
        } catch {}
        const match = location.href.match(/[?&]workspace=([a-zA-Z0-9-]+)/);
        return match ? match[1] : null;
      }

      function getBearerToken() {
        try {
          for (let i = 0; i < localStorage.length; i += 1) {
            const key = localStorage.key(i);
            if (!key) continue;
            if (key.startsWith("sb-") && key.endsWith("-auth-token")) {
              const parsed = JSON.parse(localStorage.getItem(key));
              if (parsed?.access_token) return parsed.access_token;
            }
          }
        } catch {}
        return null;
      }

      /**
       * Cookies são sensíveis. Nunca enviamos valores ao background.
       * Apenas a contagem + nomes (sem values) — suficiente para diagnosticar
       * "tem cookie de sessão?" sem permitir replay.
       */
      function getCookieSnapshot() {
        try {
          const raw = document.cookie || "";
          if (!raw) return null;
          const names = raw.split(";").map((c) => c.split("=")[0].trim()).filter(Boolean);
          if (!names.length) return null;
          return `${names.length} cookie(s): ${names.slice(0, 8).join(", ")}${names.length > 8 ? `, +${names.length - 8}` : ""}`;
        } catch {
          return null;
        }
      }

      function post(type, payload) {
        window.postMessage({ source: "BURP_LOVABLE_PAGE", type, payload }, "*");
      }

      function captureAuth(extra) {
        post("AUTH_SNAPSHOT", {
          bearerToken: extra?.bearerToken || getBearerToken(),
          projectId: extra?.projectId || detectProjectId(extra?.url),
          workspaceId: getWorkspaceId(),
          cookies: getCookieSnapshot(),
          source: "page-hook",
        });
      }

      function inferKind(headers, body) {
        const headerMap = serializeHeaders(headers);
        const contentType = String(headerMap["content-type"] || headerMap["Content-Type"] || "").toLowerCase();
        const bodyText = typeof body === "string" ? body : JSON.stringify(body || "");
        if (contentType.includes("graphql") || /(query|mutation)/.test(bodyText)) return "graphql";
        if (contentType.includes("json") || bodyText.startsWith("{")) return "fetch";
        return "xhr";
      }

      function buildRequestBase(method, url, headers, body) {
        const headerMap = serializeHeaders(headers);
        const authHeader = headerMap.Authorization || headerMap.authorization;
        const bearerToken = authHeader && String(authHeader).startsWith("Bearer ") ? String(authHeader).slice(7).trim() : null;
        return {
          id: crypto.randomUUID(),
          method: method || "GET",
          url: String(url || location.href),
          requestHeaders: headerMap,
          requestBody: clamp(body),
          kind: inferKind(headerMap, body),
          source: "page",
          startedAt: new Date().toISOString(),
          projectId: detectProjectId(url),
          bearerToken,
        };
      }

      const originalFetch = window.fetch.bind(window);
      window.fetch = async function patchedFetch(input, init) {
        const request = input instanceof Request ? input : null;
        const url = request ? request.url : String(input);
        const method = request ? request.method : (init?.method || "GET");
        const headers = request ? request.headers : init?.headers;
        const body = init?.body;
        const requestBase = buildRequestBase(method, url, headers, body);
        const started = performance.now();

        try {
          const response = await originalFetch(input, init);
          const clone = response.clone();
          let responseBody = "";
          try {
            responseBody = await clone.text();
          } catch {}
          captureAuth({ bearerToken: requestBase.bearerToken, projectId: requestBase.projectId, url: requestBase.url });
          post("REQUEST_COMPLETED", {
            ...requestBase,
            status: response.status,
            statusText: response.statusText,
            responseHeaders: serializeHeaders(response.headers),
            responseBody: clamp(responseBody),
            responseJson: (() => { try { return JSON.parse(responseBody); } catch { return null; } })(),
            responseSize: responseBody.length,
            timingMs: Math.round(performance.now() - started),
          });
          return response;
        } catch (error) {
          post("REQUEST_FAILED", {
            ...requestBase,
            error: error?.message || String(error),
            timingMs: Math.round(performance.now() - started),
          });
          throw error;
        }
      };

      const originalOpen = XMLHttpRequest.prototype.open;
      const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
      const originalSend = XMLHttpRequest.prototype.send;

      XMLHttpRequest.prototype.open = function patchedOpen(method, url) {
        XHR_META.set(this, {
          method,
          url,
          headers: {},
          started: 0,
          body: null,
        });
        return originalOpen.apply(this, arguments);
      };

      XMLHttpRequest.prototype.setRequestHeader = function patchedSetRequestHeader(name, value) {
        const meta = XHR_META.get(this) || { headers: {} };
        meta.headers[name] = value;
        XHR_META.set(this, meta);
        return originalSetRequestHeader.apply(this, arguments);
      };

      XMLHttpRequest.prototype.send = function patchedSend(body) {
        const meta = XHR_META.get(this) || {};
        meta.started = performance.now();
        meta.body = body;
        XHR_META.set(this, meta);

        this.addEventListener("loadend", () => {
          const requestBase = buildRequestBase(meta.method, meta.url, meta.headers || {}, meta.body);
          captureAuth({ bearerToken: requestBase.bearerToken, projectId: requestBase.projectId, url: requestBase.url });
          post("REQUEST_COMPLETED", {
            ...requestBase,
            kind: inferKind(meta.headers || {}, meta.body),
            status: this.status,
            statusText: this.statusText,
            responseHeaders: {},
            responseBody: clamp(this.responseText || this.response),
            responseJson: (() => { try { return JSON.parse(this.responseText); } catch { return null; } })(),
            responseSize: String(this.responseText || this.response || "").length,
            timingMs: Math.round(performance.now() - meta.started),
          });
        }, { once: true });

        return originalSend.apply(this, arguments);
      };

      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        if (!event.data || event.data.source !== "BURP_LOVABLE_CONTENT") return;
        if (event.data.type === "REQUEST_AUTH_SNAPSHOT") {
          captureAuth();
        }
      });

      // ------------------------------------------------------------
      // WebSocket interception (transparent monkey-patch).
      // Each connection produces:
      //   - WS_OPEN  (status: 101, request entry)
      //   - WS_FRAME (direction: send/recv, payload preview)
      //   - WS_CLOSE (with code/reason and duration)
      // ------------------------------------------------------------
      try {
        const OriginalWebSocket = window.WebSocket;
        if (OriginalWebSocket && !OriginalWebSocket.__hyperRbPatched) {
          const PatchedWebSocket = function(url, protocols) {
            const ws = protocols === undefined ? new OriginalWebSocket(url) : new OriginalWebSocket(url, protocols);
            const connId = crypto.randomUUID();
            const startedAt = new Date().toISOString();
            const startedPerf = performance.now();
            let frameCount = 0;

            post("REQUEST_COMPLETED", {
              id: connId,
              method: "WS",
              url: String(url),
              kind: "ws",
              source: "websocket",
              startedAt,
              status: 101,
              statusText: "Switching Protocols",
              requestHeaders: { Upgrade: "websocket", Protocol: Array.isArray(protocols) ? protocols.join(",") : (protocols || "") },
              requestBody: null,
              responseHeaders: {},
              responseBody: "// WebSocket conectado — frames aparecem como WS_FRAME",
              responseSize: 0,
              timingMs: 0,
              wsState: "open",
            });

            const originalSend = ws.send.bind(ws);
            ws.send = function(data) {
              try {
                frameCount += 1;
                post("WS_FRAME", {
                  connId,
                  direction: "send",
                  url: String(url),
                  payload: clamp(typeof data === "string" ? data : (data instanceof ArrayBuffer ? `[binary ${data.byteLength}b]` : String(data))),
                  timestamp: new Date().toISOString(),
                  frameIndex: frameCount,
                });
              } catch {}
              return originalSend(data);
            };

            ws.addEventListener("message", (ev) => {
              try {
                frameCount += 1;
                const data = ev.data;
                post("WS_FRAME", {
                  connId,
                  direction: "recv",
                  url: String(url),
                  payload: clamp(typeof data === "string" ? data : (data instanceof ArrayBuffer ? `[binary ${data.byteLength}b]` : String(data))),
                  timestamp: new Date().toISOString(),
                  frameIndex: frameCount,
                });
              } catch {}
            });

            ws.addEventListener("close", (ev) => {
              post("WS_FRAME", {
                connId,
                direction: "close",
                url: String(url),
                payload: `close code=${ev.code} reason=${ev.reason || "—"}`,
                timestamp: new Date().toISOString(),
                frameIndex: frameCount + 1,
                durationMs: Math.round(performance.now() - startedPerf),
              });
            });

            ws.addEventListener("error", () => {
              post("WS_FRAME", {
                connId,
                direction: "error",
                url: String(url),
                payload: "WebSocket error",
                timestamp: new Date().toISOString(),
                frameIndex: frameCount + 1,
              });
            });

            return ws;
          };
          PatchedWebSocket.prototype = OriginalWebSocket.prototype;
          PatchedWebSocket.CONNECTING = OriginalWebSocket.CONNECTING;
          PatchedWebSocket.OPEN = OriginalWebSocket.OPEN;
          PatchedWebSocket.CLOSING = OriginalWebSocket.CLOSING;
          PatchedWebSocket.CLOSED = OriginalWebSocket.CLOSED;
          PatchedWebSocket.__hyperRbPatched = true;
          window.WebSocket = PatchedWebSocket;
        }
      } catch (err) {
        console.warn("[Hyper RB] WebSocket hook falhou", err);
      }

      post("HOOK_READY", { href: location.href, title: document.title, timestamp: Date.now() });
      captureAuth();
      setInterval(() => captureAuth(), 2000);
    })();
