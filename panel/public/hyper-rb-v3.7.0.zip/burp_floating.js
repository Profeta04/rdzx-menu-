/* Hyper RB — Painel flutuante (overlay injetado, draggable + resizable).
 * Carrega burp_sidepanel.html dentro de um iframe — single source of truth p/ UI.
 * Estado persistido em chrome.storage.local.qlrb_floating_state.
 */
(() => {
  if (window.__BURP_RB_FLOATING__) return;

  const STORAGE_KEY = "qlrb_floating_state";
  let root = null;
  let visible = false;
  let minimized = false;
  let pos = { top: 80, right: 24, width: 980, height: 680 };

  function loadState() {
    try {
      chrome.storage?.local?.get([STORAGE_KEY], (data) => {
        if (data && data[STORAGE_KEY]) {
          pos = { ...pos, ...data[STORAGE_KEY] };
          if (root) applyPos();
        }
      });
    } catch {}
  }

  function persistState() {
    try {
      chrome.storage?.local?.set({ [STORAGE_KEY]: pos });
    } catch {}
  }

  function applyPos() {
    if (!root) return;
    root.style.top = `${pos.top}px`;
    root.style.right = `${pos.right}px`;
    root.style.left = "auto";
    root.style.width = `${pos.width}px`;
    if (!minimized) root.style.height = `${pos.height}px`;
  }

  function build() {
    if (root) return root;
    root = document.createElement("div");
    root.id = "hyper-rb-floating-root";
    root.innerHTML = `
      <div class="hrb-handle" data-drag-handle>
        <div class="hrb-handle-title">
          <div class="hrb-handle-mark">H</div>
          <span>Hyper RB</span>
        </div>
        <div class="hrb-handle-actions">
          <button class="hrb-handle-btn" data-act="reload" title="Recarregar painel">↻</button>
          <button class="hrb-handle-btn" data-act="minimize" title="Minimizar">_</button>
          <button class="hrb-handle-btn" data-act="close" title="Fechar">✕</button>
        </div>
      </div>
      <div class="hrb-body">
        <iframe class="hrb-iframe" src="${chrome.runtime.getURL("burp_sidepanel.html")}"></iframe>
      </div>
    `;
    (document.body || document.documentElement).appendChild(root);

    const handle = root.querySelector("[data-drag-handle]");
    handle.addEventListener("pointerdown", startDrag);

    root.querySelector('[data-act="close"]').addEventListener("click", hide);
    root.querySelector('[data-act="minimize"]').addEventListener("click", toggleMinimize);
    root.querySelector('[data-act="reload"]').addEventListener("click", () => {
      const iframe = root.querySelector("iframe");
      if (iframe) iframe.src = iframe.src;
    });

    // Observa resize do user para persistir.
    const ro = new ResizeObserver(() => {
      if (!visible || minimized) return;
      const rect = root.getBoundingClientRect();
      pos.width = Math.round(rect.width);
      pos.height = Math.round(rect.height);
      persistState();
    });
    ro.observe(root);

    applyPos();
    return root;
  }

  function startDrag(e) {
    if (e.target.closest(".hrb-handle-actions")) return;
    const rect = root.getBoundingClientRect();
    const startX = e.clientX, startY = e.clientY;
    const startLeft = rect.left, startTop = rect.top;
    root.style.left = `${startLeft}px`;
    root.style.right = "auto";
    root.style.top = `${startTop}px`;
    const onMove = (ev) => {
      const nextLeft = Math.max(0, Math.min(window.innerWidth - 80, startLeft + (ev.clientX - startX)));
      const nextTop = Math.max(0, Math.min(window.innerHeight - 60, startTop + (ev.clientY - startY)));
      root.style.left = `${nextLeft}px`;
      root.style.top = `${nextTop}px`;
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      const r = root.getBoundingClientRect();
      pos.top = Math.round(r.top);
      pos.right = Math.max(0, Math.round(window.innerWidth - r.right));
      // Mantemos o eixo "right" como referência para responsividade.
      root.style.left = "auto";
      root.style.right = `${pos.right}px`;
      persistState();
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }

  function show() { build(); root.classList.add("visible"); visible = true; }
  function hide() { if (root) { root.classList.remove("visible"); visible = false; } }
  function toggle() { visible ? hide() : show(); }
  function toggleMinimize() {
    minimized = !minimized;
    if (!root) return;
    root.classList.toggle("minimized", minimized);
    if (!minimized) root.style.height = `${pos.height}px`;
  }

  window.__BURP_RB_FLOATING__ = { show, hide, toggle };

  loadState();
})();
