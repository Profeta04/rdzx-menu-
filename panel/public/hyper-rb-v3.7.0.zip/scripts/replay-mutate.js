(function registerReplayMutate() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · replay-mutate] HYPER_RB_SHARED ausente");
    return;
  }

  const MAX_VARIANTS = 10;
  const SLEEP_MS = 150;
  const BLOCKED_HEADERS = new Set(["authorization", "cookie", "set-cookie", "proxy-authorization"]);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function cloneHeaders(headers) {
    const next = {};
    for (const [k, v] of Object.entries(headers || {})) {
      if (BLOCKED_HEADERS.has(String(k).toLowerCase())) continue;
      next[k] = v;
    }
    return next;
  }

  function buildVariants(baseReq) {
    return [{
      label: "original",
      method: baseReq.method,
      url: baseReq.url,
      headers: cloneHeaders(baseReq.reqHeaders),
      body: baseReq.reqBody || "",
    }];
  }

  async function runReplays(ctx, variants, onProgress) {
    const results = [];
    for (let i = 0; i < variants.length; i++) {
      const v = variants[i];
      onProgress(i, variants.length, v.label);
      try {
        const res = await ctx.proxyFetch(v.url, {
          method: v.method,
          headers: cloneHeaders(v.headers),
          body: v.body || undefined,
        });
        results.push({ label: v.label, ok: res.ok, status: res.status, ms: res.durationMs, body: (res.body || "").slice(0, 8192), error: res.error });
      } catch (e) {
        results.push({ label: v.label, ok: false, status: 0, ms: 0, body: "", error: String((e && e.message) || e) });
      }
      if (i < variants.length - 1) await sleep(SLEEP_MS);
    }
    return results;
  }

  const SCRIPT = {
    id: 6,
    slug: "replay-mutate",
    name: "Replay & Mutate",
    description: "Replica uma request com até 10 variantes mutáveis (headers/body) e compara respostas.",
    icon: "🧪",
    needsAI: false,
    needsNetwork: true,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes." };
      }

      const requests = ctx.requests.slice(-50).reverse();

      return {
        ok: true,
        summary: `${requests.length} requests disponíveis para replay`,
        render(mountEl) {
          mountEl.innerHTML = `
            <div class="hyper-rb-replay">
              <div style="margin-bottom:12px;">
                <label style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.6);margin-bottom:6px;">Request base</label>
                <select class="rm-select" style="width:100%;padding:8px;background:rgba(18,18,20,.7);color:#fff;border:1px solid rgba(191,0,255,.3);border-radius:6px;">
                  ${requests.map((r, i) => `<option value="${i}">${S.escapeHtml(r.method)} ${S.escapeHtml((r.host || "") + (r.pathname || ""))}</option>`).join("")}
                </select>
              </div>
              <div class="rm-variants" style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px;"></div>
              <div style="display:flex;gap:8px;margin-bottom:12px;">
                <button class="rm-add" style="padding:8px 12px;background:rgba(191,0,255,.15);color:#fff;border:1px solid rgba(191,0,255,.4);border-radius:6px;cursor:pointer;">+ Variante</button>
                <button class="rm-run" style="padding:8px 12px;background:#bf00ff;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600;">Executar replays</button>
              </div>
              <div class="rm-status" style="font-size:12px;color:rgba(255,255,255,.6);margin-bottom:8px;"></div>
              <div class="rm-results"></div>
            </div>
          `;

          const select = mountEl.querySelector(".rm-select");
          const variantsEl = mountEl.querySelector(".rm-variants");
          const addBtn = mountEl.querySelector(".rm-add");
          const runBtn = mountEl.querySelector(".rm-run");
          const statusEl = mountEl.querySelector(".rm-status");
          const resultsEl = mountEl.querySelector(".rm-results");

          let variants = [];

          function renderVariants() {
            variantsEl.innerHTML = variants.map((v, i) => `
              <details style="background:rgba(18,18,20,.5);border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:8px;">
                <summary style="cursor:pointer;color:#fff;font-size:12px;">${S.escapeHtml(v.label)} <button data-rm-del="${i}" style="float:right;background:transparent;border:none;color:#ff6b6b;cursor:pointer;">×</button></summary>
                <div style="margin-top:8px;display:flex;flex-direction:column;gap:6px;">
                  <input data-rm-label="${i}" value="${S.escapeHtml(v.label)}" placeholder="Rótulo" style="padding:6px;background:rgba(0,0,0,.3);color:#fff;border:1px solid rgba(255,255,255,.1);border-radius:4px;font-size:11px;" />
                  <textarea data-rm-headers="${i}" placeholder="Headers JSON (sem Authorization)" rows="3" style="padding:6px;background:rgba(0,0,0,.3);color:#fff;border:1px solid rgba(255,255,255,.1);border-radius:4px;font-family:monospace;font-size:11px;">${S.escapeHtml(JSON.stringify(v.headers, null, 2))}</textarea>
                  <textarea data-rm-body="${i}" placeholder="Body" rows="4" style="padding:6px;background:rgba(0,0,0,.3);color:#fff;border:1px solid rgba(255,255,255,.1);border-radius:4px;font-family:monospace;font-size:11px;">${S.escapeHtml(v.body || "")}</textarea>
                </div>
              </details>
            `).join("");
          }

          function syncVariantsFromDOM() {
            variantsEl.querySelectorAll("[data-rm-label]").forEach((el) => {
              const i = Number(el.getAttribute("data-rm-label"));
              variants[i].label = el.value || `variant-${i}`;
            });
            variantsEl.querySelectorAll("[data-rm-headers]").forEach((el) => {
              const i = Number(el.getAttribute("data-rm-headers"));
              try { variants[i].headers = cloneHeaders(JSON.parse(el.value || "{}")); } catch {}
            });
            variantsEl.querySelectorAll("[data-rm-body]").forEach((el) => {
              const i = Number(el.getAttribute("data-rm-body"));
              variants[i].body = el.value || "";
            });
          }

          function loadBase() {
            const idx = Number(select.value || 0);
            const base = requests[idx];
            variants = buildVariants(base);
            // store url/method on variants so they can be replayed
            variants.forEach((v) => { v.url = base.url; v.method = base.method; });
            renderVariants();
          }

          select.addEventListener("change", loadBase);

          addBtn.addEventListener("click", () => {
            syncVariantsFromDOM();
            if (variants.length >= MAX_VARIANTS) {
              statusEl.textContent = `Limite de ${MAX_VARIANTS} variantes atingido.`;
              return;
            }
            const base = variants[0] || { method: "GET", url: "", headers: {}, body: "" };
            variants.push({
              label: `variant-${variants.length}`,
              method: base.method,
              url: base.url,
              headers: { ...base.headers },
              body: base.body || "",
            });
            renderVariants();
          });

          variantsEl.addEventListener("click", (e) => {
            const target = e.target;
            if (target && target.matches && target.matches("[data-rm-del]")) {
              syncVariantsFromDOM();
              const i = Number(target.getAttribute("data-rm-del"));
              if (i === 0) {
                statusEl.textContent = "A variante original não pode ser removida.";
                return;
              }
              variants.splice(i, 1);
              renderVariants();
            }
          });

          runBtn.addEventListener("click", async () => {
            syncVariantsFromDOM();
            if (!variants.length) return;
            runBtn.disabled = true;
            runBtn.style.opacity = "0.5";
            resultsEl.innerHTML = "";
            try {
              const results = await runReplays(ctx, variants, (i, total, label) => {
                statusEl.textContent = `Executando ${i + 1}/${total} — ${label}…`;
              });
              statusEl.textContent = `Concluído: ${results.length} replays.`;
              resultsEl.innerHTML = results.map((r) => `
                <div style="background:rgba(18,18,20,.5);border:1px solid ${r.ok ? "rgba(80,200,120,.4)" : "rgba(255,107,107,.4)"};border-radius:6px;padding:10px;margin-bottom:8px;">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                    <strong style="color:#fff;font-size:12px;">${S.escapeHtml(r.label)}</strong>
                    <span style="color:${r.ok ? "#7dffb8" : "#ff6b6b"};font-size:11px;">${r.status} · ${r.ms}ms</span>
                  </div>
                  ${r.error ? `<div style="color:#ff6b6b;font-size:11px;">${S.escapeHtml(r.error)}</div>` : ""}
                  <pre style="margin:0;padding:8px;background:rgba(0,0,0,.4);color:rgba(255,255,255,.8);font-size:11px;border-radius:4px;max-height:200px;overflow:auto;white-space:pre-wrap;">${S.escapeHtml(r.body || "(vazio)")}</pre>
                </div>
              `).join("");
            } catch (e) {
              statusEl.textContent = `Erro: ${(e && e.message) || e}`;
            } finally {
              runBtn.disabled = false;
              runBtn.style.opacity = "1";
            }
          });

          loadBase();
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();