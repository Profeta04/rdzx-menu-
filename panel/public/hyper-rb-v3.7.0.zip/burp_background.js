const SUPABASE_URL = "https://cvbgrjauqjawrsyknhyj.supabase.co";
    const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN2YmdyamF1cWphd3JzeWtuaHlqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTk1OTYsImV4cCI6MjA5MTIzNTU5Nn0.JdZeY39iGHcZ5P3p0DDXYVUvNJfMrKp_OraUC5EDyzU";
    // Composer Sequence Mode (chains). Carrega helpers no escopo global do SW.
    try { importScripts("burp_chains.js"); } catch (e) { console.error("[Hyper RB] Falha ao carregar burp_chains.js", e); }
    // AI client (Fase 2): sanitiza request e fala com edge function /ai.
    try { importScripts("burp_ai_client.js"); } catch (e) { console.error("[Hyper RB] Falha ao carregar burp_ai_client.js", e); }
    // Hyper RB é uma ferramenta interna de devs HyperBuild — NÃO valida
    // licença. Apenas faz replay/intercept de requests via /burp. Qualquer
    // license_key capturada de outras extensões é mantida apenas como dado
    // opaco para preencher presets (`{{LICENSE_KEY}}`), nunca validada aqui.
    const BURP_ENDPOINT = `${SUPABASE_URL}/functions/v1/burp`;
    // Limite de segurança apenas para evitar OOM. UI permite limpar manualmente
    // e exportar HAR. Antes era 300 (insuficiente p/ sessões longas).
    const MAX_NETWORK_ENTRIES = 10000;
    const MAX_WS_FRAMES_PER_CONN = 500;
    const MAX_BODY_CHARS = 25000;
    const MAX_STARTUP_LOGS = 120;
    const SENSITIVE_HEADERS = ["authorization", "cookie", "set-cookie", "x-api-key", "apikey", "proxy-authorization"];
    // Padrões de URL ignorados por padrão (ruído de polling/refresh).
    // Mantemos a lista enxuta — só denoise comprovado, sem esconder Lovable real.
    const DENOISE_PATTERNS = [
      /\/auth\/v1\/token\?grant_type=refresh_token/i,
      /\/realtime\/v1\/websocket/i,
      /google-analytics\.com/i,
      /googletagmanager\.com/i,
      /sentry\.io/i,
      /\.posthog\.com/i,
    ];
    // Dedup janela: mesma URL+método dentro de 500ms é considerada duplicata.
    const DEDUP_WINDOW_MS = 500;

    const state = {
      bootedAt: new Date().toISOString(),
      deviceId: null,
      debug: false,
      auth: {
        bearerToken: null,
        projectId: null,
        workspaceId: null,
        cookies: null,
        source: null,
        lastUpdated: null,
      },
      license: {
        key: null,
        valid: false,
        sessionId: null,
        userName: null,
        expiresAt: null,
        status: null,
        onlineCount: 0,
      },
      hbLicense: null,
      diagnostics: {
        manifest: { status: "ready", detail: chrome.runtime.getManifest().version },
        serviceWorker: { status: "booting", detail: "Inicializando" },
        contentScript: { status: "waiting", detail: "Aguardando página Lovable" },
        pageHook: { status: "waiting", detail: "Hook ainda não respondeu" },
        auth: { status: "waiting", detail: "Aguardando captura" },
        permissions: { status: "ready", detail: "Permissões carregadas" },
      },
      startupLogs: [],
       network: [],
       isCapturing: true,
    };

    let persistTimer = null;

    function log(level, module, message, meta) {
      const entry = {
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        level,
        module,
        message,
        meta: meta || null,
      };
      state.startupLogs.unshift(entry);
      state.startupLogs = state.startupLogs.slice(0, MAX_STARTUP_LOGS);
      const consoleMethod = level === "error" ? "error" : level === "warn" ? "warn" : "log";
      console[consoleMethod](`[Hyper RB][${module}] ${message}`, meta || "");
      schedulePersist();
      broadcast({ type: "BURP_LOG_UPDATED", payload: getPublicState() });
    }

    function schedulePersist() {
      if (persistTimer) clearTimeout(persistTimer);
      persistTimer = setTimeout(() => {
        chrome.storage.local.set({
          burp_background_state: {
            bootedAt: state.bootedAt,
            deviceId: state.deviceId,
            debug: state.debug,
            auth: state.auth,
            license: state.license,
            diagnostics: state.diagnostics,
            startupLogs: state.startupLogs,
            network: state.network,
          }
        });
      }, 300);
    }

    function maskValue(value) {
      if (!value) return null;
      const stringValue = String(value);
      if (stringValue.length <= 10) return "••••";
      return `${stringValue.slice(0, 6)}••••${stringValue.slice(-4)}`;
    }

    function truncateText(value, limit = MAX_BODY_CHARS) {
      if (value === undefined || value === null) return null;
      const text = typeof value === "string" ? value : JSON.stringify(value);
      return text.length > limit ? `${text.slice(0, limit)}
/* truncated */` : text;
    }

    function parseJsonSafely(value) {
      if (!value || typeof value !== "string") return null;
      try {
        return JSON.parse(value);
      } catch {
        return null;
      }
    }

    function getSize(value) {
      if (value === undefined || value === null) return 0;
      try {
        return new Blob([typeof value === "string" ? value : JSON.stringify(value)]).size;
      } catch {
        return String(value).length;
      }
    }

    function sanitizeHeaders(headers) {
      if (!headers || typeof headers !== "object") return {};
      const sanitized = {};
      for (const [key, value] of Object.entries(headers)) {
        const normalized = key.toLowerCase();
        sanitized[key] = SENSITIVE_HEADERS.some((header) => normalized.includes(header)) ? maskValue(value) : String(value);
      }
      return sanitized;
    }

    function normalizeHeaders(headers) {
      if (!headers) return {};
      if (headers instanceof Headers) {
        return Object.fromEntries(headers.entries());
      }
      if (Array.isArray(headers)) {
        return Object.fromEntries(headers);
      }
      return { ...headers };
    }

    function inferKind(url, headers, body) {
      const headerMap = normalizeHeaders(headers);
      const contentType = String(headerMap["content-type"] || headerMap["Content-Type"] || "").toLowerCase();
      const bodyText = typeof body === "string" ? body : JSON.stringify(body || "");
      if (contentType.includes("graphql") || /(query|mutation)/.test(bodyText)) return "graphql";
      if (contentType.includes("json") || contentType.includes("javascript") || bodyText.startsWith("{")) return "fetch";
      return "xhr";
    }

    function getStats() {
      return {
        entryCount: state.network.length,
        authCaptured: Boolean(state.auth.bearerToken),
        lastCaptureAt: state.auth.lastUpdated,
        licenseValid: Boolean(state.license.valid),
      };
    }

    function getPublicState() {
      return {
        bootedAt: state.bootedAt,
        debug: state.debug,
        diagnostics: state.diagnostics,
        startupLogs: state.startupLogs,
        network: state.network,
        stats: getStats(),
        auth: {
          hasBearerToken: Boolean(state.auth.bearerToken),
          bearerTokenPreview: maskValue(state.auth.bearerToken),
          projectId: state.auth.projectId,
          workspaceId: state.auth.workspaceId,
          cookiesPreview: maskValue(state.auth.cookies),
          source: state.auth.source,
          lastUpdated: state.auth.lastUpdated,
        },
        license: {
          valid: state.license.valid,
          keyPreview: maskValue(state.license.key),
          sessionId: state.license.sessionId,
          userName: state.license.userName,
          expiresAt: state.license.expiresAt,
          status: state.license.status,
          onlineCount: state.license.onlineCount,
        },
        hbLicense: {
          hasKey: Boolean(state.hbLicense),
          preview: maskValue(state.hbLicense),
        },
      };
    }

    function broadcast(message) {
      try {
        chrome.runtime.sendMessage(message, () => void chrome.runtime?.lastError);
      } catch {}
    }

    async function ensureDeviceId() {
      const data = await chrome.storage.local.get(["burp_device_id"]);
      if (data.burp_device_id) {
        state.deviceId = data.burp_device_id;
        return data.burp_device_id;
      }
      const deviceId = crypto.randomUUID();
      state.deviceId = deviceId;
      await chrome.storage.local.set({ burp_device_id: deviceId });
      return deviceId;
    }

    async function restoreState() {
      const data = await chrome.storage.local.get([
        "burp_background_state", "ql_license_key", "ql_license_valid",
        "ql_session_id", "ql_user_name", "ql_expires_at", "ql_license_status",
        "qlrb_hb_license",
      ]);
      if (data.burp_background_state) {
        const saved = data.burp_background_state;
        state.debug = Boolean(saved.debug);
        state.auth = { ...state.auth, ...(saved.auth || {}) };
        state.license = { ...state.license, ...(saved.license || {}) };
        state.diagnostics = { ...state.diagnostics, ...(saved.diagnostics || {}) };
        delete state.diagnostics.sidePanel;
        state.startupLogs = Array.isArray(saved.startupLogs) ? saved.startupLogs.slice(0, MAX_STARTUP_LOGS) : [];
        state.network = Array.isArray(saved.network) ? saved.network.slice(0, MAX_NETWORK_ENTRIES) : [];
      }
      if (data.ql_license_key) {
        state.license.key = data.ql_license_key;
        state.license.valid = Boolean(data.ql_license_valid);
        state.license.sessionId = data.ql_session_id || null;
        state.license.userName = data.ql_user_name || null;
        state.license.expiresAt = data.ql_expires_at || null;
        state.license.status = data.ql_license_status || null;
      }
      if (data.qlrb_hb_license) state.hbLicense = data.qlrb_hb_license;
    }

    function storeNetworkEntry(entry) {
      // (see DENOISE/DEDUP logic above)
      // Denoise
      if (entry.source !== "replay") {
        if (DENOISE_PATTERNS.some((re) => re.test(entry.url || ""))) return;
        // Dedup: descarta se a última entry com mesma URL+método foi há <500ms
        const last = state.network[0];
        if (last && last.url === entry.url && last.method === entry.method) {
          const lastTs = Date.parse(last.startedAt) || 0;
          const nowTs = Date.parse(entry.startedAt) || Date.now();
          if (nowTs - lastTs < DEDUP_WINDOW_MS) return;
        }
      }
      state.network.unshift(entry);
      state.network = state.network.slice(0, MAX_NETWORK_ENTRIES);
      schedulePersist();
      broadcast({ type: "BURP_NETWORK_UPDATED", payload: getPublicState() });
    }

    /**
     * Constrói um objeto HAR 1.2 a partir do histórico capturado.
     * Spec: http://www.softwareishard.com/blog/har-12-spec/
     * Cookies e auth já estão mascarados em state.network (sanitizeHeaders).
     */
    function buildHar() {
      const manifest = chrome.runtime.getManifest();
      const headersToArr = (h) => Object.entries(h || {}).map(([name, value]) => ({ name, value: String(value) }));
      const entries = (state.network || []).slice().reverse().map((e) => {
        const startedAt = e.startedAt || new Date().toISOString();
        const requestBodyText = e.requestBody == null ? "" : (typeof e.requestBody === "string" ? e.requestBody : JSON.stringify(e.requestBody));
        const responseBodyText = e.responseBody == null ? "" : String(e.responseBody);
        const reqContentType = (e.requestHeaders && (e.requestHeaders["content-type"] || e.requestHeaders["Content-Type"])) || "application/octet-stream";
        const resContentType = (e.responseHeaders && (e.responseHeaders["content-type"] || e.responseHeaders["Content-Type"])) || "application/octet-stream";
        return {
          startedDateTime: startedAt,
          time: Number(e.timingMs || 0),
          request: {
            method: e.method || "GET",
            url: e.url || "",
            httpVersion: "HTTP/1.1",
            cookies: [],
            headers: headersToArr(e.requestHeaders),
            queryString: [],
            headersSize: -1,
            bodySize: requestBodyText.length,
            ...(requestBodyText ? { postData: { mimeType: String(reqContentType), text: requestBodyText } } : {}),
          },
          response: {
            status: Number(e.status || 0),
            statusText: e.statusText || "",
            httpVersion: "HTTP/1.1",
            cookies: [],
            headers: headersToArr(e.responseHeaders),
            content: {
              size: Number(e.responseSize || responseBodyText.length || 0),
              mimeType: String(resContentType),
              text: responseBodyText,
            },
            redirectURL: "",
            headersSize: -1,
            bodySize: responseBodyText.length,
          },
          cache: {},
          timings: { send: 0, wait: Number(e.timingMs || 0), receive: 0 },
          _hyperRb: { id: e.id, kind: e.kind, source: e.source, error: e.error || null },
        };
      });
      return {
        log: {
          version: "1.2",
          creator: { name: "Hyper RB", version: manifest.version || "0.0.0" },
          browser: { name: "Chrome", version: navigator.userAgent || "" },
          pages: [],
          entries,
        },
      };
    }

    function upsertAuth(payload) {
      const nextAuth = {
        ...state.auth,
        bearerToken: payload.bearerToken || state.auth.bearerToken,
        projectId: payload.projectId || state.auth.projectId,
        workspaceId: payload.workspaceId || state.auth.workspaceId,
        cookies: payload.cookies || state.auth.cookies,
        source: payload.source || payload.origin || state.auth.source || "page",
        lastUpdated: new Date().toISOString(),
      };
      state.auth = nextAuth;
      state.diagnostics.auth = {
        status: nextAuth.bearerToken ? "ready" : "warning",
        detail: nextAuth.bearerToken ? "Bearer token capturado" : "Sem token capturado",
      };
      state.diagnostics.pageHook = {
        status: "ready",
        detail: `Último sync em ${new Date().toLocaleTimeString("pt-BR")}`,
      };
      schedulePersist();
      broadcast({ type: "BURP_AUTH_UPDATED", payload: getPublicState() });
    }

    // NOTA: Hyper RB não valida licença. Antes existia `validateLicense()`
    // que batia em /vx — removido. A extensão apenas lê `ql_license_key` do
    // storage (se outra extensão HyperBuild já tiver salvo) para uso opaco
    // em presets de replay. Nenhuma chamada de validação é feita.

     async function executeBurpRequest(payload) {
       if (!payload.url) throw new Error("URL obrigatória");
        // Hyper RB é ferramenta interna dos devs HyperBuild — sem trava de
        // licença. Se uma licença foi capturada, ainda enviamos no header só
        // para logging opcional no servidor.
        const licenseKey = state.license?.key || null;
        const requestHeaders = normalizeHeaders(payload.headers || {});
        const fetchHeaders = {
          "Content-Type": "application/json",
          "apikey": SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
        };
        if (licenseKey) fetchHeaders["x-license-key"] = licenseKey;

        const response = await fetch(BURP_ENDPOINT, {
          method: "POST",
          headers: fetchHeaders,
         body: JSON.stringify({
           url: payload.url,
           method: payload.method || "GET",
           headers: requestHeaders,
           body: payload.body ?? null,
           device_id: state.deviceId,
           auth: {
             bearerToken: state.auth.bearerToken,
             cookies: state.auth.cookies,
             projectId: state.auth.projectId,
             workspaceId: state.auth.workspaceId,
           },
         }),
       });
       const result = await response.json().catch(() => ({}));
       if (!response.ok) {
         // Erros do próprio /burp (não do upstream). Pode vir como
         // `{error, error_display, user_action, error_code}` quando o /burp
         // já mapeou — repassamos a melhor mensagem disponível.
         const msg =
           result?.user_action ||
           result?.error_display ||
           result?.error ||
           `Falha HTTP ${response.status}`;
         throw new Error(msg);
       }

       // O /burp agora pode anexar `mappedError` quando o upstream Lovable
       // retornou erro estruturado (CAPTCHA_REQUIRED, AUTH_FAILED, etc).
       // Promovemos isso para o entry e disparamos diagnóstico se o token
       // Lovable expirou.
       if (result?.mappedError?.error_code === "AUTH_FAILED") {
         state.auth.bearerToken = null;
         log("warn", "auth", "Token Lovable invalidado pelo upstream (AUTH_FAILED).");
       }
 
       const entry = {
         id: result.requestId || crypto.randomUUID(),
         url: payload.url,
         method: payload.method || "GET",
         kind: inferKind(payload.url, requestHeaders, payload.body),
         source: "replay",
         status: result.status || 0,
         statusText: result.ok ? "OK" : "ERROR",
         requestHeaders: sanitizeHeaders(requestHeaders),
         requestBody: truncateText(payload.body),
         responseHeaders: sanitizeHeaders(result.headers || {}),
         responseBody: truncateText(result.body || ""),
         responseJson: result.json || parseJsonSafely(result.body),
         timingMs: result.timingMs || 0,
         responseSize: result.responseSize || getSize(result.body || ""),
         startedAt: new Date().toISOString(),
         mappedError: result.mappedError || null,
         auth: {
           hasBearerToken: Boolean(state.auth.bearerToken),
           tokenPreview: maskValue(state.auth.bearerToken),
           cookiesPreview: maskValue(state.auth.cookies),
           projectId: state.auth.projectId,
           workspaceId: state.auth.workspaceId,
         },
       };
       storeNetworkEntry(entry);
       return entry;
     }

     // -----------------------------------------------------------------
     // Composer Sequence Mode — executor serial de chains.
     // Cada step é executado via /burp single-request (que já tem SSRF
     // guard + allowlist + rate limit). Progresso é emitido em tempo real
     // via `chrome.runtime.sendMessage({type:"BURP_CHAIN_PROGRESS"})`.
     // -----------------------------------------------------------------
     async function executeBurpChain(chain, opts) {
       const Chains = self.HyperRBChains;
       if (!Chains) throw new Error("Módulo de chains não carregado.");
       const { valid, errors } = Chains.validateChain(chain);
       if (!valid) throw new Error(`Chain inválida: ${errors.join("; ")}`);

       const runId = (opts && opts.runId) || crypto.randomUUID();
       const startedAt = Date.now();
       const deadline = startedAt + Chains.HARD_LIMITS.GLOBAL_DEADLINE_MS;
       const stopOnError = chain.stopOnError !== false;

       // Contexto inicial — vars + dados capturados (token, projectId, etc).
       const context = {
         vars: chain.vars ? { ...chain.vars } : {},
         ctx: {
           token: state.auth.bearerToken || "",
           projectId: state.auth.projectId || "",
           workspaceId: state.auth.workspaceId || "",
           licenseKey: state.license.key || "",
           deviceId: state.deviceId || "",
         },
       };

       const results = [];
       let totalBytes = 0;

       function emit(stage, stepIndex, payload) {
          broadcast({
           type: "BURP_CHAIN_PROGRESS",
           payload: { runId, stage, stepIndex, totalSteps: chain.steps.length, ...payload },
         });
       }

       emit("start", -1, { chainName: chain.name || "chain" });

       for (let i = 0; i < chain.steps.length; i++) {
         const step = chain.steps[i];
         if (Date.now() > deadline) {
           emit("aborted", i, { reason: "Deadline global excedido (60s)." });
           break;
         }

         // Avalia runIf (string template booleana opcional). Se resolvido para
         // "" ou "false", pula o step.
         if (step.runIf) {
           const resolved = Chains.resolveTemplate(String(step.runIf), context, []);
           if (!resolved || resolved === "false" || resolved === "0") {
             const skipResult = { stepId: step.id, skipped: true, reason: "runIf=false" };
             results.push(skipResult);
             context[step.id] = { skipped: true };
             emit("step:skipped", i, { stepId: step.id });
             continue;
           }
         }

         const prepared = Chains.prepareStep(step, context);
         if (prepared.missing && prepared.missing.length) {
           const err = `Tokens não resolvidos: ${prepared.missing.join(", ")}`;
           const failResult = { stepId: step.id, ok: false, error: err };
           results.push(failResult);
           context[step.id] = { ok: false, error: err };
           emit("step:failed", i, { stepId: step.id, error: err });
           if (stopOnError) break;
           continue;
         }

         emit("step:start", i, { stepId: step.id, method: prepared.method, url: prepared.url });

         const stepT0 = Date.now();
         let attempt = 0;
         const maxAttempts = 1 + Math.max(0, Math.min(Chains.HARD_LIMITS.MAX_RETRY, Number(step.retry || 0)));
         let stepResult = null;
         let lastErr = null;

         while (attempt < maxAttempts) {
           attempt += 1;
           try {
             const replay = await executeBurpRequest({
               url: prepared.url,
               method: prepared.method,
               headers: prepared.headers,
               body: prepared.body,
             });
             const extracted = Chains.extractFromResponse(step.extract, replay.responseJson);
             const ctxEntry = {
               status: replay.status,
               headers: replay.responseHeaders,
               body: replay.responseBody,
               json: replay.responseJson,
               extracted,
               ok: replay.status >= 200 && replay.status < 400,
             };
             context[step.id] = ctxEntry;
             totalBytes += Number(replay.responseSize || 0);
             stepResult = {
               stepId: step.id,
               attempt,
               ok: ctxEntry.ok,
               status: replay.status,
               timingMs: Date.now() - stepT0,
               requestId: replay.id,
               extracted,
               mappedError: replay.mappedError || null,
             };
             if (ctxEntry.ok) break;
             // não-2xx/3xx é falha lógica; só refaz tentativa se ainda houver retry
             lastErr = `HTTP ${replay.status}`;
             if (attempt < maxAttempts) await new Promise((r) => setTimeout(r, 400 * attempt));
           } catch (err) {
             lastErr = err && err.message ? err.message : String(err);
             if (attempt < maxAttempts) await new Promise((r) => setTimeout(r, 400 * attempt));
           }
         }

         if (!stepResult) {
           stepResult = { stepId: step.id, ok: false, attempt, timingMs: Date.now() - stepT0, error: lastErr || "Falha desconhecida" };
           context[step.id] = { ok: false, error: stepResult.error };
         }
         results.push(stepResult);
         emit(stepResult.ok ? "step:ok" : "step:failed", i, { stepId: step.id, status: stepResult.status, error: stepResult.error || null, ms: stepResult.timingMs });

         if (totalBytes > Chains.HARD_LIMITS.MAX_TOTAL_BYTES) {
           emit("aborted", i, { reason: "Tamanho total da chain excedeu 5MB." });
           break;
         }
         if (!stepResult.ok && stopOnError) break;
       }

       const summary = {
         runId,
         chainName: chain.name || "chain",
         startedAt: new Date(startedAt).toISOString(),
         durationMs: Date.now() - startedAt,
         stepCount: chain.steps.length,
         executed: results.length,
         okCount: results.filter((r) => r.ok).length,
         results,
       };
       emit("done", -1, { summary });
       return summary;
     }

    async function bootstrap() {
      await restoreState();
      await ensureDeviceId();
      state.diagnostics.serviceWorker = { status: "ready", detail: "Service worker ativo" };
      schedulePersist();
      broadcast({ type: "BURP_STATE_READY", payload: getPublicState() });
    }

    chrome.runtime.onInstalled.addListener(() => {
      log("info", "startup", "Hyper RB instalado/inicializado.");
    });

    chrome.runtime.onStartup.addListener(() => {
      log("info", "startup", "Hyper RB reiniciado pelo navegador.");
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      (async () => {
        switch (message?.type) {
          case "BURP_GET_STATE": {
            sendResponse({ ok: true, state: getPublicState() });
            return;
          }
          case "BURP_SET_DEBUG": {
            state.debug = Boolean(message.payload?.enabled);
            schedulePersist();
            log("info", "ui", `Debug mode ${state.debug ? "ativado" : "desativado"}.`);
            sendResponse({ ok: true, state: getPublicState() });
            return;
          }
          case "BURP_HOOK_READY": {
            state.diagnostics.contentScript = { status: "ready", detail: sender?.tab?.url || "Content script ativo" };
            state.diagnostics.pageHook = { status: "ready", detail: message.payload?.href || "Hook injetado" };
            schedulePersist();
            sendResponse({ ok: true });
            return;
          }
          case "BURP_CAPTURE_AUTH": {
            upsertAuth(message.payload || {});
            sendResponse({ ok: true });
            return;
          }
          case "BURP_SET_CAPTURE": {
            state.isCapturing = Boolean(message.payload?.enabled);
            schedulePersist();
            sendResponse({ ok: true, isCapturing: state.isCapturing });
            return;
          }
          case "BURP_NETWORK_EVENT": {
            if (!state.isCapturing) {
              sendResponse({ ok: true, dropped: true });
              return;
            }
            state.diagnostics.contentScript = { status: "ready", detail: sender?.tab?.url || "Tráfego capturado" };
            const payload = message.payload || {};
            const entry = {
              id: payload.id || crypto.randomUUID(),
              url: payload.url || "",
              method: payload.method || "GET",
              kind: payload.kind || inferKind(payload.url || "", payload.requestHeaders || {}, payload.requestBody),
              source: payload.source || "page",
              status: payload.status || 0,
              statusText: payload.statusText || (payload.error ? "FAILED" : "PENDING"),
              requestHeaders: sanitizeHeaders(payload.requestHeaders || {}),
              requestBody: truncateText(payload.requestBody),
              responseHeaders: sanitizeHeaders(payload.responseHeaders || {}),
              responseBody: truncateText(payload.responseBody),
              responseJson: payload.responseJson || parseJsonSafely(payload.responseBody),
              timingMs: payload.timingMs || 0,
              responseSize: payload.responseSize || getSize(payload.responseBody || ""),
              startedAt: payload.startedAt || new Date().toISOString(),
              auth: {
                hasBearerToken: Boolean(state.auth.bearerToken),
                tokenPreview: maskValue(state.auth.bearerToken),
                cookiesPreview: maskValue(state.auth.cookies),
                projectId: state.auth.projectId,
                workspaceId: state.auth.workspaceId,
              },
              error: payload.error || null,
            };
            storeNetworkEntry(entry);
            sendResponse({ ok: true });
            return;
          }
          case "BURP_VALIDATE_LICENSE":
          case "BURP_HEARTBEAT": {
            // Hyper RB é ferramenta interna e não valida licença.
            // Retornamos sucesso imediato para não quebrar a UI da sidepanel
            // ou fluxos de outras extensões.
            sendResponse({
              ok: true,
              result: { 
                valid: true, 
                skipped: true, 
                reason: "hyper_rb_internal_tool",
                message: "Validação desativada (Hyper RB)" 
              },
              state: getPublicState(),
            });
            return;
          }
          case "BURP_EXECUTE_REQUEST": {
            try {
              const result = await executeBurpRequest(message.payload || {});
              log("info", "replay", `Request replay executada: ${result.method} ${result.url}`);
              sendResponse({ ok: true, result, state: getPublicState() });
            } catch (error) {
              log("error", "replay", "Falha ao executar request replay.", { message: error.message });
              sendResponse({ ok: false, error: error.message, state: getPublicState() });
            }
            return;
          }
          case "BURP_EXECUTE_CHAIN": {
            try {
              const chain = message.payload?.chain;
              const summary = await executeBurpChain(chain, { runId: message.payload?.runId });
              log("info", "chain", `Chain executada: ${summary.chainName} (${summary.okCount}/${summary.executed} ok)`);
              sendResponse({ ok: true, summary, state: getPublicState() });
            } catch (error) {
              log("error", "chain", "Falha ao executar chain.", { message: error.message });
              sendResponse({ ok: false, error: error.message, state: getPublicState() });
            }
            return;
          }
          case "BURP_GET_CHAIN_TEMPLATES": {
            try {
              const tpls = (self.HyperRBChains && self.HyperRBChains.BUILTIN_TEMPLATES) || [];
              sendResponse({ ok: true, templates: tpls });
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_AI_EXPLAIN": {
            try {
              if (!self.HyperRBAI) {
                sendResponse({ ok: false, error: "AI client não carregado." });
                return;
              }
              const entryId = message.payload?.entryId;
              const entry = state.network.find((n) => n.id === entryId);
              if (!entry) {
                sendResponse({ ok: false, error: "Request não encontrada." });
                return;
              }
              const res = await self.HyperRBAI.explainRequest({
                entry,
                supabaseUrl: SUPABASE_URL,
                supabaseAnonKey: SUPABASE_ANON_KEY,
              });
              if (res.ok) {
                log("info", "ai", `Request explicada (${entry.method} ${entry.url})${res.cached ? " [cache]" : ""}`);
              } else {
                log("warn", "ai", `Falha ao explicar request: ${res.error}`);
              }
              sendResponse(res);
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_AI_RECIPE": {
            try {
              if (!self.HyperRBAI) {
                sendResponse({ ok: false, error: "AI client não carregado." });
                return;
              }
              const entryId = message.payload?.entryId;
              let entry = entryId ? state.network.find((n) => n.id === entryId) : null;
              if (!entry) {
                const candidate = message.payload?.entry || message.payload?.request;
                if (candidate && typeof candidate === "object") entry = candidate;
              }
              if (!entry) {
                sendResponse({ ok: false, error: "Request não encontrada." });
                return;
              }
              const res = await self.HyperRBAI.suggestRecipe({
                entry,
                supabaseUrl: SUPABASE_URL,
                supabaseAnonKey: SUPABASE_ANON_KEY,
              });
              if (res.ok) {
                log("info", "ai", `Recipe IA gerado (${entry.method} ${entry.url})${res.cached ? " [cache]" : ""}`);
              } else {
                log("warn", "ai", `Falha ao gerar recipe: ${res.error}`);
              }
              sendResponse(res);
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_BUILD_CHAIN_FROM_ENTRIES": {
            // Converte N entries (na ordem fornecida) em uma chain JSON pronta
            // para o Chain tab. Sanitiza tokens via HyperRBAI.sanitizeEntry,
            // gera vars sugeridas e steps com ids sequenciais.
            try {
              const ids = Array.isArray(message.payload?.entryIds) ? message.payload.entryIds : [];
              if (!ids.length) {
                sendResponse({ ok: false, error: "Selecione ao menos 1 request." });
                return;
              }
              if (ids.length > 10) {
                sendResponse({ ok: false, error: "Máximo 10 requests por chain." });
                return;
              }
              const entries = ids
                .map((id) => state.network.find((n) => n.id === id))
                .filter(Boolean);
              if (entries.length !== ids.length) {
                sendResponse({ ok: false, error: "Algumas requests não foram encontradas." });
                return;
              }
              const sanitizer = self.HyperRBAI?.sanitizeEntry;
              const chain = {
                name: `Chain importada (${entries.length} steps)`,
                vars: {},
                stopOnError: true,
                maxBudgetMs: 30000,
                steps: entries.map((e, idx) => {
                  const s = sanitizer ? sanitizer(e) : e;
                  const step = {
                    id: `s${idx + 1}`,
                    method: s.method,
                    url: s.url,
                    headers: s.requestHeaders || {},
                  };
                  if (s.requestBody != null && s.requestBody !== "") {
                    step.bodySource = "json";
                    step.body = s.requestBody;
                  }
                  return step;
                }),
              };
              sendResponse({ ok: true, chain });
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_AI_ANALYZE": {
            try {
              if (!self.HyperRBAI?.analyzeTraffic) {
                sendResponse({ ok: false, error: "AI client não carregado." });
                return;
              }
              const entries = Array.isArray(message.payload?.entries) && message.payload.entries.length
                ? message.payload.entries
                : state.network;
              const metrics = message.payload?.metrics || null;
              const res = await self.HyperRBAI.analyzeTraffic({
                entries,
                metrics,
                supabaseUrl: SUPABASE_URL,
                supabaseAnonKey: SUPABASE_ANON_KEY,
              });
              if (res.ok) log("info", "ai", `Analyzer IA: ${entries.length} entries`);
              else log("warn", "ai", `Analyzer IA falhou: ${res.error}`);
              sendResponse(res);
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_AI_MUTATE":
          case "BURP_AI_DIAGNOSE":
          case "BURP_AI_CLASSIFY": {
            try {
              if (!self.HyperRBAI) {
                sendResponse({ ok: false, error: "AI client não carregado." });
                return;
              }
              if (message.type === "BURP_AI_CLASSIFY" && Array.isArray(message.payload?.items) && message.payload.items.length) {
                const res = await self.HyperRBAI.classifyBatch({ items: message.payload.items });
                log(res.ok ? "info" : "warn", "ai", `${message.type}: ${res.ok ? `batch(${message.payload.items.length})` : res.error}`);
                sendResponse(res);
                return;
              }
              const entryId = message.payload?.entryId;
              let entry = entryId ? state.network.find((n) => n.id === entryId) : null;
              // Scripts (Bloco B) e callers externos podem mandar o objeto inteiro
              // em vez de um entryId — aceitamos ambos os formatos.
              if (!entry) {
                const candidate = message.payload?.entry || message.payload?.request;
                if (candidate && typeof candidate === "object") entry = candidate;
              }
              if (!entry) { sendResponse({ ok: false, error: "Request não encontrada." }); return; }
              const fn = message.type === "BURP_AI_MUTATE" ? self.HyperRBAI.suggestMutations
                       : message.type === "BURP_AI_DIAGNOSE" ? self.HyperRBAI.diagnoseFailedReplay
                       : self.HyperRBAI.classifyAction;
              const res = await fn({
                entry,
                supabaseUrl: SUPABASE_URL,
                supabaseAnonKey: SUPABASE_ANON_KEY,
              });
              log(res.ok ? "info" : "warn", "ai", `${message.type}: ${res.ok ? "ok" : res.error}`);
              sendResponse(res);
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_CLEAR_NETWORK": {
            state.network = [];
            schedulePersist();
            sendResponse({ ok: true, state: getPublicState() });
            return;
          }
          case "BURP_EXPORT_HAR": {
            try {
              sendResponse({ ok: true, har: buildHar() });
            } catch (error) {
              sendResponse({ ok: false, error: error.message });
            }
            return;
          }
          case "BURP_GET_CREDENTIALS": {
            // Retorna credenciais capturadas em claro para preenchimento de presets
            // no Composer. NUNCA é broadcast — só responde sob solicitação explícita
            // do sidepanel da própria extensão.
            sendResponse({
              ok: true,
              credentials: {
                license_key: state.license.key || null,
                device_id: state.deviceId || null,
                session_id: state.license.sessionId || null,
                lovable_token: state.auth.bearerToken || null,
                project_id: state.auth.projectId || null,
                workspace_id: state.auth.workspaceId || null,
                hb_license: state.hbLicense || null,
                supabase_url: SUPABASE_URL,
                supabase_anon_key: SUPABASE_ANON_KEY,
              },
            });
            return;
          }
          case "BURP_SET_HB_LICENSE": {
            const value = String(message.payload?.license || "").trim();
            state.hbLicense = value || null;
            await chrome.storage.local.set({ qlrb_hb_license: state.hbLicense });
            schedulePersist();
            broadcast({ type: "BURP_AUTH_UPDATED", payload: getPublicState() });
            sendResponse({ ok: true, hbLicense: { hasKey: Boolean(state.hbLicense), preview: maskValue(state.hbLicense) } });
            return;
          }
          case "BURP_WS_FRAME": {
            if (!state.isCapturing) { sendResponse({ ok: true, dropped: true }); return; }
            const f = message.payload || {};
            // Anexa frame ao entry da conexão (kind=ws). Cria placeholder se ainda não existir.
            let entry = state.network.find((n) => n.id === f.connId);
            if (!entry) {
              entry = {
                id: f.connId,
                url: f.url || "",
                method: "WS",
                kind: "ws",
                source: "websocket",
                status: 101,
                statusText: "Switching Protocols",
                requestHeaders: {},
                requestBody: null,
                responseHeaders: {},
                responseBody: "",
                wsFrames: [],
                startedAt: f.timestamp || new Date().toISOString(),
                timingMs: 0,
                responseSize: 0,
              };
              state.network.unshift(entry);
            }
            entry.wsFrames = entry.wsFrames || [];
            if (entry.wsFrames.length < MAX_WS_FRAMES_PER_CONN) {
              entry.wsFrames.push({
                direction: f.direction,
                payload: f.payload,
                timestamp: f.timestamp,
                frameIndex: f.frameIndex,
              });
            }
            if (f.direction === "close") {
              entry.statusText = "Closed";
              entry.timingMs = f.durationMs || entry.timingMs;
            }
            entry.responseSize = (entry.wsFrames || []).reduce((acc, x) => acc + (x.payload ? String(x.payload).length : 0), 0);
            schedulePersist();
            broadcast({ type: "BURP_NETWORK_UPDATED", payload: getPublicState() });
            sendResponse({ ok: true });
            return;
          }
          default: {
            sendResponse({ ok: false, error: "Mensagem desconhecida" });
          }
        }
      })();
      return true;
    });

    // Action click → abre/fecha painel flutuante na aba ativa.
    // Fallback: se não for página Lovable (content script ausente), abre janela popup.
    chrome.action.onClicked.addListener(async (tab) => {
      if (!tab?.id) return;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "BURP_TOGGLE_FLOATING" });
      } catch {
        // Sem content script → abrir como janela popup standalone.
        try {
          await chrome.windows.create({
            url: chrome.runtime.getURL("burp_sidepanel.html"),
            type: "popup",
            width: 1100,
            height: 760,
          });
        } catch (err) {
          log("error", "ui", "Falha ao abrir popup standalone.", { message: err?.message });
        }
      }
    });

    bootstrap().catch((error) => {
      state.diagnostics.serviceWorker = { status: "error", detail: error.message };
      log("error", "startup", "Falha fatal ao iniciar o service worker.", { message: error.message });
    });
