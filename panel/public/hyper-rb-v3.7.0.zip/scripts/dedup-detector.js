// ============================================================
// Hyper RB · Scripts · #16 dedup-detector
// Detecta requests duplicadas / redundantes (mesmo method+url+body
// num intervalo curto) — sinaliza desperdício de chamadas.
// Sem IA, sem rede.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  const WINDOW_MS = 10_000; // requests dentro de 10s são candidatas a duplicata

  function bodyHash(s) {
    if (!s) return "∅";
    let h = 0;
    for (let i = 0; i < s.length; i++) {
      h = (h * 31 + s.charCodeAt(i)) | 0;
    }
    return String(h);
  }

  function keyOf(req) {
    let host = "", path = "";
    try {
      const u = new URL(req.url);
      host = u.host;
      path = u.pathname;
    } catch { path = req.url || ""; }
    return `${req.method || "GET"} ${host}${path} #${bodyHash(req.reqBody || "")}`;
  }

  function analyze(requests) {
    const groups = new Map();
    for (const r of requests) {
      const k = keyOf(r);
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(r);
    }

    const dupes = [];
    for (const [k, list] of groups) {
      if (list.length < 2) continue;
      list.sort((a, b) => (a.startedAt || 0) - (b.startedAt || 0));
      let bursts = 0;
      for (let i = 1; i < list.length; i++) {
        const dt = (list[i].startedAt || 0) - (list[i - 1].startedAt || 0);
        if (dt <= WINDOW_MS) bursts++;
      }
      const span = (list[list.length - 1].startedAt || 0) - (list[0].startedAt || 0);
      dupes.push({
        key: k,
        count: list.length,
        bursts,
        spanMs: span,
        firstAt: list[0].startedAt,
        lastAt: list[list.length - 1].startedAt,
        sampleId: list[0].id,
      });
    }

    dupes.sort((a, b) => (b.bursts - a.bursts) || (b.count - a.count));
    return {
      generatedAt: Date.now(),
      totalRequests: requests.length,
      totalGroups: groups.size,
      duplicatedGroups: dupes.length,
      groups: dupes,
    };
  }

  function render(report) {
    if (!report.groups.length) {
      return `<div class="hrb-empty">Nenhuma request duplicada detectada (janela ${WINDOW_MS / 1000}s).</div>`;
    }
    const rows = report.groups.map((g) => `
      <tr>
        <td><code>${S.esc(g.key)}</code></td>
        <td>${g.count}</td>
        <td>${g.bursts > 0 ? `<span class="hrb-tag hrb-tag-warn">${g.bursts} em rajada</span>` : "—"}</td>
        <td>${(g.spanMs / 1000).toFixed(1)}s</td>
      </tr>
    `).join("");
    return `
      <div class="hrb-summary">
        ${report.duplicatedGroups} grupos duplicados de ${report.totalGroups} (${report.totalRequests} requests).
      </div>
      <table class="hrb-table">
        <thead><tr><th>Endpoint + body</th><th>#</th><th>Rajada</th><th>Span</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push({
    id: 16,
    slug: "dedup-detector",
    title: "Dedup Detector",
    description: "Detecta requests duplicadas/redundantes em janela curta.",
    needsAI: false,
    needsNetwork: false,
    run(ctx) {
      const requests = (ctx && ctx.requests) || [];
      const report = analyze(requests);
      return { html: render(report), data: report };
    },
  });
})();