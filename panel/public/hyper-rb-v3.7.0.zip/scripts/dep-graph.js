// ============================================================
// Hyper RB · Script #4 · dep-graph
// Grafo de dependências (janela 5s) com layout force-directed.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;
  if (!S) { console.error("[dep-graph] HYPER_RB_SHARED ausente"); return; }

  const WINDOW_MS = 5000;
  const MAX_NODES = 200;
  const ITER = 100;

  function normalizePath(p) {
    if (!p) return "/";
    return p.split("/").map((seg) => {
      if (!seg) return seg;
      if (/^\d+$/.test(seg)) return "{id}";
      if (/^[0-9a-f-]{8,}$/i.test(seg)) return "{id}";
      return seg;
    }).join("/") || "/";
  }

  function buildGraph(requests) {
    const sorted = requests.slice().sort((a, b) => (a.ts || 0) - (b.ts || 0));
    const nodeKey = (r) => `${r.method} ${normalizePath(r.pathname)}`;
    const nodes = new Map(); // key -> {key, host, count, degree}
    const edges = new Map(); // "a||b" -> {a, b, weight}

    for (let i = 0; i < sorted.length; i++) {
      const r = sorted[i];
      const k = nodeKey(r);
      const n = nodes.get(k) || { key: k, host: r.host, count: 0, degree: 0 };
      n.count++;
      nodes.set(k, n);
      for (let j = i - 1; j >= 0; j--) {
        const p = sorted[j];
        if ((r.ts - p.ts) > WINDOW_MS) break;
        const pk = nodeKey(p);
        if (pk === k) continue;
        const ek = `${pk}||${k}`;
        const e = edges.get(ek) || { a: pk, b: k, weight: 0 };
        e.weight++;
        edges.set(ek, e);
      }
    }

    // Cap to MAX_NODES by count
    let nodeArr = Array.from(nodes.values()).sort((a, b) => b.count - a.count).slice(0, MAX_NODES);
    const keep = new Set(nodeArr.map((n) => n.key));
    const edgeArr = Array.from(edges.values()).filter((e) => keep.has(e.a) && keep.has(e.b));
    for (const e of edgeArr) {
      const a = nodes.get(e.a); const b = nodes.get(e.b);
      if (a) a.degree++;
      if (b) b.degree++;
    }
    return { nodes: nodeArr, edges: edgeArr };
  }

  function hashColor(s) {
    let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    const hue = Math.abs(h) % 360;
    return `hsl(${hue}, 70%, 60%)`;
  }

  function layout(graph, w, h) {
    const N = graph.nodes.length;
    if (!N) return [];
    const area = w * h;
    const k = Math.sqrt(area / N);
    const pos = graph.nodes.map(() => ({ x: Math.random() * w, y: Math.random() * h, dx: 0, dy: 0 }));
    const idx = new Map(graph.nodes.map((n, i) => [n.key, i]));
    let t = w / 10;
    const cool = t / ITER;

    for (let it = 0; it < ITER; it++) {
      // repulsion
      for (let i = 0; i < N; i++) { pos[i].dx = 0; pos[i].dy = 0; }
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const dx = pos[i].x - pos[j].x;
          const dy = pos[i].y - pos[j].y;
          const d2 = dx * dx + dy * dy + 0.01;
          const f = (k * k) / d2;
          const fx = dx * f, fy = dy * f;
          pos[i].dx += fx; pos[i].dy += fy;
          pos[j].dx -= fx; pos[j].dy -= fy;
        }
      }
      // attraction
      for (const e of graph.edges) {
        const i = idx.get(e.a), j = idx.get(e.b);
        if (i == null || j == null) continue;
        const dx = pos[i].x - pos[j].x;
        const dy = pos[i].y - pos[j].y;
        const d = Math.sqrt(dx * dx + dy * dy) + 0.01;
        const f = (d * d) / k;
        const fx = (dx / d) * f, fy = (dy / d) * f;
        pos[i].dx -= fx; pos[i].dy -= fy;
        pos[j].dx += fx; pos[j].dy += fy;
      }
      // move
      for (let i = 0; i < N; i++) {
        const d = Math.sqrt(pos[i].dx * pos[i].dx + pos[i].dy * pos[i].dy) + 0.01;
        pos[i].x += (pos[i].dx / d) * Math.min(d, t);
        pos[i].y += (pos[i].dy / d) * Math.min(d, t);
        pos[i].x = Math.max(20, Math.min(w - 20, pos[i].x));
        pos[i].y = Math.max(20, Math.min(h - 20, pos[i].y));
      }
      t = Math.max(1, t - cool);
    }
    return pos;
  }

  const SCRIPT = {
    id: 4,
    slug: "dep-graph",
    name: "Grafo de Dependências",
    description: "Inferência de dependências entre requests via janela deslizante de 5s.",
    icon: "🕸️",
    needsAI: false,
    needsNetwork: false,
    minRequests: 5,

    async run(ctx) {
      if (!ctx.requests || ctx.requests.length < 5) {
        return { ok: false, error: "Capture pelo menos 5 requests antes." };
      }
      const graph = buildGraph(ctx.requests);
      if (!graph.nodes.length) return { ok: false, error: "Sem nós válidos." };

      return {
        ok: true,
        summary: `${graph.nodes.length} nós · ${graph.edges.length} arestas`,
        render(mountEl) {
          mountEl.innerHTML = `<div class="hyper-rb-loading">Calculando layout…</div>`;
          const W = 720, H = 480;
          const run = () => {
            const pos = layout(graph, W, H);
            const idx = new Map(graph.nodes.map((n, i) => [n.key, i]));
            const maxW = graph.edges.reduce((m, e) => Math.max(m, e.weight), 1);
            const edgesSvg = graph.edges.map((e) => {
              const a = pos[idx.get(e.a)], b = pos[idx.get(e.b)];
              if (!a || !b) return "";
              const op = 0.2 + 0.6 * (e.weight / maxW);
              return `<line x1="${a.x.toFixed(1)}" y1="${a.y.toFixed(1)}" x2="${b.x.toFixed(1)}" y2="${b.y.toFixed(1)}" stroke="rgba(191,0,255,${op.toFixed(2)})" stroke-width="${Math.min(3, 0.5 + e.weight / maxW * 2.5).toFixed(2)}"/>`;
            }).join("");
            const nodesSvg = graph.nodes.map((n, i) => {
              const p = pos[i]; if (!p) return "";
              const r = 4 + Math.min(10, Math.log2(1 + n.count) * 2);
              const c = hashColor(n.host || "?");
              return `<g class="hyper-rb-node" data-key="${S.escapeHtml(n.key)}"><circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${r.toFixed(1)}" fill="${c}" stroke="rgba(255,255,255,0.4)" stroke-width="1"/><title>${S.escapeHtml(n.key)} · ${n.count}× · ${S.escapeHtml(n.host)}</title></g>`;
            }).join("");
            mountEl.innerHTML = `
              <div style="display:flex;flex-direction:column;gap:8px;">
                <div style="font-size:11px;color:rgba(255,255,255,0.6);">
                  ${graph.nodes.length} nós · ${graph.edges.length} arestas · janela ${WINDOW_MS}ms
                </div>
                <div style="background:rgba(18,18,20,0.7);border:1px solid rgba(191,0,255,0.3);border-radius:8px;overflow:hidden;">
                  <svg viewBox="0 0 ${W} ${H}" width="100%" style="display:block;">
                    ${edgesSvg}${nodesSvg}
                  </svg>
                </div>
              </div>`;
          };
          if (typeof requestIdleCallback === "function") requestIdleCallback(run, { timeout: 500 });
          else setTimeout(run, 0);
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();