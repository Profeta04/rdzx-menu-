/* eslint-disable no-undef */
/**
 * Hyper RB · AI client (background) — Groq direct.
 * Sanitiza a request e chama Groq diretamente (mesmo padrão que o
 * HyperBuild parent usa em proxyGroq). Substitui a edge function /ai.
 * Mantém cache LRU (32) + rate limit local (20/min).
 *
 * NUNCA expor: Authorization, Cookie, set-cookie, x-api-key,
 * license_key, lovable_token, tokens em query string.
 *
 * Expõe: self.HyperRBAI = {
 *   explainRequest, suggestRecipe, analyzeTraffic,
 *   suggestMutations, diagnoseFailedReplay, classifyAction,
 *   sanitizeEntry, clearCache
 * }
 */
(function (root) {
  "use strict";

  // Roteamos via edge function /ai (Lovable AI Gateway) — sem chave no client.
  // O background injeta supabaseUrl/supabaseAnonKey nos params de cada chamada.
  const MAX_CACHE = 32;
  const MAX_PAYLOAD_CHARS = 30_000;
  const MAX_BODY_CHARS_PER_FIELD = 4_000;
  const RATE_LIMIT_WINDOW_MS = 60_000;
  const RATE_LIMIT_MAX = 20;

  const SENSITIVE_HEADER_PATTERNS = [
    /^authorization$/i, /^cookie$/i, /^set-cookie$/i,
    /^x-api-key$/i, /^apikey$/i, /^proxy-authorization$/i,
    /^x-license-key$/i,
  ];
  const SENSITIVE_BODY_KEYS = new Set([
    "license_key", "lovable_token", "bearer_token", "access_token",
    "refresh_token", "session_token", "password", "secret",
    "api_key", "apikey",
  ]);
  const SENSITIVE_QUERY_KEYS = [
    "token", "access_token", "refresh_token", "license_key", "apikey", "api_key",
  ];

  const cache = new Map();
  const recentCalls = [];

  function mask(v) {
    const s = String(v ?? "");
    if (!s) return "";
    if (s.length <= 8) return "***";
    return `${s.slice(0, 4)}***${s.slice(-4)}`;
  }
  function sanitizeHeaders(h) {
    if (!h || typeof h !== "object") return {};
    const out = {};
    for (const [k, v] of Object.entries(h)) {
      const sens = SENSITIVE_HEADER_PATTERNS.some((re) => re.test(k));
      out[k] = sens ? mask(v) : String(v).slice(0, 500);
    }
    return out;
  }
  function sanitizeUrl(url) {
    if (!url || typeof url !== "string") return url || "";
    try {
      const u = new URL(url);
      for (const k of SENSITIVE_QUERY_KEYS) if (u.searchParams.has(k)) u.searchParams.set(k, "***");
      return u.toString();
    } catch { return url; }
  }
  function sanitizeBodyDeep(value, depth = 0) {
    if (depth > 6) return "[depth-limit]";
    if (value == null) return value;
    if (typeof value === "string") {
      if (/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(value)) return mask(value);
      return value.length > MAX_BODY_CHARS_PER_FIELD
        ? value.slice(0, MAX_BODY_CHARS_PER_FIELD) + "…[truncated]" : value;
    }
    if (Array.isArray(value)) return value.slice(0, 20).map((v) => sanitizeBodyDeep(v, depth + 1));
    if (typeof value === "object") {
      const out = {};
      for (const [k, v] of Object.entries(value)) {
        out[k] = SENSITIVE_BODY_KEYS.has(k.toLowerCase()) ? mask(v) : sanitizeBodyDeep(v, depth + 1);
      }
      return out;
    }
    return value;
  }
  function parseMaybeJson(v) {
    if (v == null) return null;
    if (typeof v === "object") return v;
    if (typeof v !== "string") return v;
    try { return JSON.parse(v); } catch { return v; }
  }
  function sanitizeEntry(entry) {
    if (!entry || typeof entry !== "object") return null;
    return {
      method: String(entry.method || "GET"),
      url: sanitizeUrl(entry.url),
      status: entry.status ?? 0,
      statusText: entry.statusText ?? "",
      timingMs: entry.timingMs ?? 0,
      requestHeaders: sanitizeHeaders(entry.requestHeaders),
      responseHeaders: sanitizeHeaders(entry.responseHeaders),
      requestBody: sanitizeBodyDeep(parseMaybeJson(entry.requestBody)),
      responseBody: sanitizeBodyDeep(parseMaybeJson(entry.responseBody)),
    };
  }
  function cacheKey(action, payload) {
    return `${action}::${payload.method}::${payload.url}::${(payload.status || 0)}`;
  }
  function checkRateLimit() {
    const now = Date.now();
    while (recentCalls.length && now - recentCalls[0] > RATE_LIMIT_WINDOW_MS) recentCalls.shift();
    if (recentCalls.length >= RATE_LIMIT_MAX) return false;
    recentCalls.push(now);
    return true;
  }
  function putCache(key, value) {
    if (cache.has(key)) cache.delete(key);
    cache.set(key, value);
    while (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
  }
  function getCache(key) {
    if (!cache.has(key)) return null;
    const v = cache.get(key);
    cache.delete(key); cache.set(key, v);
    return v;
  }
  function clearCache() { cache.clear(); recentCalls.length = 0; }

  // Last-known Supabase endpoint info (injetado pelo background no 1º call).
  let _supabaseUrl = "";
  let _supabaseAnonKey = "";

  async function callAiEdge(action, payload, opts = {}) {
    if (!checkRateLimit()) return { ok: false, error: "Rate limit local atingido (20/min). Aguarde." };
    if (opts.supabaseUrl) _supabaseUrl = opts.supabaseUrl;
    if (opts.supabaseAnonKey) _supabaseAnonKey = opts.supabaseAnonKey;
    if (!_supabaseUrl || !_supabaseAnonKey) {
      return { ok: false, error: "Edge /ai não configurado (faltam credenciais)." };
    }
    const userMsg = JSON.stringify(payload);
    if (userMsg.length > MAX_PAYLOAD_CHARS) return { ok: false, error: "Payload muito grande (limite 30KB)." };
    try {
      const res = await fetch(`${_supabaseUrl}/functions/v1/ai`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": _supabaseAnonKey,
          "Authorization": `Bearer ${_supabaseAnonKey}`,
        },
        body: JSON.stringify({ action, request: payload }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        return {
          ok: false,
          status: res.status,
          error: data?.message || data?.error || `HTTP ${res.status}`,
        };
      }
      // /ai retorna { ok, action, model, content?, recipe?, usage }
      if (action === "convert_to_composer_recipe") {
        return { ok: true, recipe: data?.recipe, usage: data?.usage };
      }
      return { ok: true, content: String(data?.content || "").trim(), usage: data?.usage };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  }

  async function explainRequest({ entry, supabaseUrl, supabaseAnonKey }) {
    if (!entry) return { ok: false, error: "Nenhuma request selecionada." };
    const sanitized = sanitizeEntry(entry);
    const key = cacheKey("explain_lovable_request", sanitized);
    const cached = getCache(key);
    if (cached) return { ok: true, content: cached, cached: true };
    const res = await callAiEdge("explain_lovable_request", sanitized, { supabaseUrl, supabaseAnonKey });
    if (res.ok && res.content) putCache(key, res.content);
    return res;
  }

  async function suggestRecipe({ entry, supabaseUrl, supabaseAnonKey }) {
    if (!entry) return { ok: false, error: "Nenhuma request selecionada." };
    const sanitized = sanitizeEntry(entry);
    const key = cacheKey("convert_to_composer_recipe", sanitized);
    const cached = getCache(key);
    if (cached) return { ok: true, recipe: cached, cached: true };
    const res = await callAiEdge("convert_to_composer_recipe", sanitized, { supabaseUrl, supabaseAnonKey });
    if (!res.ok) return res;
    const recipe = res.recipe;
    if (!recipe || typeof recipe !== "object") return { ok: false, error: "Recipe não retornado pela IA." };
    putCache(key, recipe);
    return { ok: true, recipe, usage: res.usage };
  }

  async function analyzeTraffic({ entries, metrics, limit = 50, supabaseUrl, supabaseAnonKey }) {
    if (!Array.isArray(entries) || !entries.length) return { ok: false, error: "Sem requests para analisar." };
    const sliced = entries.slice(0, limit).map((e) => {
      const s = sanitizeEntry(e) || {};
      return {
        method: s.method, url: s.url, status: s.status, timingMs: s.timingMs,
        contentType: s.responseHeaders?.["content-type"] || s.responseHeaders?.["Content-Type"] || "",
      };
    });
    // Agregados pré-calculados — economiza tokens e dá insight melhor à IA.
    const byHost = {};
    const byStatus = {};
    let errorCount = 0, totalMs = 0, msSamples = 0;
    for (const e of entries) {
      try { const u = new URL(e.url); byHost[u.host] = (byHost[u.host] || 0) + 1; } catch {}
      const st = Number(e.status || 0);
      byStatus[st] = (byStatus[st] || 0) + 1;
      if (st === 0 || st >= 400) errorCount++;
      if (typeof e.timingMs === "number") { totalMs += e.timingMs; msSamples++; }
    }
    const enriched = {
      total: entries.length,
      sampled: sliced.length,
      errorRate: entries.length ? +(errorCount / entries.length).toFixed(3) : 0,
      avgMs: msSamples ? Math.round(totalMs / msSamples) : 0,
      byHost, byStatus,
      metrics: metrics || null,
      entries: sliced,
    };
    return callAiEdge("analyze_network_traffic", enriched, { supabaseUrl, supabaseAnonKey });
  }

  async function suggestMutations({ entry, supabaseUrl, supabaseAnonKey }) {
    if (!entry) return { ok: false, error: "Nenhuma request selecionada." };
    const sanitized = sanitizeEntry(entry);
    const key = cacheKey("suggest_mutations", sanitized);
    const cached = getCache(key);
    if (cached) return { ok: true, content: cached, cached: true };
    const res = await callAiEdge("suggest_mutations", sanitized, { supabaseUrl, supabaseAnonKey });
    if (res.ok && res.content) putCache(key, res.content);
    return res;
  }

  async function diagnoseFailedReplay({ entry, supabaseUrl, supabaseAnonKey }) {
    if (!entry) return { ok: false, error: "Nenhuma request selecionada." };
    return callAiEdge("diagnose_failed_replay", sanitizeEntry(entry), { supabaseUrl, supabaseAnonKey });
  }

  async function classifyAction({ entry, supabaseUrl, supabaseAnonKey }) {
    if (!entry) return { ok: false, error: "Nenhuma request selecionada." };
    const sanitized = sanitizeEntry(entry);
    const key = cacheKey("classify_action_ptbr", sanitized);
    const cached = getCache(key);
    if (cached) return { ok: true, content: cached, cached: true };
    const res = await callAiEdge("classify_action_ptbr", sanitized, { supabaseUrl, supabaseAnonKey });
    if (res.ok && res.content) putCache(key, res.content);
    return res;
  }

  async function classifyBatch({ items, supabaseUrl, supabaseAnonKey }) {
    if (!Array.isArray(items) || !items.length) {
      return { ok: false, error: "Nenhum item para classificar." };
    }

    const normalized = items.slice(0, 25).map((item) => ({
      id: String(item?.id || ""),
      method: String(item?.method || "GET").toUpperCase(),
      url: sanitizeUrl(String(item?.url || "")),
      bodyExcerpt: typeof item?.bodyExcerpt === "string"
        ? item.bodyExcerpt.slice(0, 1000)
        : "",
    }));

    const results = [];
    for (const item of normalized) {
      const res = await callAiEdge("classify_action_ptbr", item, { supabaseUrl, supabaseAnonKey });
      if (!res.ok) return res;
      results.push({
        id: item.id,
        categoria: String(res.content || "Não classificado").trim() || "Não classificado",
      });
    }

    return { ok: true, data: { items: results } };
  }

  root.HyperRBAI = {
    explainRequest, suggestRecipe, analyzeTraffic,
    suggestMutations, diagnoseFailedReplay, classifyAction, classifyBatch,
    sanitizeEntry, clearCache,
  };
})(typeof self !== "undefined" ? self : globalThis);
