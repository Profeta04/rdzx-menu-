// ============================================================================
//  Hyper RB — Chains (Composer Sequence Mode)
// ----------------------------------------------------------------------------
//  Encadeia N requests com passagem de dados via template `{{stepId.path}}`,
//  `{{vars.x}}`, `{{ctx.token}}`, `{{ctx.projectId}}`.
//
//  Usado em fluxos multi-step reais (ex.: upload de arquivos da HyperBuild
//  Pro: generate-upload-url → PUT signed → register-file).
//
//  Carregado tanto pelo background (executor) quanto pelo sidepanel (UI).
//  Não tem dependências externas.
// ============================================================================
(function (root) {
  "use strict";

  const HARD_LIMITS = Object.freeze({
    MAX_STEPS: 10,
    MAX_TOTAL_BYTES: 5 * 1024 * 1024,
    DEFAULT_STEP_TIMEOUT_MS: 30000,
    GLOBAL_DEADLINE_MS: 60000,
    MAX_RETRY: 3,
  });

  // --------------------------------------------------------------------------
  // JSONPath subset: $.a.b[0].c — sem libs externas.
  // --------------------------------------------------------------------------
  function jsonPath(obj, path) {
    if (obj == null || !path || typeof path !== "string") return undefined;
    let p = path.trim();
    if (p.startsWith("$")) p = p.slice(1);
    if (p.startsWith(".")) p = p.slice(1);
    if (!p) return obj;
    // tokenize: foo.bar[0].baz → ["foo","bar","0","baz"]
    const tokens = [];
    let buf = "";
    for (let i = 0; i < p.length; i++) {
      const c = p[i];
      if (c === ".") {
        if (buf) { tokens.push(buf); buf = ""; }
      } else if (c === "[") {
        if (buf) { tokens.push(buf); buf = ""; }
        const end = p.indexOf("]", i);
        if (end === -1) return undefined;
        tokens.push(p.slice(i + 1, end).replace(/^["']|["']$/g, ""));
        i = end;
      } else {
        buf += c;
      }
    }
    if (buf) tokens.push(buf);
    let cur = obj;
    for (const tok of tokens) {
      if (cur == null) return undefined;
      cur = cur[tok];
    }
    return cur;
  }

  // --------------------------------------------------------------------------
  // Template engine: resolve {{a.b.c}} contra um contexto plano.
  // O contexto tem shape:
  //   { vars: {...}, ctx: {token, projectId, ...}, <stepId>: {status, body, json, headers, extracted: {...}} }
  // Tokens não resolvidos viram string vazia e ficam registrados em `missing`.
  // --------------------------------------------------------------------------
  function resolveTemplate(input, context, missing) {
    if (input == null) return input;
    if (typeof input === "string") {
      return input.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (full, expr) => {
        const v = jsonPath(context, expr);
        if (v === undefined || v === null) {
          if (missing && !missing.includes(expr)) missing.push(expr);
          return "";
        }
        return typeof v === "object" ? JSON.stringify(v) : String(v);
      });
    }
    if (Array.isArray(input)) {
      return input.map((v) => resolveTemplate(v, context, missing));
    }
    if (typeof input === "object") {
      const out = {};
      for (const k of Object.keys(input)) out[k] = resolveTemplate(input[k], context, missing);
      return out;
    }
    return input;
  }

  // --------------------------------------------------------------------------
  // Validação estrutural da chain. Retorna `{ valid, errors[] }`.
  // --------------------------------------------------------------------------
  function validateChain(chain) {
    const errors = [];
    if (!chain || typeof chain !== "object") {
      return { valid: false, errors: ["Chain inválida (não é objeto)."] };
    }
    if (!Array.isArray(chain.steps) || chain.steps.length === 0) {
      errors.push("Chain precisa ter pelo menos 1 step.");
    }
    if (chain.steps && chain.steps.length > HARD_LIMITS.MAX_STEPS) {
      errors.push(`Limite máximo de ${HARD_LIMITS.MAX_STEPS} steps por chain.`);
    }
    const ids = new Set();
    (chain.steps || []).forEach((step, idx) => {
      if (!step || typeof step !== "object") {
        errors.push(`Step #${idx + 1} inválido.`);
        return;
      }
      if (!step.id || typeof step.id !== "string" || !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(step.id)) {
        errors.push(`Step #${idx + 1}: 'id' obrigatório (letras/números/underscore, começar com letra).`);
      } else if (ids.has(step.id)) {
        errors.push(`Step #${idx + 1}: id duplicado "${step.id}".`);
      } else {
        ids.add(step.id);
      }
      if (!step.url || typeof step.url !== "string") {
        errors.push(`Step "${step.id || idx + 1}": 'url' obrigatória.`);
      }
      if (step.method && typeof step.method !== "string") {
        errors.push(`Step "${step.id}": 'method' inválido.`);
      }
      if (step.retry != null && (typeof step.retry !== "number" || step.retry < 0 || step.retry > HARD_LIMITS.MAX_RETRY)) {
        errors.push(`Step "${step.id}": 'retry' precisa ser 0..${HARD_LIMITS.MAX_RETRY}.`);
      }
    });
    return { valid: errors.length === 0, errors };
  }

  // --------------------------------------------------------------------------
  // Templates embutidos (F.5). Cada template descreve um fluxo conhecido.
  // --------------------------------------------------------------------------
  const BUILTIN_TEMPLATES = [
    {
      id: "hb-upload-file",
      name: "Upload de arquivo (HyperBuild Pro)",
      description: "Fluxo de 3 steps: gera signed URL → PUT no storage → registra o arquivo.",
      chain: {
        name: "Upload arquivo HyperBuild Pro",
        vars: { filename: "exemplo.png", contentType: "image/png" },
        stopOnError: true,
        steps: [
          {
            id: "s1",
            name: "Gerar URL de upload",
            method: "POST",
            url: "https://api.lovable.dev/projects/{{ctx.projectId}}/files/generate-upload-url",
            headers: { "Content-Type": "application/json" },
            body: { filename: "{{vars.filename}}", content_type: "{{vars.contentType}}" },
            extract: { uploadUrl: "$.upload_url", fileId: "$.id" },
          },
          {
            id: "s2",
            name: "PUT no signed URL",
            method: "PUT",
            url: "{{s1.extracted.uploadUrl}}",
            headers: { "Content-Type": "{{vars.contentType}}" },
            body: null,
            bodySource: "raw",
          },
          {
            id: "s3",
            name: "Registrar arquivo",
            method: "POST",
            url: "https://api.lovable.dev/files/{{s1.extracted.fileId}}/register",
            headers: { "Content-Type": "application/json" },
            body: { uploaded: true },
          },
        ],
      },
    },
    {
      id: "hb-create-project",
      name: "Criar projeto Lovable",
      description: "Lista workspaces → cria projeto no primeiro workspace retornado.",
      chain: {
        name: "Criar projeto Lovable",
        vars: { projectName: "Novo projeto Hyper RB" },
        stopOnError: true,
        steps: [
          {
            id: "ws",
            name: "Listar workspaces",
            method: "GET",
            url: "https://api.lovable.dev/user/workspaces",
            extract: { workspaceId: "$.workspaces[0].id" },
          },
          {
            id: "create",
            name: "Criar projeto",
            method: "POST",
            url: "https://api.lovable.dev/workspaces/{{ws.extracted.workspaceId}}/projects",
            headers: { "Content-Type": "application/json" },
            body: { name: "{{vars.projectName}}" },
          },
        ],
      },
    },
    {
      id: "hb-heartbeat-ping",
      name: "Heartbeat → ping",
      description: "Heartbeat + ping de telemetria (exemplo simples de 2 steps).",
      chain: {
        name: "Heartbeat + ping",
        stopOnError: false,
        steps: [
          {
            id: "hb",
            name: "Heartbeat",
            method: "POST",
            url: "https://cvbgrjauqjawrsyknhyj.supabase.co/functions/v1/heartbeat",
            headers: { "Content-Type": "application/json" },
            body: { ping: true },
          },
          {
            id: "vx",
            name: "Validate (info-only)",
            method: "POST",
            url: "https://cvbgrjauqjawrsyknhyj.supabase.co/functions/v1/vx",
            headers: { "Content-Type": "application/json" },
            body: { license_key: "", device_id: "", heartbeat: true },
          },
        ],
      },
    },
  ];

  // --------------------------------------------------------------------------
  // Helpers expostos.
  // --------------------------------------------------------------------------
  const api = {
    HARD_LIMITS,
    jsonPath,
    resolveTemplate,
    validateChain,
    BUILTIN_TEMPLATES,

    /** Constrói um step "preparado" (URL/headers/body já resolvidos). */
    prepareStep(step, context) {
      const missing = [];
      const headers = step.headers ? resolveTemplate(step.headers, context, missing) : {};
      const url = resolveTemplate(String(step.url || ""), context, missing);
      const method = String(step.method || "GET").toUpperCase();
      let body = step.body;
      if (body !== null && body !== undefined) {
        body = resolveTemplate(body, context, missing);
      }
      return { url, method, headers, body, missing };
    },

    /** Aplica `extract: { alias: jsonpath }` ao body de resposta JSON. */
    extractFromResponse(extract, responseJson) {
      const out = {};
      if (!extract || typeof extract !== "object" || responseJson == null) return out;
      for (const [alias, path] of Object.entries(extract)) {
        out[alias] = jsonPath(responseJson, String(path));
      }
      return out;
    },
  };

  root.HyperRBChains = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof self !== "undefined" ? self : globalThis);
