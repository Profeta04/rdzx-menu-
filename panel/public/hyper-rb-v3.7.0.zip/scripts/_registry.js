// ============================================================
// Hyper RB · Scripts · _registry.js
// Singleton registry para os 12 scripts do Bloco B.
// Cada arquivo de script faz: window.HYPER_RB_SCRIPTS.push(SCRIPT)
// Esta lib expõe: list/get/run + montagem de contexto canônico.
// ============================================================
(function () {
  "use strict";

  if (!window.HYPER_RB_SCRIPTS) window.HYPER_RB_SCRIPTS = [];

  function getScripts() {
    // ordenado por id canônico (1..12)
    return [...window.HYPER_RB_SCRIPTS].sort((a, b) => (a.id || 99) - (b.id || 99));
  }

  function getScript(idOrSlug) {
    return getScripts().find((s) => s.id === idOrSlug || s.slug === idOrSlug);
  }

  function makeCtx({ requests, licenseKey, callAI, proxyFetch, slug }) {
    const S = window.HYPER_RB_SHARED;
    return {
      requests: Array.isArray(requests) ? requests : [],
      licenseKey: licenseKey || "",
      callAI: typeof callAI === "function" ? callAI : async () => ({ error: "ai_unavailable" }),
      proxyFetch: typeof proxyFetch === "function" ? proxyFetch : async () => ({ ok: false, error: "proxy_unavailable" }),
      storage: S.makeStorage(slug),
      log(level, msg, meta) {
        const tag = `[Hyper RB · ${slug}]`;
        if (level === "error") console.error(tag, msg, meta || "");
        else if (level === "warn") console.warn(tag, msg, meta || "");
        else console.log(tag, msg, meta || "");
      },
    };
  }

  async function runScript(idOrSlug, { rawRequests, licenseKey, callAI, proxyFetch } = {}) {
    const script = getScript(idOrSlug);
    if (!script) throw new Error(`Script não encontrado: ${idOrSlug}`);
    const S = window.HYPER_RB_SHARED;
    if (!S) throw new Error("HYPER_RB_SHARED não carregado — verifique a ordem dos scripts.");

    const requests = S.sanitizeAll(rawRequests);
    const ctx = makeCtx({ requests, licenseKey, callAI, proxyFetch, slug: script.slug });

    const t0 = performance.now();
    try {
      const result = await script.run(ctx);
      const ms = Math.round(performance.now() - t0);
      ctx.log("info", `concluído em ${ms}ms`);
      return { ok: true, ms, ...(result || {}) };
    } catch (e) {
      ctx.log("error", "falha durante execução", e);
      return { ok: false, error: (e && e.message) || String(e) };
    }
  }

  window.HYPER_RB_REGISTRY = { getScripts, getScript, runScript };
})();
