// ============================================================
// Hyper RB · Script #2 · payload-diff
// Rastreador de Mudanças de Payload — compara payloads consecutivos
// por endpoint canônico, com diff JSON recursivo ou fallback por linha.
// ============================================================
(function registerPayloadDiff() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · payload-diff] HYPER_RB_SHARED ausente");
    return;
  }

  const UUID_RE = /^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
  const HEXID_RE = /^[0-9a-f]{12,}$/i;
  const NUMID_RE = /^\d+$/;
  const LINE_DIFF_CAP = 200;

  function normalizeSegment(seg) {
    if (!seg) return seg;
    if (UUID_RE.test(seg)) return "{uuid}";
    if (HEXID_RE.test(seg)) return "{hexid}";
    if (NUMID_RE.test(seg)) return "{id}";
    return seg;
  }

  function normalizePath(pathname) {
    if (!pathname || pathname === "/") return "/";
    return "/" + pathname.split("/").filter(Boolean).map(normalizeSegment).join("/");
  }

  function groupKey(req) {
    return `${(req.method || "GET").toUpperCase()} ${req.host || ""}${normalizePath(req.pathname || "/")}`;
  }

  function safeJsonParse(value) {
    if (typeof value !== "string") return { ok: false, value: null };
    const trimmed = value.trim();
    if (!trimmed) return { ok: false, value: null };
    if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) return { ok: false, value: null };
    try {
      return { ok: true, value: JSON.parse(trimmed) };
    } catch {
      return { ok: false, value: null };
    }
  }

  function valuePreview(value) {
    if (value === undefined) return "undefined";
    if (value === null) return "null";
    if (typeof value === "string") return value;
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }

  function joinPath(base, segment) {
    if (typeof segment === "number") return `${base}[${segment}]`;
    if (!base) return String(segment);
    return `${base}.${segment}`;
  }

  function diffJson(prev, next, basePath, out) {
    if (prev === next) return;

    if (Array.isArray(prev) && Array.isArray(next)) {
      const max = Math.max(prev.length, next.length);
      for (let i = 0; i < max; i++) {
        const hasPrev = i < prev.length;
        const hasNext = i < next.length;
        const path = joinPath(basePath, i);
        if (!hasPrev && hasNext) {
          out.push({ path, op: "add", from: undefined, to: next[i] });
        } else if (hasPrev && !hasNext) {
          out.push({ path, op: "remove", from: prev[i], to: undefined });
        } else {
          diffJson(prev[i], next[i], path, out);
        }
      }
      return;
    }

    const prevIsObject = prev && typeof prev === "object" && !Array.isArray(prev);
    const nextIsObject = next && typeof next === "object" && !Array.isArray(next);

    if (prevIsObject && nextIsObject) {
      const keys = new Set([...Object.keys(prev), ...Object.keys(next)]);
      for (const key of keys) {
        const hasPrev = Object.prototype.hasOwnProperty.call(prev, key);
        const hasNext = Object.prototype.hasOwnProperty.call(next, key);
        const path = joinPath(basePath, key);
        if (!hasPrev && hasNext) {
          out.push({ path, op: "add", from: undefined, to: next[key] });
        } else if (hasPrev && !hasNext) {
          out.push({ path, op: "remove", from: prev[key], to: undefined });
        } else {
          diffJson(prev[key], next[key], path, out);
        }
      }
      return;
    }

    out.push({ path: basePath || "$", op: "change", from: prev, to: next });
  }

  function lcsDiff(prevText, nextText) {
    const a = String(prevText || "").split(/\r?\n/).slice(0, LINE_DIFF_CAP);
    const b = String(nextText || "").split(/\r?\n/).slice(0, LINE_DIFF_CAP);
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

    for (let i = m - 1; i >= 0; i--) {
      for (let j = n - 1; j >= 0; j--) {
        dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }

    const ops = [];
    let i = 0;
    let j = 0;
    while (i < m && j < n) {
      if (a[i] === b[j]) {
        ops.push({ type: "same", text: a[i] });
        i++;
        j++;
      } else if (dp[i + 1][j] >= dp[i][j + 1]) {
        ops.push({ type: "remove", text: a[i] });
        i++;
      } else {
        ops.push({ type: "add", text: b[j] });
        j++;
      }
    }
    while (i < m) ops.push({ type: "remove", text: a[i++] });
    while (j < n) ops.push({ type: "add", text: b[j++] });
    return ops;
  }

  function buildPairs(requests) {
    const groups = new Map();
    const sorted = requests.slice().sort((a, b) => Number(a.ts || 0) - Number(b.ts || 0));

    for (const req of sorted) {
      if (!req || !req.host) continue;
      const key = groupKey(req);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(req);
    }

    const results = [];
    for (const [key, items] of groups.entries()) {
      if (items.length < 2) continue;
      const pairs = [];
      for (let i = 1; i < items.length; i++) {
        const prev = items[i - 1];
        const next = items[i];
        const prevJson = safeJsonParse(prev.reqBody);
        const nextJson = safeJsonParse(next.reqBody);
        if (prevJson.ok && nextJson.ok) {
          const changes = [];
          diffJson(prevJson.value, nextJson.value, "", changes);
          if (changes.length) {
            pairs.push({
              type: "json",
              prevId: prev.id,
              nextId: next.id,
              prevTs: prev.ts,
              nextTs: next.ts,
              changes,
              prevBody: prev.reqBody || "",
              nextBody: next.reqBody || "",
            });
          }
        } else {
          const lineOps = lcsDiff(prev.reqBody || "", next.reqBody || "");
          const changedLines = lineOps.filter((op) => op.type !== "same");
          if (changedLines.length) {
            pairs.push({
              type: "text",
              prevId: prev.id,
              nextId: next.id,
              prevTs: prev.ts,
              nextTs: next.ts,
              lineOps,
              changeCount: changedLines.length,
              prevBody: prev.reqBody || "",
              nextBody: next.reqBody || "",
            });
          }
        }
      }
      if (pairs.length) {
        results.push({ key, method: items[0].method, host: items[0].host, path: normalizePath(items[0].pathname || "/"), pairs });
      }
    }

    results.sort((a, b) => b.pairs.length - a.pairs.length);
    return results;
  }

  function renderJsonChanges(changes) {
    return changes.map((change) => {
      const cls = change.op === "add" ? "pd-add" : change.op === "remove" ? "pd-remove" : "pd-change";
      const symbol = change.op === "add" ? "+" : change.op === "remove" ? "-" : "~";
      return `
        <div class="pd-line ${cls}">
          <span class="pd-symbol">${symbol}</span>
          <span class="pd-path">${S.escapeHtml(change.path || "$")}</span>
          <span class="pd-values">${S.escapeHtml(valuePreview(change.from))} → ${S.escapeHtml(valuePreview(change.to))}</span>
        </div>
      `;
    }).join("");
  }

  function renderTextChanges(lineOps) {
    return lineOps.map((line) => {
      const cls = line.type === "add" ? "pd-add" : line.type === "remove" ? "pd-remove" : "pd-same";
      const symbol = line.type === "add" ? "+" : line.type === "remove" ? "-" : " ";
      return `<div class="pd-line ${cls}"><span class="pd-symbol">${symbol}</span><span class="pd-text">${S.escapeHtml(line.text)}</span></div>`;
    }).join("");
  }

  function renderGroupList(groups) {
    return groups.map((group, idx) => `
      <button class="pd-group ${idx === 0 ? "active" : ""}" data-group-index="${idx}">
        <div class="pd-group-top">
          <span class="pd-method">${S.escapeHtml(group.method)}</span>
          <span class="pd-key">${S.escapeHtml(group.host)}${S.escapeHtml(group.path)}</span>
        </div>
        <div class="pd-group-meta">${group.pairs.length} mudança(s)</div>
      </button>
    `).join("");
  }

  function renderPairSelector(group) {
    return group.pairs.map((pair, idx) => `
      <button class="pd-pair ${idx === 0 ? "active" : ""}" data-pair-index="${idx}">
        ${S.escapeHtml(pair.prevId.slice(0, 8))} → ${S.escapeHtml(pair.nextId.slice(0, 8))}
      </button>
    `).join("");
  }

  function renderPairDetail(pair) {
    const summary = pair.type === "json"
      ? `${pair.changes.length} mudança(s) estruturais`
      : `${pair.changeCount} linha(s) alterada(s)`;

    return `
      <div class="pd-detail-head">
        <div class="pd-detail-meta">
          <span class="pd-badge">${S.escapeHtml(pair.type.toUpperCase())}</span>
          <span>${S.escapeHtml(summary)}</span>
        </div>
        <div class="pd-detail-ids">
          <span>${S.escapeHtml(pair.prevId)}</span>
          <span>→</span>
          <span>${S.escapeHtml(pair.nextId)}</span>
        </div>
      </div>
      <div class="pd-detail-body">
        ${pair.type === "json" ? renderJsonChanges(pair.changes) : renderTextChanges(pair.lineOps)}
      </div>
    `;
  }

  function buildStyles() {
    return `
      <style>
        .pd-wrap{display:grid;grid-template-columns:minmax(280px,340px) minmax(0,1fr);gap:14px;height:100%;padding:12px;color:#e8e8ec;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace}
        .pd-panel{background:rgba(18,18,20,.7);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,.06);border-radius:8px;min-height:0}
        .pd-side{display:flex;flex-direction:column;overflow:hidden}
        .pd-side-head,.pd-main-head{padding:12px 14px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:space-between;gap:8px}
        .pd-title{font-weight:800;color:#bf00ff;text-transform:uppercase;font-size:11px;letter-spacing:.08em}
        .pd-sub{color:rgba(255,255,255,.5);font-size:10px}
        .pd-groups{padding:8px;display:flex;flex-direction:column;gap:8px;overflow:auto}
        .pd-group,.pd-pair{width:100%;text-align:left;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);border-radius:8px;color:#ececf1;cursor:pointer}
        .pd-group{padding:10px}.pd-pair{padding:8px 10px;font-size:11px}
        .pd-group.active,.pd-pair.active{border-color:rgba(191,0,255,.45);background:rgba(191,0,255,.1)}
        .pd-group-top{display:flex;gap:8px;align-items:center}.pd-group-meta{margin-top:6px;color:rgba(255,255,255,.45);font-size:10px}
        .pd-method{font-weight:800;color:#bf00ff;font-size:10px}.pd-key{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .pd-main{display:flex;flex-direction:column;min-height:0}.pd-pairs{padding:10px 12px;display:flex;gap:8px;flex-wrap:wrap;border-bottom:1px solid rgba(255,255,255,.06)}
        .pd-content{padding:12px;overflow:auto}.pd-detail-head{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px}
        .pd-detail-meta,.pd-detail-ids{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.pd-badge{padding:3px 8px;border-radius:999px;background:rgba(191,0,255,.12);border:1px solid rgba(191,0,255,.32);font-size:10px;font-weight:800;color:#bf00ff}
        .pd-detail-body{display:flex;flex-direction:column;gap:6px}.pd-line{display:grid;grid-template-columns:14px minmax(120px,220px) minmax(0,1fr);gap:10px;padding:8px 10px;border-radius:6px;background:rgba(255,255,255,.02);align-items:start}
        .pd-symbol{font-weight:900}.pd-path{color:rgba(255,255,255,.72)}.pd-values,.pd-text{white-space:pre-wrap;word-break:break-word}
        .pd-add{color:#6de3a8;background:rgba(109,227,168,.07)}.pd-remove{color:#ff8b9f;background:rgba(255,139,159,.07)}.pd-change{color:#ffcf70;background:rgba(255,207,112,.07)}.pd-same{color:rgba(255,255,255,.35)}
        .pd-empty{padding:24px;color:rgba(255,255,255,.5);text-align:center}
        @media (max-width: 920px){.pd-wrap{grid-template-columns:1fr}.pd-line{grid-template-columns:14px 1fr}}
      </style>
    `;
  }

  const SCRIPT = {
    id: 2,
    slug: "payload-diff",
    name: "Rastreador de Payload",
    description: "Compara payloads consecutivos por endpoint e destaca mudanças JSON ou por linha.",
    icon: "🧬",
    needsAI: false,
    needsNetwork: false,
    minRequests: 2,

    async run(ctx) {
      if (!ctx.requests.length || ctx.requests.length < 2) {
        return { ok: false, error: "Capture pelo menos 2 requests antes de executar." };
      }

      const groups = buildPairs(ctx.requests);
      if (!groups.length) {
        return { ok: false, error: "Nenhuma mudança de payload encontrada entre requests consecutivas." };
      }

      return {
        ok: true,
        summary: `${groups.length} grupo(s) com mudanças de payload`,
        render(mountEl) {
          let activeGroup = 0;
          let activePair = 0;

          mountEl.innerHTML = `
            ${buildStyles()}
            <div class="pd-wrap">
              <div class="pd-panel pd-side">
                <div class="pd-side-head">
                  <div>
                    <div class="pd-title">Payload Diff</div>
                    <div class="pd-sub">${S.escapeHtml(groups.length)} grupos com mudanças</div>
                  </div>
                </div>
                <div class="pd-groups" data-region="groups">${renderGroupList(groups)}</div>
              </div>
              <div class="pd-panel pd-main">
                <div class="pd-main-head">
                  <div>
                    <div class="pd-title">Comparações</div>
                    <div class="pd-sub" data-region="subtitle"></div>
                  </div>
                </div>
                <div class="pd-pairs" data-region="pairs"></div>
                <div class="pd-content" data-region="content"></div>
              </div>
            </div>
          `;

          const groupsHost = mountEl.querySelector('[data-region="groups"]');
          const pairsHost = mountEl.querySelector('[data-region="pairs"]');
          const contentHost = mountEl.querySelector('[data-region="content"]');
          const subtitleHost = mountEl.querySelector('[data-region="subtitle"]');

          function paint() {
            const group = groups[activeGroup];
            const pair = group && group.pairs[activePair];
            groupsHost.querySelectorAll('.pd-group').forEach((btn, idx) => btn.classList.toggle('active', idx === activeGroup));
            if (!group || !pair) {
              pairsHost.innerHTML = "";
              contentHost.innerHTML = '<div class="pd-empty">Nenhum diff disponível.</div>';
              subtitleHost.textContent = "";
              return;
            }
            subtitleHost.textContent = `${group.method} ${group.host}${group.path} · ${group.pairs.length} comparação(ões)`;
            pairsHost.innerHTML = renderPairSelector(group);
            pairsHost.querySelectorAll('.pd-pair').forEach((btn, idx) => {
              btn.addEventListener('click', () => {
                activePair = idx;
                paint();
              });
            });
            contentHost.innerHTML = renderPairDetail(pair);
          }

          groupsHost.querySelectorAll('.pd-group').forEach((btn, idx) => {
            btn.addEventListener('click', () => {
              activeGroup = idx;
              activePair = 0;
              paint();
            });
          });

          paint();
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();