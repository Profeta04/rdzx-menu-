// ============================================================
// Hyper RB · Script #1 · cartographer
// Mapa de Endpoints — agrupa requests por host + pathTemplate + method,
// normaliza segmentos dinâmicos (UUIDs / numericIds) e infere um
// documento OpenAPI 3.1 navegável. Sem IA, sem rede.
// ============================================================
(function registerCartographer() {
  "use strict";
  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · cartographer] HYPER_RB_SHARED ausente");
    return;
  }

  // ---------- helpers ----------
  const UUID_RE = /^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
  const HEXID_RE = /^[0-9a-f]{12,}$/i;
  const NUMID_RE = /^\d+$/;
  const MAX_EXAMPLE_BYTES = 2 * 1024;

  function normalizeSegment(seg) {
    if (!seg) return seg;
    if (UUID_RE.test(seg)) return "{uuid}";
    if (HEXID_RE.test(seg)) return "{hexid}";
    if (NUMID_RE.test(seg)) return "{id}";
    return seg;
  }

  function pathTemplate(pathname) {
    if (!pathname || pathname === "/") return "/";
    return "/" + pathname
      .split("/")
      .filter(Boolean)
      .map(normalizeSegment)
      .join("/");
  }

  function pctile(sorted, p) {
    if (!sorted.length) return 0;
    const idx = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
    return sorted[idx];
  }

  function pickExample(body) {
    if (body == null) return undefined;
    const str = typeof body === "string" ? body : (() => {
      try { return JSON.stringify(body); } catch { return String(body); }
    })();
    if (str.length <= MAX_EXAMPLE_BYTES) return str;
    return str.slice(0, MAX_EXAMPLE_BYTES) + "…";
  }

  function safeJsonParse(s) {
    if (typeof s !== "string") return undefined;
    try { return JSON.parse(s); } catch { return undefined; }
  }

  // ---------- core ----------
  function buildMap(requests) {
    /** @type {Map<string, any>} */
    const groups = new Map();
    const hosts = new Set();

    for (const r of requests) {
      if (!r || !r.host || !r.method) continue;
      hosts.add(r.host);
      const tpl = pathTemplate(r.pathname || "/");
      const key = `${r.host}|${tpl}|${r.method.toUpperCase()}`;
      let g = groups.get(key);
      if (!g) {
        g = {
          host: r.host,
          path: tpl,
          method: r.method.toUpperCase(),
          count: 0,
          statuses: {},
          durations: [],
          contentTypes: new Set(),
          sampleReqBody: undefined,
          sampleResBody: undefined,
          sampleStatus: undefined,
          sampleResHeaders: undefined,
          sampleReqId: undefined,
        };
        groups.set(key, g);
      }
      g.count++;
      const st = typeof r.status === "number" ? r.status : 0;
      g.statuses[st] = (g.statuses[st] || 0) + 1;
      if (typeof r.durationMs === "number" && isFinite(r.durationMs)) {
        g.durations.push(r.durationMs);
      }
      const ct = (r.resHeaders && (r.resHeaders["content-type"] || r.resHeaders["Content-Type"])) || "";
      if (ct) g.contentTypes.add(String(ct).split(";")[0].trim());
      if (g.sampleReqBody === undefined && r.reqBody) g.sampleReqBody = pickExample(r.reqBody);
      if (g.sampleResBody === undefined && r.resBody) {
        g.sampleResBody = pickExample(r.resBody);
        g.sampleStatus = st || 200;
        g.sampleResHeaders = r.resHeaders || {};
        g.sampleReqId = r.id;
      }
    }

    // Finalize metrics
    const finalized = [];
    for (const g of groups.values()) {
      const sorted = g.durations.slice().sort((a, b) => a - b);
      const sum = sorted.reduce((a, b) => a + b, 0);
      finalized.push({
        ...g,
        contentTypes: [...g.contentTypes],
        avgMs: sorted.length ? Math.round(sum / sorted.length) : 0,
        p50Ms: Math.round(pctile(sorted, 50)),
        p95Ms: Math.round(pctile(sorted, 95)),
        durations: undefined,
      });
    }
    finalized.sort((a, b) => b.count - a.count);

    return { hosts: [...hosts].sort(), endpoints: finalized };
  }

  function toOpenApi(map) {
    const doc = {
      openapi: "3.1.0",
      info: {
        title: "Hyper RB — Inferred API",
        version: new Date().toISOString().slice(0, 10),
        description: `Inferido a partir de ${map.endpoints.reduce((a, e) => a + e.count, 0)} requests capturadas em ${map.hosts.length} host(s).`,
      },
      servers: map.hosts.map((h) => ({ url: `https://${h}` })),
      paths: {},
    };
    for (const e of map.endpoints) {
      const key = e.path;
      if (!doc.paths[key]) doc.paths[key] = {};
      const op = {
        summary: `${e.method} ${e.path}`,
        "x-hyper-rb": {
          host: e.host,
          count: e.count,
          avgMs: e.avgMs,
          p50Ms: e.p50Ms,
          p95Ms: e.p95Ms,
          contentTypes: e.contentTypes,
          statuses: e.statuses,
        },
        responses: {},
      };
      if (e.sampleReqBody) {
        const parsed = safeJsonParse(e.sampleReqBody);
        op.requestBody = {
          content: {
            "application/json": parsed !== undefined
              ? { example: parsed }
              : { example: e.sampleReqBody },
          },
        };
      }
      for (const [st, n] of Object.entries(e.statuses)) {
        op.responses[st] = {
          description: `${n} ocorrência(s)`,
        };
      }
      if (e.sampleResBody && e.sampleStatus) {
        const parsed = safeJsonParse(e.sampleResBody);
        const ct = (e.contentTypes[0] || "application/json");
        op.responses[String(e.sampleStatus)] = {
          ...(op.responses[String(e.sampleStatus)] || { description: "sample" }),
          content: {
            [ct]: parsed !== undefined ? { example: parsed } : { example: e.sampleResBody },
          },
        };
      }
      doc.paths[key][e.method.toLowerCase()] = op;
    }
    return doc;
  }

  // ---------- render ----------
  function renderTree(map, openapi, mountEl) {
    const esc = S.escapeHtml;
    const byHost = new Map();
    for (const e of map.endpoints) {
      if (!byHost.has(e.host)) byHost.set(e.host, []);
      byHost.get(e.host).push(e);
    }

    const hostsHtml = [...byHost.entries()].map(([host, eps]) => {
      const epsHtml = eps.map((e) => {
        const stHtml = Object.entries(e.statuses)
          .map(([st, n]) => `<span class="crt-st crt-st-${String(st)[0] || "x"}xx">${esc(st)}·${esc(n)}</span>`)
          .join("");
        const cts = e.contentTypes.length ? `<span class="crt-ct">${esc(e.contentTypes.join(", "))}</span>` : "";
        return `
          <details class="crt-ep">
            <summary>
              <span class="crt-method crt-m-${esc(e.method.toLowerCase())}">${esc(e.method)}</span>
              <span class="crt-path">${esc(e.path)}</span>
              <span class="crt-count">${esc(e.count)}×</span>
              <span class="crt-ms">p95 ${S.formatMs(e.p95Ms)}</span>
              ${stHtml}
            </summary>
            <div class="crt-ep-body">
              <div class="crt-row"><b>avg</b> ${S.formatMs(e.avgMs)} · <b>p50</b> ${S.formatMs(e.p50Ms)} · <b>p95</b> ${S.formatMs(e.p95Ms)} ${cts}</div>
              ${e.sampleReqBody ? `<div class="crt-row"><b>req.body</b><pre>${esc(e.sampleReqBody)}</pre></div>` : ""}
              ${e.sampleResBody ? `<div class="crt-row"><b>res.body (${esc(e.sampleStatus)})</b><pre>${esc(e.sampleResBody)}</pre></div>` : ""}
            </div>
          </details>`;
      }).join("");
      return `
        <details class="crt-host" open>
          <summary><span class="crt-host-name">${esc(host)}</span><span class="crt-host-count">${esc(eps.length)} endpoint(s)</span></summary>
          <div class="crt-host-body">${epsHtml}</div>
        </details>`;
    }).join("");

    mountEl.innerHTML = `
      <style>
        .crt-wrap{display:flex;flex-direction:column;gap:12px;color:#e6e6ea;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace}
        .crt-toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
        .crt-toolbar .crt-stat{padding:4px 8px;background:rgba(191,0,255,.08);border:1px solid rgba(191,0,255,.25);border-radius:6px;color:#e6e6ea}
        .crt-btn{padding:6px 12px;background:#bf00ff;color:#0a0a0c;border:none;border-radius:6px;font-weight:700;cursor:pointer}
        .crt-btn:hover{filter:brightness(1.1)}
        .crt-host{background:rgba(18,18,20,.55);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:6px 10px}
        .crt-host > summary{cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:8px;padding:4px 0}
        .crt-host-name{font-weight:700;color:#bf00ff}
        .crt-host-count{color:rgba(255,255,255,.55);font-size:11px}
        .crt-host-body{display:flex;flex-direction:column;gap:4px;padding:6px 0 2px}
        .crt-ep{padding:4px 6px;border-radius:6px;background:rgba(255,255,255,.02)}
        .crt-ep > summary{cursor:pointer;display:flex;gap:8px;align-items:center;flex-wrap:wrap;list-style:none}
        .crt-ep > summary::-webkit-details-marker{display:none}
        .crt-method{font-weight:800;font-size:10px;padding:2px 6px;border-radius:4px;letter-spacing:.5px}
        .crt-m-get{background:#0d4f3c;color:#5cffb1}
        .crt-m-post{background:#0d3e6e;color:#7dbdff}
        .crt-m-put,.crt-m-patch{background:#6e4a0d;color:#ffce7d}
        .crt-m-delete{background:#6e0d1f;color:#ff7d8d}
        .crt-path{color:#e6e6ea;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .crt-count{color:rgba(255,255,255,.7);font-size:11px}
        .crt-ms{color:rgba(255,255,255,.5);font-size:11px}
        .crt-st{font-size:10px;padding:1px 5px;border-radius:3px;background:rgba(255,255,255,.06)}
        .crt-st-2xx{color:#5cffb1}.crt-st-3xx{color:#7dbdff}.crt-st-4xx{color:#ffce7d}.crt-st-5xx{color:#ff7d8d}
        .crt-ct{color:rgba(255,255,255,.45);font-size:10px;margin-left:6px}
        .crt-ep-body{padding:6px 4px 2px;display:flex;flex-direction:column;gap:6px}
        .crt-row{font-size:11px;color:rgba(255,255,255,.75)}
        .crt-row b{color:#bf00ff;margin-right:6px}
        .crt-row pre{margin:4px 0 0;padding:6px 8px;background:rgba(0,0,0,.35);border-radius:4px;max-height:240px;overflow:auto;white-space:pre-wrap;word-break:break-word;color:#d6d6da}
        .crt-empty{padding:24px;text-align:center;color:rgba(255,255,255,.5)}
      </style>
      <div class="crt-wrap">
        <div class="crt-toolbar">
          <span class="crt-stat">${esc(map.endpoints.length)} endpoints</span>
          <span class="crt-stat">${esc(map.hosts.length)} hosts</span>
          <span class="crt-stat">${esc(map.endpoints.reduce((a,e)=>a+e.count,0))} requests</span>
          <span style="flex:1"></span>
          <button class="crt-btn" data-action="dl-openapi">Baixar openapi.json</button>
          <button class="crt-btn" data-action="dl-map" style="background:#3a3a40;color:#e6e6ea">Baixar mapa.json</button>
        </div>
        ${hostsHtml || `<div class="crt-empty">Nenhum endpoint mapeável.</div>`}
      </div>`;

    mountEl.querySelector('[data-action="dl-openapi"]')?.addEventListener("click", () => {
      S.downloadBlob("hyper-rb-openapi.json", "application/json", JSON.stringify(openapi, null, 2));
    });
    mountEl.querySelector('[data-action="dl-map"]')?.addEventListener("click", () => {
      S.downloadBlob("hyper-rb-mapa.json", "application/json", JSON.stringify(map, null, 2));
    });
  }

  // ---------- SCRIPT ----------
  const SCRIPT = {
    id: 1,
    slug: "cartographer",
    name: "Mapa de Endpoints",
    description: "Agrupa por host+path+method, normaliza IDs e infere um OpenAPI 3.1 navegável.",
    icon: "🗺️",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes de executar." };
      }
      const map = buildMap(ctx.requests);
      if (!map.endpoints.length) {
        return { ok: false, error: "Nenhum endpoint identificável (faltam host/method nas requests)." };
      }
      const openapi = toOpenApi(map);
      const total = map.endpoints.reduce((a, e) => a + e.count, 0);
      ctx.log("info", `cartographer: ${map.endpoints.length} endpoints, ${map.hosts.length} hosts, ${total} reqs`);

      return {
        ok: true,
        summary: `${map.endpoints.length} endpoints em ${map.hosts.length} host(s) · ${total} requests`,
        render(mountEl) {
          try {
            renderTree(map, openapi, mountEl);
          } catch (e) {
            mountEl.innerHTML = `<pre style="color:#ff7d8d;padding:12px">Falha no render: ${S.escapeHtml(e.message || String(e))}</pre>`;
          }
        },
        // Sem `artifact` — o download é manual via botões do drawer
        // (evita baixar automaticamente a cada execução).
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();
