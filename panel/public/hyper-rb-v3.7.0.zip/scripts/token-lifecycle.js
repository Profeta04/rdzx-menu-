// ============================================================
// Hyper RB · Scripts · #15 token-lifecycle
// Detecta tokens (JWT, Bearer, cookies de sessão) nas requests,
// decodifica `exp` de JWT, monta timeline de aparição/rotação/reuso.
// Sem IA, sem rede.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  // JWT real (não os <jwt> mascarados pelo _shared). Captura na fonte só funciona
  // se algum header não foi redacted — usamos os mascarados para CONTAR ocorrências
  // e os crus quando disponíveis em reqBody/resBody/url.
  const JWT_RE = /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}/g;
  const MASKED_TOKENS = new Set(["<jwt>", "<lovable-token>", "<redacted>"]);

  function b64urlDecode(s) {
    try {
      const pad = "=".repeat((4 - (s.length % 4)) % 4);
      const b64 = (s + pad).replace(/-/g, "+").replace(/_/g, "/");
      return atob(b64);
    } catch { return null; }
  }

  function decodeJwt(tok) {
    const parts = tok.split(".");
    if (parts.length !== 3) return null;
    const payload = b64urlDecode(parts[1]);
    if (!payload) return null;
    try { return JSON.parse(payload); } catch { return null; }
  }

  function fingerprint(tok) {
    // hash leve para identificar token sem persistir o valor inteiro
    return tok.slice(0, 6) + "…" + tok.slice(-6) + ":" + tok.length;
  }

  function* iterTokens(req) {
    const h = req.reqHeaders || {};
    const auth = h["authorization"] || h["Authorization"];
    if (auth && typeof auth === "string") {
      const m = auth.match(/^Bearer\s+(\S+)/i);
      if (m && !MASKED_TOKENS.has(m[1])) yield { source: "header:authorization", token: m[1] };
    }
    // varre URL + body cru por JWTs visíveis
    const blobs = [req.url, req.reqBody, req.resBody].filter((x) => typeof x === "string");
    for (const blob of blobs) {
      let m;
      JWT_RE.lastIndex = 0;
      while ((m = JWT_RE.exec(blob)) !== null) {
        yield { source: blob === req.url ? "url" : "body", token: m[0] };
      }
    }
    // cookie sessão (mascarado vira <redacted>; só aparece se NÃO estiver na blocklist)
    const cookie = h["cookie"] || h["Cookie"];
    if (cookie && typeof cookie === "string" && cookie !== "<redacted>") {
      const parts = cookie.split(/;\s*/);
      for (const p of parts) {
        const eq = p.indexOf("=");
        if (eq < 0) continue;
        const name = p.slice(0, eq).trim();
        const value = p.slice(eq + 1);
        if (/sess|sid|auth|token/i.test(name) && value && value.length >= 16) {
          yield { source: `cookie:${name}`, token: value };
        }
      }
    }
  }

  function analyze(requests) {
    const tokens = new Map(); // fp -> { fp, kind, exp?, iat?, sub?, iss?, first, last, count, sources:Set, endpoints:Set }
    const sorted = [...requests].sort((a, b) => (a.ts || 0) - (b.ts || 0));

    for (const r of sorted) {
      for (const { source, token } of iterTokens(r)) {
        const fp = fingerprint(token);
        const jwt = decodeJwt(token);
        let t = tokens.get(fp);
        if (!t) {
          t = {
            fp,
            kind: jwt ? "jwt" : (source.startsWith("cookie") ? "cookie" : "opaque"),
            exp: jwt?.exp, iat: jwt?.iat, sub: jwt?.sub, iss: jwt?.iss,
            first: r.ts, last: r.ts, count: 0,
            sources: new Set(), endpoints: new Set(),
          };
          tokens.set(fp, t);
        }
        t.count++;
        t.last = r.ts;
        t.sources.add(source);
        t.endpoints.add(`${r.method} ${r.host}${r.pathname}`);
      }
    }

    const now = Math.floor(Date.now() / 1000);
    const list = [...tokens.values()].map((t) => ({
      ...t,
      sources: [...t.sources],
      endpoints: [...t.endpoints],
      expired: typeof t.exp === "number" ? t.exp < now : null,
      expiresInSec: typeof t.exp === "number" ? t.exp - now : null,
    }));

    // ordenar: expirados primeiro, depois mais reusados
    list.sort((a, b) => {
      if (a.expired && !b.expired) return -1;
      if (!a.expired && b.expired) return 1;
      return b.count - a.count;
    });
    return list;
  }

  function fmtExp(t) {
    if (t.exp == null) return "—";
    const d = new Date(t.exp * 1000);
    const rel = t.expiresInSec;
    const tag = t.expired ? "expirado" : (rel < 300 ? "expira <5min" : `em ${Math.round(rel / 60)}min`);
    return `${d.toISOString().slice(11, 19)} (${tag})`;
  }

  const SCRIPT = {
    id: 15,
    slug: "token-lifecycle",
    name: "Token Lifecycle",
    description: "Detecta JWT/Bearer/cookies de sessão, decodifica exp, mostra reuso e rotação.",
    icon: "🔑",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      const tokens = analyze(ctx.requests);
      if (!tokens.length) {
        return { ok: false, error: "Nenhum token detectado nas requests capturadas (headers sensíveis podem ter sido sanitizados)." };
      }

      const expired = tokens.filter((t) => t.expired).length;

      return {
        ok: true,
        summary: `${tokens.length} token(s) · ${expired} expirado(s)`,
        render(mountEl) {
          const rows = tokens.map((t) => `
            <tr class="${t.expired ? "row-danger" : ""}">
              <td><code>${S.escapeHtml(t.fp)}</code></td>
              <td>${S.escapeHtml(t.kind)}</td>
              <td>${S.escapeHtml(t.sub || "—")}</td>
              <td>${S.escapeHtml(fmtExp(t))}</td>
              <td style="text-align:right">${t.count}</td>
              <td style="text-align:right">${t.endpoints.length}</td>
              <td>${S.escapeHtml(t.sources.join(", "))}</td>
            </tr>
          `).join("");

          mountEl.innerHTML = `
            <div class="hyper-rb-section">
              <div class="hyper-rb-section-head">
                <div>
                  <div class="hyper-rb-section-title">Token Lifecycle</div>
                  <div class="hyper-rb-section-sub">
                    ${S.escapeHtml(tokens.length)} token(s) detectado(s) · ${S.escapeHtml(expired)} expirado(s).
                    Fingerprint = prefixo + sufixo + tamanho (valor completo nunca é exibido).
                  </div>
                </div>
              </div>
              <table class="hyper-rb-table">
                <thead><tr>
                  <th>Fingerprint</th><th>Tipo</th><th>sub</th><th>exp</th>
                  <th style="text-align:right">Reusos</th><th style="text-align:right">Endpoints</th><th>Fontes</th>
                </tr></thead>
                <tbody>${rows}</tbody>
              </table>
            </div>
          `;
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();