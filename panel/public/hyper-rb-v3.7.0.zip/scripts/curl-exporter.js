// ============================================================
// Hyper RB · Scripts · #13 curl-exporter
// Exporta requests sanitizadas como comandos `curl` (bash).
// Sem IA, sem rede. Headers sanitizados, body via --data-raw.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  const BINARY_CT = /(image\/|audio\/|video\/|application\/(octet-stream|pdf|zip|x-protobuf|wasm))/i;

  function isBinaryContentType(headers) {
    if (!headers) return false;
    const ct = headers["content-type"] || headers["Content-Type"] || "";
    return BINARY_CT.test(String(ct));
  }

  // bash single-quote escape: ' -> '\''
  function shq(v) {
    return "'" + String(v ?? "").replace(/'/g, "'\\''") + "'";
  }

  function toCurl(req) {
    if (!req || !req.url) return null;
    const lines = [];
    const method = String(req.method || "GET").toUpperCase();
    lines.push(`curl -X ${method} ${shq(req.url)}`);

    const h = req.reqHeaders || {};
    for (const [k, v] of Object.entries(h)) {
      if (v == null) continue;
      lines.push(`  -H ${shq(`${k}: ${v}`)}`);
    }

    if (req.reqBody != null && req.reqBody !== "" && method !== "GET" && method !== "HEAD") {
      if (isBinaryContentType(h)) {
        lines.push(`  # body binário omitido`);
      } else {
        lines.push(`  --data-raw ${shq(req.reqBody)}`);
      }
    }

    return lines.join(" \\\n");
  }

  function buildScript(requests) {
    const ts = new Date().toISOString();
    const blocks = [];
    let ok = 0;
    for (const r of requests) {
      const c = toCurl(r);
      if (!c) continue;
      blocks.push(`# ${r.method} ${r.host || ""}${r.pathname || ""}\n${c}`);
      ok++;
    }
    const header = `#!/usr/bin/env bash\n# Hyper RB · curl-exporter\n# Generated: ${ts}\n# Total: ${ok} request(s)\n# Headers/bodies sanitizados (JWT/tokens redacted).\nset -euo pipefail\n\n`;
    return { script: header + blocks.join("\n\n") + "\n", count: ok };
  }

  const SCRIPT = {
    id: 13,
    slug: "curl-exporter",
    name: "cURL Exporter",
    description: "Exporta requests capturadas como comandos curl (.sh) sanitizados.",
    icon: "🌀",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes." };
      }

      const { script, count } = buildScript(ctx.requests);
      const filename = `hyper-rb-curl-${Date.now()}.sh`;

      return {
        ok: true,
        summary: `${count} comando(s) curl gerado(s)`,
        artifact: { filename, mime: "text/x-shellscript", content: script },
        render(mountEl) {
          const preview = script.length > 4000 ? script.slice(0, 4000) + "\n…(truncado)" : script;

          mountEl.innerHTML = `
            <div class="hyper-rb-section">
              <div class="hyper-rb-section-head">
                <div>
                  <div class="hyper-rb-section-title">cURL Exporter</div>
                  <div class="hyper-rb-section-sub">
                    ${S.escapeHtml(count)} request(s) convertida(s) em curl.
                    Headers sensíveis redacted. Bodies binários omitidos.
                  </div>
                </div>
                <div style="display:flex;gap:8px">
                  <button class="hyper-rb-btn copy-curl">📋 Copiar</button>
                  <button class="hyper-rb-btn hyper-rb-btn-primary dl-curl">⬇ Baixar .sh</button>
                </div>
              </div>
              <pre class="hyper-rb-pre" style="max-height:480px;overflow:auto"><code>${S.escapeHtml(preview)}</code></pre>
            </div>
          `;

          mountEl.querySelector(".dl-curl")?.addEventListener("click", () => {
            S.downloadBlob(filename, "text/x-shellscript", script);
          });
          mountEl.querySelector(".copy-curl")?.addEventListener("click", async () => {
            try {
              await navigator.clipboard.writeText(script);
              const btn = mountEl.querySelector(".copy-curl");
              if (btn) { const t = btn.textContent; btn.textContent = "✓ Copiado"; setTimeout(() => { btn.textContent = t; }, 1500); }
            } catch (e) {
              console.error("[Hyper RB · curl-exporter] clipboard falhou:", e);
            }
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();