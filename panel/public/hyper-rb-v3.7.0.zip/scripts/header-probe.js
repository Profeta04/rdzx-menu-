(function registerHeaderProbe() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · header-probe] HYPER_RB_SHARED ausente");
    return;
  }

  const MAX_VARIANTS = 6;
  const SLEEP_MS = 150;
  const BLOCKED_HEADERS = new Set(["authorization", "cookie", "set-cookie", "proxy-authorization"]);
  const BODY_HASH_PREVIEW_SIZE = 512;

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function cloneHeaders(headers) {
    const next = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (BLOCKED_HEADERS.has(String(key).toLowerCase())) continue;
      next[key] = value;
    }
    return next;
  }

  function simpleHash(text) {
    const input = String(text || "").slice(0, BODY_HASH_PREVIEW_SIZE);
    let hash = 2166136261;
    for (let i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function normalizeVariantHeaders(baseHeaders, patch) {
    const headers = cloneHeaders(baseHeaders);
    for (const [key, value] of Object.entries(patch || {})) {
      if (BLOCKED_HEADERS.has(String(key).toLowerCase())) continue;
      if (value == null || value === "") delete headers[key];
      else headers[key] = value;
    }
    return headers;
  }

  function getVariants(baseHeaders) {
    const base = cloneHeaders(baseHeaders);
    return [
      { label: "Chrome UA", headers: normalizeVariantHeaders(base, { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36" }) },
      { label: "Safari UA", headers: normalizeVariantHeaders(base, { "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15" }) },
      { label: "Firefox UA", headers: normalizeVariantHeaders(base, { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0" }) },
      { label: "Sem User-Agent", headers: normalizeVariantHeaders(base, { "User-Agent": null }) },
      { label: "Sem Referer", headers: normalizeVariantHeaders(base, { Referer: null }) },
      { label: "X-Real-IP", headers: normalizeVariantHeaders(base, { "X-Real-IP": "203.0.113.42", "X-Forwarded-For": null }) },
    ].slice(0, MAX_VARIANTS);
  }

  function safeBody(body) {
    if (typeof body === "string") return body;
    if (body == null) return "";
    try {
      return JSON.stringify(body);
    } catch {
      return String(body);
    }
  }

  function buildRequestOptions(request, headers) {
    return {
      method: String(request.method || "GET").toUpperCase(),
      headers,
      body: safeBody(request.reqBody || "") || null,
    };
  }

  async function runProbe(ctx, request) {
    const variants = getVariants(request.reqHeaders || {});
    const baseHash = simpleHash(request.resBody || "");
    const results = [];

    for (let i = 0; i < variants.length; i++) {
      const variant = variants[i];
      const replay = await ctx.proxyFetch(request.url, buildRequestOptions(request, variant.headers));
      const bodyHash = simpleHash(replay.body || "");
      results.push({
        label: variant.label,
        status: Number(replay.status || 0),
        durationMs: Number(replay.durationMs || 0),
        bodyHash,
        hashChanged: bodyHash !== baseHash,
        ok: Boolean(replay.ok),
        error: replay.error || "",
      });
      if (i < variants.length - 1) await sleep(SLEEP_MS);
    }

    return { variants, results, baseHash };
  }

  function buildRequestOptionsList(requests) {
    return requests
      .filter((request) => request && request.url)
      .slice(0, 50)
      .map((request, index) => ({
        id: request.id,
        label: `${index + 1}. ${request.method} ${request.host}${request.pathname || "/"}`,
        request,
      }));
  }

  const SCRIPT = {
    id: 9,
    slug: "header-probe",
    name: "Sonda de Headers",
    description: "Reexecuta uma request com variações canônicas de headers e mostra impacto em status, latência e hash da resposta.",
    icon: "🧪",
    needsAI: false,
    needsNetwork: true,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes de executar." };
      }

      const requestOptions = buildRequestOptionsList(ctx.requests);
      if (!requestOptions.length) {
        return { ok: false, error: "Nenhuma request válida foi encontrada para a sonda." };
      }

      return {
        ok: true,
        summary: `${requestOptions.length} request(s) disponíveis · ${MAX_VARIANTS} variantes por execução`,
        render(mountEl) {
          mountEl.innerHTML = `
            <style>
              .hp-wrap{display:flex;flex-direction:column;gap:12px;padding:12px;color:#ececf1;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace}
              .hp-panel{background:rgba(18,18,20,.7);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:12px}
              .hp-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.hp-row select{min-width:280px;max-width:100%;padding:8px 10px;border-radius:6px;background:rgba(255,255,255,.04);color:#ececf1;border:1px solid rgba(255,255,255,.08)}
              .hp-btn{padding:8px 12px;border:none;border-radius:6px;background:#bf00ff;color:#0a0a0c;font-weight:900;cursor:pointer}
              .hp-btn[disabled]{opacity:.6;cursor:wait}
              .hp-hint{color:rgba(255,255,255,.55)}
              .hp-table-wrap{overflow:auto}.hp-table{width:100%;border-collapse:collapse}.hp-table th,.hp-table td{padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;font-size:11px}
              .hp-table th{font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,.52)}
              .hp-ok{color:#7ce6b5}.hp-warn{color:#ffd27f}.hp-err{color:#ff9aac}.hp-hash-changed{font-weight:900}
              .hp-empty{padding:18px;color:rgba(255,255,255,.45)}
              .hp-base{color:rgba(255,255,255,.55);font-size:11px}
            </style>
            <div class="hp-wrap">
              <div class="hp-panel">
                <div class="hp-row">
                  <select data-role="request-select">${requestOptions.map((option, index) => `<option value="${S.escapeHtml(index)}">${S.escapeHtml(option.label)}</option>`).join("")}</select>
                  <button class="hp-btn" data-action="run">Executar</button>
                  <span class="hp-hint">6 variantes sequenciais · 150ms entre replays · Authorization bloqueado no client</span>
                </div>
              </div>
              <div class="hp-panel">
                <div class="hp-base" data-role="meta">Selecione uma request e execute a sonda.</div>
                <div class="hp-table-wrap" data-role="results"><div class="hp-empty">Nenhuma execução ainda.</div></div>
              </div>
            </div>`;

          const select = mountEl.querySelector('[data-role="request-select"]');
          const runButton = mountEl.querySelector('[data-action="run"]');
          const meta = mountEl.querySelector('[data-role="meta"]');
          const resultsRegion = mountEl.querySelector('[data-role="results"]');

          runButton?.addEventListener("click", async () => {
            const selected = requestOptions[Number(select?.value || 0)];
            if (!selected) return;
            runButton.disabled = true;
            meta.textContent = `Executando sonda para ${selected.request.method} ${selected.request.host}${selected.request.pathname || "/"}…`;
            resultsRegion.innerHTML = `<div class="hyper-rb-loading">Executando variantes de header…</div>`;
            try {
              const probe = await runProbe(ctx, selected.request);
              meta.textContent = `Base hash ${probe.baseHash} · ${selected.request.method} ${selected.request.host}${selected.request.pathname || "/"}`;
              resultsRegion.innerHTML = `
                <table class="hp-table">
                  <thead>
                    <tr>
                      <th>Variante</th>
                      <th>Status</th>
                      <th>Latência</th>
                      <th>Hash</th>
                      <th>Delta</th>
                      <th>Obs.</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${probe.results.map((result) => `
                      <tr>
                        <td>${S.escapeHtml(result.label)}</td>
                        <td class="${result.status >= 400 || !result.ok ? "hp-err" : "hp-ok"}">${S.escapeHtml(result.status || "—")}</td>
                        <td>${S.escapeHtml(S.formatMs(result.durationMs))}</td>
                        <td class="${result.hashChanged ? "hp-hash-changed hp-warn" : ""}">${S.escapeHtml(result.bodyHash)}</td>
                        <td class="${result.hashChanged ? "hp-warn" : "hp-ok"}">${result.hashChanged ? "mudou" : "igual"}</td>
                        <td>${S.escapeHtml(result.error || (result.hashChanged ? "Resposta diferente" : "Sem alteração perceptível"))}</td>
                      </tr>`).join("")}
                  </tbody>
                </table>`;
            } catch (error) {
              meta.textContent = `Falha ao executar a sonda.`;
              resultsRegion.innerHTML = `<div class="hyper-rb-error">${S.escapeHtml(error && error.message ? error.message : String(error))}</div>`;
            } finally {
              runButton.disabled = false;
            }
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();