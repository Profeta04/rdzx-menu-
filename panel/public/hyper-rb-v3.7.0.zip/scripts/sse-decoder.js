// ============================================================
// Hyper RB · Scripts · #7 sse-decoder
// Parser SSE (text/event-stream) + timeline + export NDJSON.
// ============================================================
(function registerScript() {
  "use strict";
  const S = window.HYPER_RB_SHARED;

  const LOVABLE_TYPE_RE = /(tool_call|message_delta|done|error|message_start|message_stop|content_block_(start|delta|stop))/i;

  function isSseRequest(r) {
    if (!r) return false;
    if (r.isSSE) return true;
    const ct = (r.resHeaders && (r.resHeaders["content-type"] || r.resHeaders["Content-Type"])) || "";
    return String(ct).toLowerCase().includes("text/event-stream");
  }

  /**
   * Parse SSE body per spec: blocks separated by \n\n.
   * Each block: lines `field: value`. Multi `data:` lines are concat with \n.
   * Returns array of { id?, event?, retry?, data, type, raw }.
   */
  function parseSse(body) {
    if (!body || typeof body !== "string") return [];
    const normalized = body.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const blocks = normalized.split(/\n\n+/);
    const events = [];
    for (const block of blocks) {
      const trimmed = block.trim();
      if (!trimmed) continue;
      const ev = { id: undefined, event: undefined, retry: undefined, data: "" };
      const dataLines = [];
      for (const line of trimmed.split("\n")) {
        if (!line || line.startsWith(":")) continue; // comment
        const idx = line.indexOf(":");
        const field = idx === -1 ? line : line.slice(0, idx);
        let value = idx === -1 ? "" : line.slice(idx + 1);
        if (value.startsWith(" ")) value = value.slice(1);
        switch (field) {
          case "id": ev.id = value; break;
          case "event": ev.event = value; break;
          case "retry": ev.retry = Number(value) || undefined; break;
          case "data": dataLines.push(value); break;
          default: break;
        }
      }
      ev.data = dataLines.join("\n");

      // tipo inferido: event explícito > heurística por conteúdo
      let type = ev.event || "message";
      if (!ev.event) {
        const m = ev.data.match(LOVABLE_TYPE_RE);
        if (m) type = m[1].toLowerCase();
        else if (/^\s*\[DONE\]\s*$/i.test(ev.data)) type = "done";
      }
      ev.type = type;

      // tenta parsear JSON do data
      let parsed = null;
      const dataTrim = ev.data.trim();
      if (dataTrim && (dataTrim.startsWith("{") || dataTrim.startsWith("["))) {
        try { parsed = JSON.parse(dataTrim); } catch { parsed = null; }
      }
      ev.parsed = parsed;
      ev.raw = block;
      events.push(ev);
    }
    return events;
  }

  function summarizeTypes(events) {
    const counts = {};
    for (const e of events) counts[e.type] = (counts[e.type] || 0) + 1;
    return counts;
  }

  function buildNdjson(streams) {
    const lines = [];
    for (const s of streams) {
      for (const e of s.events) {
        lines.push(JSON.stringify({
          reqId: s.reqId,
          host: s.host,
          path: s.path,
          id: e.id,
          event: e.event,
          type: e.type,
          retry: e.retry,
          data: e.parsed ?? e.data,
        }));
      }
    }
    return lines.join("\n");
  }

  const SCRIPT = {
    id: 7,
    slug: "sse-decoder",
    name: "Decodificador SSE",
    description: "Parseia streams text/event-stream e mostra timeline de eventos (tool_call, delta, done).",
    icon: "📡",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      const sseReqs = ctx.requests.filter(isSseRequest);
      if (!sseReqs.length) {
        return { ok: false, error: "Nenhuma request SSE (text/event-stream) capturada." };
      }

      const streams = [];
      let totalEvents = 0;
      const globalCounts = {};

      for (const r of sseReqs) {
        const events = parseSse(r.resBody || "");
        const counts = summarizeTypes(events);
        for (const [k, v] of Object.entries(counts)) globalCounts[k] = (globalCounts[k] || 0) + v;
        totalEvents += events.length;
        streams.push({
          reqId: r.id,
          host: r.host,
          path: r.pathname,
          method: r.method,
          ts: r.ts,
          events,
          counts,
        });
      }

      const ndjson = buildNdjson(streams);
      const filename = `hyper-rb-sse-${Date.now()}.ndjson`;

      return {
        ok: true,
        summary: `${streams.length} stream(s) · ${totalEvents} evento(s)`,
        artifact: { filename, mime: "application/x-ndjson", content: ndjson },
        render(mountEl) {
          mountEl.innerHTML = `<div class="hyper-rb-loading">Renderizando timeline…</div>`;

          const allTypes = Object.keys(globalCounts).sort();
          const typeChips = allTypes.map((t) =>
            `<button class="hyper-rb-chip" data-type="${S.escapeHtml(t)}" aria-pressed="true">
              ${S.escapeHtml(t)} · ${S.escapeHtml(globalCounts[t])}
            </button>`
          ).join("");

          const streamSelector = streams.map((s, i) =>
            `<option value="${i}">${S.escapeHtml(s.method)} ${S.escapeHtml(s.host)}${S.escapeHtml(s.path)} (${s.events.length} ev)</option>`
          ).join("");

          mountEl.innerHTML = `
            <div class="hyper-rb-section">
              <div class="hyper-rb-section-head">
                <div>
                  <div class="hyper-rb-section-title">SSE Timeline</div>
                  <div class="hyper-rb-section-sub">
                    ${S.escapeHtml(streams.length)} stream(s) · ${S.escapeHtml(totalEvents)} evento(s).
                  </div>
                </div>
                <button class="hyper-rb-btn hyper-rb-btn-primary dl-ndjson">⬇ Baixar .ndjson</button>
              </div>

              <div class="hyper-rb-toolbar">
                <label>Stream:&nbsp;
                  <select class="hyper-rb-select stream-sel">${streamSelector}</select>
                </label>
              </div>

              <div class="hyper-rb-toolbar type-filters">${typeChips || "<span>Sem eventos</span>"}</div>

              <ol class="hyper-rb-timeline" data-region="timeline"></ol>
            </div>
          `;

          const timeline = mountEl.querySelector('[data-region="timeline"]');
          const sel = mountEl.querySelector(".stream-sel");
          const activeTypes = new Set(allTypes);

          function renderTimeline() {
            const idx = Number(sel.value) || 0;
            const stream = streams[idx];
            if (!stream) { timeline.innerHTML = ""; return; }
            const items = stream.events
              .filter((e) => activeTypes.has(e.type))
              .map((e, i) => {
                const preview = e.parsed
                  ? JSON.stringify(e.parsed, null, 2)
                  : (e.data || "");
                const previewSafe = S.escapeHtml(
                  preview.length > 800 ? preview.slice(0, 800) + "…" : preview
                );
                return `
                  <li class="hyper-rb-timeline-item" data-type="${S.escapeHtml(e.type)}">
                    <div class="hyper-rb-timeline-marker"></div>
                    <div class="hyper-rb-timeline-body">
                      <div class="hyper-rb-timeline-head">
                        <span class="hyper-rb-badge">${S.escapeHtml(e.type)}</span>
                        ${e.id ? `<span class="hyper-rb-mono">id=${S.escapeHtml(e.id)}</span>` : ""}
                        <span class="hyper-rb-mono">#${S.escapeHtml(i + 1)}</span>
                      </div>
                      <details>
                        <summary>ver payload (${S.escapeHtml(preview.length)} chars)</summary>
                        <pre class="hyper-rb-pre">${previewSafe}</pre>
                      </details>
                    </div>
                  </li>
                `;
              }).join("");
            timeline.innerHTML = items || `<li class="hyper-rb-empty">Nenhum evento corresponde aos filtros.</li>`;
          }

          sel.addEventListener("change", renderTimeline);

          mountEl.querySelectorAll(".type-filters .hyper-rb-chip").forEach((chip) => {
            chip.addEventListener("click", () => {
              const t = chip.getAttribute("data-type");
              if (activeTypes.has(t)) { activeTypes.delete(t); chip.setAttribute("aria-pressed", "false"); }
              else { activeTypes.add(t); chip.setAttribute("aria-pressed", "true"); }
              renderTimeline();
            });
          });

          mountEl.querySelector(".dl-ndjson")?.addEventListener("click", () => {
            S.downloadBlob(filename, "application/x-ndjson", ndjson);
          });

          renderTimeline();
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();