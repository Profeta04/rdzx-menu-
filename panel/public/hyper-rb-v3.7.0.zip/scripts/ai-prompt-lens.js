// ============================================================
// Hyper RB · Script #17 · ai-prompt-lens
// Filtra requests para endpoints de chat/IA (Lovable, Supabase AI),
// extrai prompts/mensagens dos bodies, estima tokens e oferece
// análise agregada via IA (analyze_network_traffic).
// IIFE puro · render(mountEl) · sanitização via HYPER_RB_SHARED.
// ============================================================
(function registerAiPromptLens() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · ai-prompt-lens] HYPER_RB_SHARED ausente");
    return;
  }

  // Heurística: endpoints que parecem chat/IA
  const AI_PATH_RE = /(chat|completions?|messages?|generate|prompt|ai|llm|composer)/i;
  const AI_HOST_RE = /(lovable\.dev|supabase\.co|openai|anthropic|groq|gemini|googleapis)/i;

  function isAiRequest(r) {
    const host = r.host || "";
    const path = r.pathname || "";
    if (!host && !path) return false;
    return AI_HOST_RE.test(host) && AI_PATH_RE.test(path);
  }

  // Extrai prompt/mensagem do body JSON
  function extractPrompt(body) {
    if (!body) return "";
    let obj = body;
    if (typeof body === "string") {
      try { obj = JSON.parse(body); } catch { return body.slice(0, 500); }
    }
    if (!obj || typeof obj !== "object") return "";
    // Campos comuns
    const keys = ["mensagem", "message", "prompt", "input", "query", "text", "content"];
    for (const k of keys) {
      if (typeof obj[k] === "string" && obj[k].trim()) return obj[k];
    }
    // OpenAI-style messages[]
    if (Array.isArray(obj.messages)) {
      return obj.messages
        .map((m) => (typeof m === "string" ? m : m?.content || ""))
        .filter(Boolean)
        .join("\n");
    }
    if (Array.isArray(obj.contents)) {
      return obj.contents
        .map((c) => c?.parts?.map?.((p) => p?.text).join(" ") || "")
        .filter(Boolean)
        .join("\n");
    }
    return "";
  }

  // ~4 chars por token (heurística OpenAI/Anthropic)
  function estimateTokens(text) {
    if (!text) return 0;
    return Math.ceil(text.length / 4);
  }

  function truncate(s, n) {
    if (!s) return "";
    return s.length > n ? s.slice(0, n) + "…" : s;
  }

  function extractResponseSnippet(r) {
    const body = r.resBody || "";
    if (!body) return "";
    if (typeof body === "string") return truncate(body, 200);
    try { return truncate(JSON.stringify(body), 200); } catch { return ""; }
  }

  function callWithTimeout(promise, ms) {
    return Promise.race([
      promise,
      new Promise((resolve) => setTimeout(() => resolve({ ok: false, error: "timeout" }), ms)),
    ]);
  }

  const SCRIPT = {
    id: 17,
    slug: "ai-prompt-lens",
    name: "AI Prompt Lens",
    description: "Filtra requests de IA, extrai prompts, estima tokens e sugere otimizações via IA.",
    icon: "🔍",
    needsAI: true,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      const aiReqs = (ctx.requests || []).filter(isAiRequest);
      if (!aiReqs.length) {
        return {
          ok: true,
          summary: "Nenhuma request de IA detectada.",
          render(mountEl) {
            mountEl.innerHTML = `<div class="hyper-rb-empty" style="color:rgba(255,255,255,.5);font-style:italic;padding:12px;">Nenhuma request para endpoints de chat/IA foi capturada.</div>`;
          },
        };
      }

      const rows = aiReqs.map((r) => {
        const prompt = extractPrompt(r.reqBody);
        const tokens = estimateTokens(prompt);
        return {
          id: r.id,
          when: r.startedAt || 0,
          endpoint: `${r.method} ${r.host}${r.pathname}`,
          prompt,
          tokens,
          status: r.status || 0,
          response: extractResponseSnippet(r),
        };
      }).sort((a, b) => b.tokens - a.tokens);

      const totalTokens = rows.reduce((s, r) => s + r.tokens, 0);

      return {
        ok: true,
        summary: `${rows.length} requests de IA · ~${totalTokens} tokens estimados`,
        render(mountEl) {
          mountEl.innerHTML = `
            <div class="hyper-rb-apl">
              <div class="apl-summary">
                <strong>${rows.length}</strong> requests de IA ·
                <strong>~${totalTokens.toLocaleString()}</strong> tokens estimados
                <button class="apl-analyze" type="button">Analisar com IA</button>
              </div>
              <div class="apl-ai-out"></div>
              <table class="apl-table">
                <thead>
                  <tr><th>Endpoint</th><th>Prompt</th><th>Tokens</th><th>Status</th><th>Resposta</th></tr>
                </thead>
                <tbody>
                  ${rows.map((r) => `
                    <tr>
                      <td><code>${S.escapeHtml(truncate(r.endpoint, 60))}</code></td>
                      <td class="apl-prompt">${S.escapeHtml(truncate(r.prompt, 180))}</td>
                      <td class="apl-num">${r.tokens}</td>
                      <td class="apl-num">${S.escapeHtml(String(r.status))}</td>
                      <td class="apl-resp">${S.escapeHtml(r.response)}</td>
                    </tr>
                  `).join("")}
                </tbody>
              </table>
            </div>
            <style>
              .hyper-rb-apl { display:flex; flex-direction:column; gap:10px; font-size:12px; }
              .apl-summary { display:flex; gap:8px; align-items:center; flex-wrap:wrap; background:rgba(191,0,255,.08); border:1px solid rgba(191,0,255,.25); border-radius:8px; padding:8px 12px; color:#fff; }
              .apl-summary button { margin-left:auto; background:rgba(191,0,255,.2); color:#fff; border:1px solid rgba(191,0,255,.4); padding:6px 12px; border-radius:6px; cursor:pointer; font-size:12px; }
              .apl-summary button:hover:not(:disabled) { background:rgba(191,0,255,.35); }
              .apl-summary button:disabled { opacity:.5; cursor:not-allowed; }
              .apl-ai-out { background:rgba(0,0,0,.3); border:1px solid rgba(255,255,255,.08); border-radius:8px; padding:10px; color:#fff; min-height:0; max-height:280px; overflow:auto; display:none; line-height:1.5; }
              .apl-ai-out.show { display:block; }
              .apl-table { width:100%; border-collapse:collapse; background:rgba(0,0,0,.3); border-radius:8px; overflow:hidden; }
              .apl-table th, .apl-table td { padding:6px 8px; text-align:left; border-bottom:1px solid rgba(255,255,255,.06); color:#fff; vertical-align:top; }
              .apl-table th { background:rgba(191,0,255,.15); font-weight:600; }
              .apl-table code { font-family:monospace; font-size:11px; color:#bf00ff; }
              .apl-prompt, .apl-resp { max-width:280px; word-break:break-word; white-space:pre-wrap; }
              .apl-num { text-align:right; font-variant-numeric:tabular-nums; }
            </style>
          `;

          const btn = mountEl.querySelector(".apl-analyze");
          const out = mountEl.querySelector(".apl-ai-out");

          btn.addEventListener("click", async () => {
            btn.disabled = true;
            out.classList.add("show");
            out.textContent = "Consultando IA…";

            // Agregado enxuto para a IA (sem PII excessiva)
            const aggregate = rows.slice(0, 25).map((r) => ({
              endpoint: r.endpoint,
              tokens: r.tokens,
              status: r.status,
              prompt_snippet: truncate(r.prompt, 240),
            }));

            try {
              const res = await callWithTimeout(
                ctx.callAI("analyze_network_traffic", {
                  focus: "ai_prompt_optimization",
                  total_requests: rows.length,
                  total_tokens_estimated: totalTokens,
                  samples: aggregate,
                }),
                25000
              );
              if (!res.ok) {
                const code = res.error_code ? ` [${res.error_code}]` : "";
                out.innerHTML = `<span style="color:#ff5577;">Falha na IA${S.escapeHtml(code)}: ${S.escapeHtml(res.error || "erro")}</span>`;
                return;
              }
              const text = typeof res.data === "string"
                ? res.data
                : (res.data?.markdown || res.data?.content || JSON.stringify(res.data, null, 2));
              out.innerHTML = S.escapeHtml(text).replace(/\n/g, "<br/>");
            } catch (e) {
              out.innerHTML = `<span style="color:#ff5577;">Erro: ${S.escapeHtml(String(e?.message || e))}</span>`;
            } finally {
              btn.disabled = false;
            }
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();