// ============================================================
// Hyper RB · Script #18 · smart-replay-fuzz
// "Auto-replay no Composer" (modo descoberta).
// Cliente escolhe 1 request, marca par\u00e2metros com checkbox,
// fornece valores aceitos conhecidos, e o script diversifica/muta
// para descobrir novos valores aceitos pelo backend.
// IIFE puro \u00b7 render(mountEl) \u00b7 zero egresso direto (proxyFetch).
// ============================================================
(function registerSmartReplayFuzz() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB \u00b7 smart-replay-fuzz] HYPER_RB_SHARED ausente");
    return;
  }

  // Anti-abuse
  const MAX_VARIANTS_TOTAL = 50;
  const MIN_DEBOUNCE_MS = 500;
  const ALLOWED_HOST_RE = /(^|\.)lovable\.(dev|app)$/i;
  const BLOCKED_HEADERS = new Set(["authorization", "cookie", "set-cookie", "proxy-authorization", "host", "content-length"]);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function cloneHeaders(h) {
    const out = {};
    for (const [k, v] of Object.entries(h || {})) {
      if (BLOCKED_HEADERS.has(String(k).toLowerCase())) continue;
      out[k] = v;
    }
    return out;
  }

  function parseBody(body) {
    if (body == null || body === "") return { kind: "empty", obj: null, raw: "" };
    if (typeof body === "object") return { kind: "json", obj: body, raw: JSON.stringify(body) };
    try { return { kind: "json", obj: JSON.parse(body), raw: body }; } catch {}
    return { kind: "raw", obj: null, raw: String(body) };
  }

  // Flatten top-level + 1 n\u00edvel de objetos (n\u00e3o entra em arrays).
  function flattenParams(obj) {
    const params = [];
    if (!obj || typeof obj !== "object") return params;
    for (const [k, v] of Object.entries(obj)) {
      if (v !== null && typeof v === "object" && !Array.isArray(v)) {
        for (const [k2, v2] of Object.entries(v)) {
          if (v2 !== null && typeof v2 === "object") continue; // skip deep
          params.push({ path: `${k}.${k2}`, value: v2, type: typeof v2 });
        }
      } else if (!Array.isArray(v) || v.every((x) => typeof x !== "object")) {
        params.push({ path: k, value: v, type: Array.isArray(v) ? "array" : typeof v });
      }
    }
    return params;
  }

  function setByPath(obj, path, value) {
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!cur[parts[i]] || typeof cur[parts[i]] !== "object") cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = value;
  }

  // Estrat\u00e9gias de muta\u00e7\u00e3o por tipo
  function generateMutations(originalValue, acceptedValues, type) {
    const set = new Set();
    // Valores aceitos pelo usu\u00e1rio (verbatim)
    for (const v of acceptedValues) set.add(JSON.stringify(v));

    // Diversifica\u00e7\u00f5es baseadas no tipo
    if (type === "string") {
      for (const v of acceptedValues) {
        if (typeof v !== "string") continue;
        set.add(JSON.stringify(v.toUpperCase()));
        set.add(JSON.stringify(v.toLowerCase()));
        set.add(JSON.stringify(v + "_x"));
        set.add(JSON.stringify("x_" + v));
        set.add(JSON.stringify(v.slice(0, Math.max(1, Math.floor(v.length / 2)))));
      }
      // Boundary
      set.add(JSON.stringify(""));
      set.add(JSON.stringify("a".repeat(1024)));
    } else if (type === "number") {
      for (const v of acceptedValues) {
        const n = Number(v);
        if (Number.isFinite(n)) {
          set.add(JSON.stringify(n + 1));
          set.add(JSON.stringify(n - 1));
          set.add(JSON.stringify(n * 2));
          set.add(JSON.stringify(-n));
        }
      }
      set.add(JSON.stringify(0));
      set.add(JSON.stringify(-1));
      set.add(JSON.stringify(Number.MAX_SAFE_INTEGER));
    } else if (type === "boolean") {
      set.add(JSON.stringify(true));
      set.add(JSON.stringify(false));
    } else if (type === "array") {
      set.add(JSON.stringify([]));
      for (const v of acceptedValues) set.add(JSON.stringify(Array.isArray(v) ? v : [v]));
    }
    // Boundary universal
    set.add(JSON.stringify(null));

    // Remove o valor original (n\u00e3o \u00e9 muta\u00e7\u00e3o)
    set.delete(JSON.stringify(originalValue));

    return Array.from(set).map((s) => JSON.parse(s));
  }

  function parseAcceptedInput(text) {
    if (!text || !text.trim()) return [];
    return text.split(",").map((s) => {
      const t = s.trim();
      if (!t) return null;
      try { return JSON.parse(t); } catch { return t; }
    }).filter((v) => v !== null);
  }

  function classifyResult(originalStatus, status) {
    if (status >= 200 && status < 300) {
      if (originalStatus >= 200 && originalStatus < 300) return { tag: "accepted", label: "Aceito \u2713" };
      return { tag: "newly-accepted", label: "NOVO ACEITO \u2605" };
    }
    if (status === 400 || status === 422) return { tag: "rejected", label: "Rejeitado" };
    if (status === 401 || status === 403) return { tag: "auth", label: "Auth" };
    if (status === 429) return { tag: "rate", label: "Rate" };
    if (status >= 500) return { tag: "error", label: "Erro upstream" };
    return { tag: "other", label: String(status || "?") };
  }

  const SCRIPT = {
    id: 18,
    slug: "smart-replay-fuzz",
    name: "Smart Replay Fuzz",
    description: "Marque par\u00e2metros, forne\u00e7a valores aceitos e descubra novos valores que o backend aceita.",
    icon: "\ud83c\udfaf",
    needsAI: false,
    needsNetwork: true,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes." };
      }

      const list = ctx.requests
        .slice(-100)
        .reverse()
        .map((r) => ({ id: r.id, label: `${r.method} ${r.host}${r.pathname}`.slice(0, 90), status: r.status }));

      return {
        ok: true,
        summary: `${ctx.requests.length} requests dispon\u00edveis para fuzz`,
        render(mountEl) {
          mountEl.innerHTML = `
            <div class="hyper-rb-srf">
              <div class="srf-toolbar">
                <label>Request alvo:</label>
                <select class="srf-select">
                  ${list.map((r) => `<option value="${S.escapeHtml(r.id)}">${S.escapeHtml(r.label)}${r.status ? " \u00b7 " + r.status : ""}</option>`).join("")}
                </select>
                <button class="srf-load" type="button">Carregar par\u00e2metros</button>
              </div>
              <div class="srf-warn">
                <strong>Aviso:</strong> apenas hosts <code>lovable.dev</code> / <code>*.lovable.app</code>.
                M\u00e1ximo ${MAX_VARIANTS_TOTAL} variantes por execu\u00e7\u00e3o. Debounce m\u00ednimo ${MIN_DEBOUNCE_MS}ms.
              </div>
              <div class="srf-params"></div>
              <div class="srf-run-row" style="display:none;">
                <label>Debounce (ms):</label>
                <input class="srf-debounce" type="number" value="800" min="${MIN_DEBOUNCE_MS}" step="100" />
                <button class="srf-run" type="button">Executar fuzz</button>
                <span class="srf-progress"></span>
              </div>
              <div class="srf-output"></div>
            </div>
            <style>
              .hyper-rb-srf { display:flex; flex-direction:column; gap:10px; font-size:12px; color:#fff; }
              .srf-toolbar, .srf-run-row { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
              .srf-toolbar select { flex:1; min-width:240px; background:rgba(18,18,20,.7); color:#fff; border:1px solid rgba(191,0,255,.3); padding:6px 8px; border-radius:6px; }
              .srf-toolbar button, .srf-run-row button { background:rgba(191,0,255,.2); color:#fff; border:1px solid rgba(191,0,255,.4); padding:6px 12px; border-radius:6px; cursor:pointer; }
              .srf-toolbar button:hover:not(:disabled), .srf-run-row button:hover:not(:disabled) { background:rgba(191,0,255,.35); }
              button:disabled { opacity:.5; cursor:not-allowed; }
              .srf-warn { background:rgba(255,180,0,.08); border:1px solid rgba(255,180,0,.3); border-radius:8px; padding:8px 12px; font-size:11px; color:rgba(255,255,255,.85); }
              .srf-warn code { background:rgba(255,180,0,.15); padding:1px 4px; border-radius:3px; }
              .srf-params { display:flex; flex-direction:column; gap:6px; background:rgba(0,0,0,.3); border:1px solid rgba(255,255,255,.08); border-radius:8px; padding:10px; }
              .srf-params:empty { display:none; }
              .srf-param-row { display:grid; grid-template-columns:24px 1fr 1fr 2fr; gap:8px; align-items:center; padding:6px; border-radius:6px; background:rgba(18,18,20,.5); }
              .srf-param-row input[type=text] { background:rgba(0,0,0,.4); color:#fff; border:1px solid rgba(255,255,255,.12); padding:4px 6px; border-radius:4px; font-family:monospace; font-size:11px; }
              .srf-param-row.checked { border-left:3px solid #bf00ff; }
              .srf-param-path { font-family:monospace; color:#bf00ff; font-size:11px; word-break:break-all; }
              .srf-param-orig { color:rgba(255,255,255,.6); font-family:monospace; font-size:11px; word-break:break-all; }
              .srf-run-row input { background:rgba(18,18,20,.7); color:#fff; border:1px solid rgba(191,0,255,.3); padding:4px 8px; border-radius:4px; width:90px; }
              .srf-progress { color:rgba(191,0,255,.9); font-size:11px; }
              .srf-output { background:rgba(0,0,0,.3); border:1px solid rgba(255,255,255,.08); border-radius:8px; padding:10px; max-height:400px; overflow:auto; }
              .srf-output:empty { display:none; }
              .srf-result-table { width:100%; border-collapse:collapse; font-size:11px; }
              .srf-result-table th, .srf-result-table td { padding:5px 8px; text-align:left; border-bottom:1px solid rgba(255,255,255,.06); vertical-align:top; }
              .srf-result-table th { background:rgba(191,0,255,.15); position:sticky; top:0; }
              .srf-result-table code { font-family:monospace; color:#fff; word-break:break-all; }
              .tag-newly-accepted { background:rgba(115,255,184,.2); color:#73ffb8; padding:2px 6px; border-radius:4px; font-weight:bold; }
              .tag-accepted { color:#73ffb8; }
              .tag-rejected { color:#ff9977; }
              .tag-auth, .tag-rate { color:#ffd66b; }
              .tag-error { color:#ff5577; }
              .tag-other { color:rgba(255,255,255,.6); }
              .srf-error { color:#ff5577; padding:8px; }
            </style>
          `;

          const select = mountEl.querySelector(".srf-select");
          const btnLoad = mountEl.querySelector(".srf-load");
          const paramsEl = mountEl.querySelector(".srf-params");
          const runRow = mountEl.querySelector(".srf-run-row");
          const btnRun = mountEl.querySelector(".srf-run");
          const debounceInput = mountEl.querySelector(".srf-debounce");
          const progressEl = mountEl.querySelector(".srf-progress");
          const outputEl = mountEl.querySelector(".srf-output");

          let currentReq = null;
          let currentParams = [];
          let parsedBody = null;

          btnLoad.addEventListener("click", () => {
            outputEl.innerHTML = "";
            runRow.style.display = "none";
            paramsEl.innerHTML = "";

            const req = ctx.requests.find((r) => r.id === select.value);
            if (!req) {
              paramsEl.innerHTML = `<div class="srf-error">Request n\u00e3o encontrada.</div>`;
              return;
            }
            if (!ALLOWED_HOST_RE.test(req.host || "")) {
              paramsEl.innerHTML = `<div class="srf-error">Host n\u00e3o permitido: <code>${S.escapeHtml(req.host || "?")}</code></div>`;
              return;
            }

            currentReq = req;
            parsedBody = parseBody(req.reqBody);
            if (parsedBody.kind !== "json") {
              paramsEl.innerHTML = `<div class="srf-error">Body n\u00e3o-JSON. Smart fuzz suporta apenas requests JSON.</div>`;
              return;
            }

            currentParams = flattenParams(parsedBody.obj);
            if (!currentParams.length) {
              paramsEl.innerHTML = `<div class="srf-error">Nenhum par\u00e2metro detectado no body.</div>`;
              return;
            }

            paramsEl.innerHTML = currentParams.map((p, idx) => `
              <div class="srf-param-row" data-idx="${idx}">
                <input type="checkbox" class="srf-check" data-idx="${idx}" />
                <div class="srf-param-path">${S.escapeHtml(p.path)} <small style="color:rgba(255,255,255,.4);">(${p.type})</small></div>
                <div class="srf-param-orig">${S.escapeHtml(truncate(JSON.stringify(p.value), 40))}</div>
                <input type="text" class="srf-accepted" data-idx="${idx}" placeholder="valores aceitos (separados por v\u00edrgula, ex: &quot;a&quot;,&quot;b&quot;,123)" disabled />
              </div>
            `).join("");

            paramsEl.querySelectorAll(".srf-check").forEach((cb) => {
              cb.addEventListener("change", (e) => {
                const idx = e.target.dataset.idx;
                const row = paramsEl.querySelector(`.srf-param-row[data-idx="${idx}"]`);
                const input = paramsEl.querySelector(`.srf-accepted[data-idx="${idx}"]`);
                row.classList.toggle("checked", e.target.checked);
                input.disabled = !e.target.checked;
                updateRunVisibility();
              });
            });

            runRow.style.display = "flex";
          });

          function updateRunVisibility() {
            const anyChecked = !!paramsEl.querySelector(".srf-check:checked");
            btnRun.disabled = !anyChecked;
          }

          function truncate(s, n) {
            s = String(s);
            return s.length > n ? s.slice(0, n) + "\u2026" : s;
          }

          btnRun.addEventListener("click", async () => {
            if (!currentReq || !parsedBody) return;

            const debounce = Math.max(MIN_DEBOUNCE_MS, parseInt(debounceInput.value, 10) || MIN_DEBOUNCE_MS);
            debounceInput.value = debounce;

            // Coleta params marcados
            const targets = [];
            paramsEl.querySelectorAll(".srf-check:checked").forEach((cb) => {
              const idx = parseInt(cb.dataset.idx, 10);
              const accepted = parseAcceptedInput(paramsEl.querySelector(`.srf-accepted[data-idx="${idx}"]`).value);
              targets.push({ ...currentParams[idx], accepted });
            });

            // Gera variantes (uma muta\u00e7\u00e3o por vez, mantendo demais campos)
            const variants = [];
            for (const t of targets) {
              const mutations = generateMutations(t.value, t.accepted, t.type);
              for (const mv of mutations) {
                if (variants.length >= MAX_VARIANTS_TOTAL) break;
                variants.push({ path: t.path, value: mv });
              }
              if (variants.length >= MAX_VARIANTS_TOTAL) break;
            }

            if (!variants.length) {
              outputEl.innerHTML = `<div class="srf-error">Nenhuma muta\u00e7\u00e3o gerada. Forne\u00e7a pelo menos 1 valor aceito por par\u00e2metro.</div>`;
              return;
            }

            // Baseline (original)
            btnRun.disabled = true;
            outputEl.innerHTML = `<div>Rodando baseline\u2026</div>`;
            const baseHeaders = cloneHeaders(currentReq.reqHeaders);
            let baselineStatus = 0;
            try {
              const baseRes = await ctx.proxyFetch(currentReq.url, {
                method: currentReq.method,
                headers: baseHeaders,
                body: parsedBody.raw,
              });
              baselineStatus = baseRes.status || 0;
            } catch (e) {
              ctx.log?.("warn", "baseline falhou", e);
            }

            const results = [];
            for (let i = 0; i < variants.length; i++) {
              const v = variants[i];
              progressEl.textContent = `${i + 1} / ${variants.length} \u2014 ${v.path}`;
              const mutObj = JSON.parse(parsedBody.raw);
              setByPath(mutObj, v.path, v.value);
              try {
                const res = await ctx.proxyFetch(currentReq.url, {
                  method: currentReq.method,
                  headers: baseHeaders,
                  body: JSON.stringify(mutObj),
                });
                results.push({ path: v.path, value: v.value, status: res.status || 0, ms: res.durationMs || 0, error: res.error });
              } catch (e) {
                results.push({ path: v.path, value: v.value, status: 0, ms: 0, error: String((e && e.message) || e) });
              }
              if (i < variants.length - 1) await sleep(debounce);
            }

            progressEl.textContent = `conclu\u00eddo \u2014 baseline status ${baselineStatus}`;
            renderResults(results, baselineStatus);
            btnRun.disabled = false;
          });

          function renderResults(results, baselineStatus) {
            const sorted = [...results].sort((a, b) => {
              const aNew = classifyResult(baselineStatus, a.status).tag === "newly-accepted" ? 0 : 1;
              const bNew = classifyResult(baselineStatus, b.status).tag === "newly-accepted" ? 0 : 1;
              return aNew - bNew;
            });
            outputEl.innerHTML = `
              <table class="srf-result-table">
                <thead><tr><th>Par\u00e2metro</th><th>Valor testado</th><th>Status</th><th>Resultado</th><th>ms</th></tr></thead>
                <tbody>
                  ${sorted.map((r) => {
                    const cls = classifyResult(baselineStatus, r.status);
                    return `<tr>
                      <td><code>${S.escapeHtml(r.path)}</code></td>
                      <td><code>${S.escapeHtml(truncate(JSON.stringify(r.value), 60))}</code></td>
                      <td>${r.status || (r.error ? "\u2715" : "?")}</td>
                      <td><span class="tag-${cls.tag}">${S.escapeHtml(cls.label)}</span></td>
                      <td>${r.ms}</td>
                    </tr>`;
                  }).join("")}
                </tbody>
              </table>
            `;
          }
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();