(function registerDriftMonitor() {
  "use strict";

  const S = window.HYPER_RB_SHARED;
  if (!S) {
    console.error("[Hyper RB · drift-monitor] HYPER_RB_SHARED ausente");
    return;
  }

  const SNAPSHOT_KEY = "last_snapshot";
  const SNAPSHOTS_KEY = "snapshots";
  const MAX_SNAPSHOTS = 10;

  function normalizePath(pathname) {
    if (!pathname || pathname === "/") return "/";
    return "/" + pathname
      .split("/")
      .filter(Boolean)
      .map((segment) => {
        if (/^\d+$/.test(segment)) return "{id}";
        if (/^[0-9a-f-]{8,}$/i.test(segment)) return "{id}";
        return segment;
      })
      .join("/");
  }

  function percentile(sortedValues, p) {
    if (!sortedValues.length) return 0;
    const index = Math.min(sortedValues.length - 1, Math.floor((p / 100) * sortedValues.length));
    return Math.round(sortedValues[index]);
  }

  function buildSnapshot(requests) {
    const groups = new Map();

    for (const req of requests) {
      if (!req || !req.host || !req.method) continue;
      const method = String(req.method).toUpperCase();
      const path = normalizePath(req.pathname || "/");
      const key = `${req.host}|${method}|${path}`;

      let group = groups.get(key);
      if (!group) {
        group = {
          key,
          host: req.host,
          method,
          path,
          statuses: new Set(),
          durations: [],
          contentType: "",
          count: 0,
        };
        groups.set(key, group);
      }

      group.count += 1;

      if (typeof req.status === "number" && isFinite(req.status)) {
        group.statuses.add(String(req.status));
      }

      if (typeof req.durationMs === "number" && isFinite(req.durationMs)) {
        group.durations.push(req.durationMs);
      }

      if (!group.contentType) {
        const contentType = (req.resHeaders && (req.resHeaders["content-type"] || req.resHeaders["Content-Type"])) || "";
        group.contentType = String(contentType).split(";")[0].trim();
      }
    }

    const endpoints = Array.from(groups.values())
      .map((group) => {
        const sortedDurations = group.durations.slice().sort((a, b) => a - b);
        return {
          key: group.key,
          host: group.host,
          method: group.method,
          path: group.path,
          count: group.count,
          statuses: Array.from(group.statuses).sort(),
          p95Ms: percentile(sortedDurations, 95),
          contentType: group.contentType || "—",
        };
      })
      .sort((a, b) => a.key.localeCompare(b.key));

    return {
      version: 1,
      generatedAt: new Date().toISOString(),
      totalRequests: requests.length,
      endpoints,
    };
  }

  function ratioDelta(previous, current) {
    if (!previous && !current) return 0;
    if (!previous || !current) return 1;
    return Math.abs(current - previous) / Math.max(previous, 1);
  }

  function compareSnapshots(previousSnapshot, currentSnapshot) {
    const previousMap = new Map((previousSnapshot?.endpoints || []).map((item) => [item.key, item]));
    const currentMap = new Map((currentSnapshot?.endpoints || []).map((item) => [item.key, item]));

    const added = [];
    const removed = [];
    const changed = [];

    for (const endpoint of currentSnapshot.endpoints) {
      const before = previousMap.get(endpoint.key);
      if (!before) {
        added.push(endpoint);
        continue;
      }

      const reasons = [];
      const beforeStatuses = JSON.stringify(before.statuses || []);
      const afterStatuses = JSON.stringify(endpoint.statuses || []);
      if (beforeStatuses !== afterStatuses) {
        reasons.push(`status ${before.statuses.join(", ") || "—"} → ${endpoint.statuses.join(", ") || "—"}`);
      }

      if ((before.contentType || "—") !== (endpoint.contentType || "—")) {
        reasons.push(`content-type ${before.contentType || "—"} → ${endpoint.contentType || "—"}`);
      }

      const latencyDelta = ratioDelta(before.p95Ms, endpoint.p95Ms);
      if (latencyDelta > 0.5) {
        reasons.push(`p95 ${before.p95Ms || 0}ms → ${endpoint.p95Ms || 0}ms`);
      }

      if (reasons.length) {
        changed.push({
          ...endpoint,
          previous: before,
          reasons,
        });
      }
    }

    for (const endpoint of previousSnapshot?.endpoints || []) {
      if (!currentMap.has(endpoint.key)) {
        removed.push(endpoint);
      }
    }

    return { added, removed, changed };
  }

  async function saveSnapshot(ctx, snapshot) {
    const stored = await ctx.storage.get(SNAPSHOTS_KEY);
    const snapshots = Array.isArray(stored) ? stored : [];
    const compact = {
      generatedAt: snapshot.generatedAt,
      totalRequests: snapshot.totalRequests,
      endpoints: snapshot.endpoints,
    };
    const nextSnapshots = snapshots.concat(compact).slice(-MAX_SNAPSHOTS);
    await ctx.storage.set(SNAPSHOTS_KEY, nextSnapshots);
    await ctx.storage.set(SNAPSHOT_KEY, compact);
    return nextSnapshots.length;
  }

  function renderColumn(title, toneClass, items, renderItem) {
    if (!items.length) {
      return `
        <section class="dm-col ${toneClass}">
          <div class="dm-col-head">
            <span>${S.escapeHtml(title)}</span>
            <span class="dm-count">0</span>
          </div>
          <div class="dm-empty">Sem itens.</div>
        </section>`;
    }

    return `
      <section class="dm-col ${toneClass}">
        <div class="dm-col-head">
          <span>${S.escapeHtml(title)}</span>
          <span class="dm-count">${S.escapeHtml(items.length)}</span>
        </div>
        <div class="dm-col-body">${items.map(renderItem).join("")}</div>
      </section>`;
  }

  function renderEndpointChip(item, details) {
    return `
      <article class="dm-item">
        <div class="dm-item-top">
          <span class="dm-method">${S.escapeHtml(item.method)}</span>
          <span class="dm-path">${S.escapeHtml(item.host)}${S.escapeHtml(item.path)}</span>
        </div>
        <div class="dm-item-meta">${details}</div>
      </article>`;
  }

  const SCRIPT = {
    id: 8,
    slug: "drift-monitor",
    name: "Monitor de Drift",
    description: "Compara o mapa atual com o último snapshot salvo e destaca endpoints novos, removidos ou alterados.",
    icon: "🛰️",
    needsAI: false,
    needsNetwork: false,
    minRequests: 1,

    async run(ctx) {
      if (!ctx.requests.length) {
        return { ok: false, error: "Capture pelo menos 1 request antes de executar." };
      }

      const currentSnapshot = buildSnapshot(ctx.requests);
      if (!currentSnapshot.endpoints.length) {
        return { ok: false, error: "Nenhum endpoint válido foi encontrado na captura atual." };
      }

      const previousSnapshot = await ctx.storage.get(SNAPSHOT_KEY);
      const diff = previousSnapshot
        ? compareSnapshots(previousSnapshot, currentSnapshot)
        : { added: [], removed: [], changed: [] };

      const summary = previousSnapshot
        ? `+${diff.added.length} · -${diff.removed.length} · ~${diff.changed.length}`
        : `${currentSnapshot.endpoints.length} endpoints atuais · sem snapshot anterior`;

      return {
        ok: true,
        summary,
        render(mountEl) {
          const comparedAt = previousSnapshot?.generatedAt
            ? new Date(previousSnapshot.generatedAt).toLocaleString("pt-BR")
            : null;

          mountEl.innerHTML = `
            <style>
              .dm-wrap{display:flex;flex-direction:column;gap:12px;padding:12px;color:#ececf1;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace}
              .dm-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;background:rgba(18,18,20,.7);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:12px}
              .dm-title{font-size:12px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;color:#bf00ff}
              .dm-sub{margin-top:4px;color:rgba(255,255,255,.6)}
              .dm-stats{display:flex;gap:8px;flex-wrap:wrap}.dm-stat{padding:5px 8px;border-radius:999px;background:rgba(191,0,255,.08);border:1px solid rgba(191,0,255,.24)}
              .dm-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
              .dm-btn{padding:7px 12px;border:none;border-radius:6px;background:#bf00ff;color:#0a0a0c;font-weight:800;cursor:pointer}
              .dm-btn[disabled]{opacity:.6;cursor:wait}
              .dm-hint{color:rgba(255,255,255,.5);font-size:11px}
              .dm-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
              .dm-col{background:rgba(18,18,20,.7);border:1px solid rgba(255,255,255,.06);border-radius:8px;min-height:220px;display:flex;flex-direction:column}
              .dm-col-head{display:flex;justify-content:space-between;align-items:center;padding:12px;border-bottom:1px solid rgba(255,255,255,.06);font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
              .dm-col-body{padding:10px;display:flex;flex-direction:column;gap:8px;overflow:auto}
              .dm-count{padding:2px 7px;border-radius:999px;background:rgba(255,255,255,.08)}
              .dm-item{padding:10px;border-radius:6px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05)}
              .dm-item-top{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.dm-item-meta{margin-top:6px;color:rgba(255,255,255,.62);white-space:pre-wrap;word-break:break-word}
              .dm-method{font-size:10px;font-weight:900;color:#bf00ff}
              .dm-path{flex:1;min-width:0;word-break:break-word}
              .dm-empty{padding:18px;color:rgba(255,255,255,.45)}
              .dm-col-added .dm-col-head{color:#77e6b3}.dm-col-removed .dm-col-head{color:#ff9aac}.dm-col-changed .dm-col-head{color:#ffd07d}
              @media (max-width: 980px){.dm-grid{grid-template-columns:1fr}}
            </style>
            <div class="dm-wrap">
              <div class="dm-head">
                <div>
                  <div class="dm-title">Monitor de Drift</div>
                  <div class="dm-sub">
                    ${comparedAt ? `Comparando com snapshot salvo em ${S.escapeHtml(comparedAt)}.` : "Nenhum snapshot salvo ainda. Salve o estado atual para começar a comparar."}
                  </div>
                </div>
                <div class="dm-actions">
                  <div class="dm-stats">
                    <span class="dm-stat">${S.escapeHtml(currentSnapshot.endpoints.length)} endpoints</span>
                    <span class="dm-stat">${S.escapeHtml(currentSnapshot.totalRequests)} requests</span>
                    ${previousSnapshot ? `<span class="dm-stat">+${S.escapeHtml(diff.added.length)} / -${S.escapeHtml(diff.removed.length)} / ~${S.escapeHtml(diff.changed.length)}</span>` : ""}
                  </div>
                  <button class="dm-btn" data-action="save-snapshot">Salvar snapshot</button>
                </div>
              </div>
              ${previousSnapshot ? `
                <div class="dm-grid">
                  ${renderColumn("Added", "dm-col-added", diff.added, (item) => renderEndpointChip(item, `statuses: ${S.escapeHtml((item.statuses || []).join(", ") || "—")} · p95 ${S.escapeHtml(item.p95Ms)}ms`))}
                  ${renderColumn("Removed", "dm-col-removed", diff.removed, (item) => renderEndpointChip(item, `snapshot anterior · statuses: ${S.escapeHtml((item.statuses || []).join(", ") || "—")}`))}
                  ${renderColumn("Changed", "dm-col-changed", diff.changed, (item) => renderEndpointChip(item, S.escapeHtml(item.reasons.join(" · "))))}
                </div>` : `<div class="dm-empty">Execute novamente após salvar um snapshot para ver Added / Removed / Changed.</div>`}
                <div class="dm-hint" data-region="save-status"></div>
            </div>`;

          const saveButton = mountEl.querySelector('[data-action="save-snapshot"]');
          const saveStatus = mountEl.querySelector('[data-region="save-status"]');
          saveButton?.addEventListener("click", async () => {
            saveButton.disabled = true;
            if (saveStatus) saveStatus.textContent = "Salvando snapshot…";
            try {
              const total = await saveSnapshot(ctx, currentSnapshot);
              if (saveStatus) saveStatus.textContent = `Snapshot salvo com sucesso. Histórico atual: ${total}/${MAX_SNAPSHOTS}.`;
            } catch (error) {
              if (saveStatus) saveStatus.textContent = `Falha ao salvar: ${error && error.message ? error.message : String(error)}`;
            } finally {
              saveButton.disabled = false;
            }
          });
        },
      };
    },
  };

  window.HYPER_RB_SCRIPTS = window.HYPER_RB_SCRIPTS || [];
  window.HYPER_RB_SCRIPTS.push(SCRIPT);
})();